package com.gionee.bigdata.recommender.tencent;

import com.google.common.base.Charsets;
import com.google.common.collect.Lists;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;
import org.junit.Test;

import java.net.URISyntaxException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.BitSet;
import java.util.List;

/**
 * <code>UrlEncodedTest</code>.
 * ${DESCRIPTION}
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/20 13:35
 */
public class ParamsEncodeTest {

    @Test
    public void testEncode() throws URISyntaxException {
        List<NameValuePair> params = Lists.newArrayList();
        params.add(new BasicNameValuePair("m", "multiDataImport"));
        params.add(new BasicNameValuePair("p", "[\"200000\",\"7d10d09d-be62-4979-9ee0-414f7a23086a\",\"uid=8fbcdd43a1b276068a552e3eca8a829a&oper_time=2017/06/08 18:59:25.000&test_id=0&rule_id=0&trace_id=0&item_id=8879&action_id=103&device=231&network_type=3&app_version=1.4.9.x&report_source=CATEGORY157_GID8879##uid=5e08520d1818734fe58c133e2208708c&oper_time=2017/06/08 18:36:00.000&test_id=0&rule_id=0&trace_id=0&item_id=7851&action_id=103&device=179&network_type=3&app_version=1.4.8.j&report_source=flashrecom651##uid=792ce270073c2cb2a3ee4caf1c5d30c7&oper_time=2017/06/08 19:25:23.000&test_id=0&rule_id=0&trace_id=0&item_id=5073&action_id=103&device=234&network_type=2&app_version=1.4.9.w&report_source=ad24_pcg_GID5073##uid=424be49ddbe04a4cf32cd309cfbf8a57&oper_time=2017/06/08 19:25:41.000&test_id=0&rule_id=0&trace_id=0&item_id=5743&action_id=103&device=222&network_type=3&app_version=1.4.7.g&report_source=gltj6866_GID5743##uid=424be49ddbe04a4cf32cd309cfbf8a57&oper_time=2017/06/08 19:25:56.000&test_id=0&rule_id=0&trace_id=0&item_id=5743&action_id=103&device=222&network_type=3&app_version=1.4.7.g&report_source=gltj6866_GID5743##uid=02f3749ba29bf3ae33b45adc1aa5d64e&oper_time=2017/06/08 18:22:52.000&test_id=0&rule_id=0&trace_id=0&item_id=8754&action_id=102&device=21000&network_type=3&app_version=1.4.5.a&report_source=CATEGORY3_GID8754##uid=e5d0c8bc0e5ee16c2602e0ec8872efdf&oper_time=2017/06/08 19:52:59.000&test_id=0&rule_id=0&trace_id=0&item_id=9057&action_id=103&device=176&network_type=3&app_version=1.4.9.t&report_source=Isearch##uid=f435aba0cece62263e3f4a71cf6ef0f3&oper_time=2017/06/08 19:44:26.000&test_id=0&rule_id=0&trace_id=0&item_id=7041&action_id=103&device=178&network_type=3&app_version=1.4.8.j&report_source=flashrecom651##uid=8c86044c241814dbd61c2e3f3e286563&oper_time=2017/06/08 19:43:21.000&test_id=0&rule_id=0&trace_id=0&item_id=6695&action_id=103&device=212&network_type=3&app_version=1.4.9.f&report_source=ad22_ness_GID6695##uid=e5d0c8bc0e5ee16c2602e0ec8872efdf&oper_time=2017/06/08 19:52:45.000&test_id=0&rule_id=0&trace_id=0&item_id=9057&action_id=103&device=176&network_type=3&app_version=1.4.9.t&report_source=Isearch\"]"));
        String string = URLEncodedUtils.format(params, Charsets.UTF_8);
        System.out.println(string);

        String content = "m=multiDataImport&p=[\"200000\",\"7d10d09d-be62-4979-9ee0-414f7a23086a\",\"uid=8fbcdd43a1b276068a552e3eca8a829a&oper_time=2017/06/08 18:59:25.000&test_id=0&rule_id=0&trace_id=0&item_id=8879&action_id=103&device=231&network_type=3&app_version=1.4.9.x&report_source=CATEGORY157_GID8879##uid=5e08520d1818734fe58c133e2208708c&oper_time=2017/06/08 18:36:00.000&test_id=0&rule_id=0&trace_id=0&item_id=7851&action_id=103&device=179&network_type=3&app_version=1.4.8.j&report_source=flashrecom651##uid=792ce270073c2cb2a3ee4caf1c5d30c7&oper_time=2017/06/08 19:25:23.000&test_id=0&rule_id=0&trace_id=0&item_id=5073&action_id=103&device=234&network_type=2&app_version=1.4.9.w&report_source=ad24_pcg_GID5073##uid=424be49ddbe04a4cf32cd309cfbf8a57&oper_time=2017/06/08 19:25:41.000&test_id=0&rule_id=0&trace_id=0&item_id=5743&action_id=103&device=222&network_type=3&app_version=1.4.7.g&report_source=gltj6866_GID5743##uid=424be49ddbe04a4cf32cd309cfbf8a57&oper_time=2017/06/08 19:25:56.000&test_id=0&rule_id=0&trace_id=0&item_id=5743&action_id=103&device=222&network_type=3&app_version=1.4.7.g&report_source=gltj6866_GID5743##uid=02f3749ba29bf3ae33b45adc1aa5d64e&oper_time=2017/06/08 18:22:52.000&test_id=0&rule_id=0&trace_id=0&item_id=8754&action_id=102&device=21000&network_type=3&app_version=1.4.5.a&report_source=CATEGORY3_GID8754##uid=e5d0c8bc0e5ee16c2602e0ec8872efdf&oper_time=2017/06/08 19:52:59.000&test_id=0&rule_id=0&trace_id=0&item_id=9057&action_id=103&device=176&network_type=3&app_version=1.4.9.t&report_source=Isearch##uid=f435aba0cece62263e3f4a71cf6ef0f3&oper_time=2017/06/08 19:44:26.000&test_id=0&rule_id=0&trace_id=0&item_id=7041&action_id=103&device=178&network_type=3&app_version=1.4.8.j&report_source=flashrecom651##uid=8c86044c241814dbd61c2e3f3e286563&oper_time=2017/06/08 19:43:21.000&test_id=0&rule_id=0&trace_id=0&item_id=6695&action_id=103&device=212&network_type=3&app_version=1.4.9.f&report_source=ad22_ness_GID6695##uid=e5d0c8bc0e5ee16c2602e0ec8872efdf&oper_time=2017/06/08 19:52:45.000&test_id=0&rule_id=0&trace_id=0&item_id=9057&action_id=103&device=176&network_type=3&app_version=1.4.9.t&report_source=Isearch\"]";
//        String content = "multiDataImport";
        Charset charset = Charset.forName("UTF-8");
        final StringBuilder buf = new StringBuilder();
        final ByteBuffer bb = charset.encode(content);
        BitSet safechars = new BitSet(256);
        // alpha characters
        for (int i = 'a'; i <= 'z'; i++) {
            safechars.set(i);
        }
        for (int i = 'A'; i <= 'Z'; i++) {
            safechars.set(i);
        }
        // numeric characters
        for (int i = '0'; i <= '9'; i++) {
            safechars.set(i);
        }
        safechars.set('_'); // these are the charactes of the "mark" list
        safechars.set('-');
        safechars.set('.');
        safechars.set('*');

        int RADIX = 16;
        boolean blankAsPlus = true;
        while (bb.hasRemaining()) {
            final int b = bb.get() & 0xff;
            if (safechars.get(b)) {
                buf.append((char) b);
            } else if (blankAsPlus && b == ' ') {
                buf.append('+');
            } else {
                buf.append("%");
                final char hex1 = Character.toUpperCase(Character.forDigit((b >> 4) & 0xF, RADIX));
                final char hex2 = Character.toUpperCase(Character.forDigit(b & 0xF, RADIX));
                buf.append(hex1);
                buf.append(hex2);
            }
        }
        System.out.println(buf.toString());
    }

}
