#!/bin/bash
# 将游戏的用户行为数据上报给腾讯，部署于10.10.10.81服务器，定时9:00执行
UPLOAD_HOME=/data/game_data_to_tencent
JAR_FILE=${UPLOAD_HOME}/gdata-recommender-tencent-upload.jar
CLASS_NAME=com.gionee.bigdata.recommender.tencent.UploadAction
# 连接个数
cNum=1000
# 线程个数
tNum=100
TABLE_PATH=/user/hive/warehouse/rec_game_data_to_tencent
if [ $# -eq 0 ]
then
  dayId=`date -d "1 days ago" "+%Y%m%d"`
else
  dayId=$1
fi
dayPath=${UPLOAD_HOME}/${dayId}/rec_game_data_to_tencent
# 拉取HDFS上的数据
echo "拉取HDFS上的数据"
/home/hadoop/hadoop-2.2.0/bin/hdfs dfs -get ${TABLE_PATH}/day_id=${dayId} ${dayPath}
# 遍历日期目录下的文件
ls ${dayPath} | while read file
do
  filePath=${dayPath}/${file}
  echo "开始上传${filePath}"
  /home/hadoop/jdk1.7.0_09/bin/java -cp ${JAR_FILE} ${CLASS_NAME} -t ${tNum} -c ${cNum} -f ${filePath} > ${filePath}.log
done
