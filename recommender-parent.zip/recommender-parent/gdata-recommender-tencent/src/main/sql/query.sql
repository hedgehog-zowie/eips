-- imei 带 3 4 的
select day_id,
count(case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end) as `访问次数`,
count(distinct (case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end)) as `访问人数`,
count(case when OP_TYPE = 'startdl' then imei end) as `下载次数`,
count(distinct (case when OP_TYPE = 'startdl' then imei end)) as `下载人数`,
count(case when OP_TYPE = 'dlsucess' then imei end) as `下载成功次数`,
count(distinct (case when OP_TYPE = 'dlsucess' then imei end)) as `下载成功人数`
from fact_gamec_log_his
where (day_id between 20170829 and 20170830)
and (imei like '%3' or imei like '%4')
and pd_type = 14
group by day_id
order by day_id;

-- imei 不带 3 4 的
select day_id,
count(case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end) as `访问次数`,
count(distinct case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end) as `访问人数`,
count(case when OP_TYPE ='startdl' then imei end) as `下载次数`,
count(distinct case when OP_TYPE ='startdl' then imei end) as `下载人数`,
count(case when OP_TYPE = 'dlsucess' then imei end) as `下载成功次数`,
count(distinct (case when OP_TYPE = 'dlsucess' then imei end)) as `下载成功人数`
from fact_gamec_log_his
where (day_id between 20170829 and 20170830)
and (imei not like '%3' and  imei not like '%4')
and pd_type = 14
group by day_id
order by day_id;

-- imei 带 5 6 的，同一数据量级
select day_id,
count(case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end) as `访问次数`,
count(distinct (case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end)) as `访问人数`,
count(case when OP_TYPE = 'startdl' then imei end) as `下载次数`,
count(distinct (case when OP_TYPE = 'startdl' then imei end)) as `下载人数`,
count(case when OP_TYPE = 'dlsucess' then imei end) as `下载成功次数`,
count(distinct (case when OP_TYPE = 'dlsucess' then imei end)) as `下载成功人数`
from fact_gamec_log_his
where (day_id between 20170802 and 20170830)
and (imei like '%5' or imei like '%6')
and pd_type = 14
group by day_id
order by day_id;

-- imei全量
select day_id,
count(case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end) as `访问次数`,
count(distinct (case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end)) as `访问人数`,
count(case when OP_TYPE = 'startdl' then imei end) as `下载次数`,
count(distinct (case when OP_TYPE = 'startdl' then imei end)) as `下载人数`,
count(case when OP_TYPE = 'dlsucess' then imei end) as `下载成功次数`,
count(distinct (case when OP_TYPE = 'dlsucess' then imei end)) as `下载成功人数`
from fact_gamec_log_his
where (day_id between 20170802 and 20170903)
-- and pd_type = 14
and (INTERSRC like '%glike%'  or object like '%glike%')
group by day_id
order by day_id;

-- imei 带 3 4 的
select day_id,
count(case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end) as `曝光次数`,
count(distinct (case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end)) as `曝光人数`,
count(case when OP_TYPE = 'startdl' then imei end) as `下载次数`,
count(distinct (case when OP_TYPE = 'startdl' then imei end)) as `下载人数`,
count(case when OP_TYPE = 'dlsucess' then imei end) as `下载成功次数`,
count(distinct (case when OP_TYPE = 'dlsucess' then imei end)) as `下载成功人数`
from fact_gamec_log_his
where (day_id between 20170802 and 20170903)
and (imei like '%3' or imei like '%4')
and (INTERSRC like '%glike%'  or object like '%glike%')
group by day_id
order by day_id;

-- imei 不带 3 4 的
select day_id,
count(case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end) as `曝光次数`,
count(distinct case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end) as `曝光人数`,
count(case when OP_TYPE ='startdl' then imei end) as `下载次数`,
count(distinct case when OP_TYPE ='startdl' then imei end) as `下载人数`,
count(case when OP_TYPE = 'dlsucess' then imei end) as `下载成功次数`,
count(distinct (case when OP_TYPE = 'dlsucess' then imei end)) as `下载成功人数`
from fact_gamec_log_his
where (day_id between 20170802 and 20170903)
and (imei not like '%3' and  imei not like '%4')
and (INTERSRC like '%glike%'  or object like '%glike%')
group by day_id
order by day_id;

-- imei 带 5 6 的，同一数据量级
select day_id,
count(case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end) as `访问次数`,
count(distinct (case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end)) as `访问人数`,
count(case when OP_TYPE = 'startdl' then imei end) as `下载次数`,
count(distinct (case when OP_TYPE = 'startdl' then imei end)) as `下载人数`,
count(case when OP_TYPE = 'dlsucess' then imei end) as `下载成功次数`,
count(distinct (case when OP_TYPE = 'dlsucess' then imei end)) as `下载成功人数`
from fact_gamec_log_his
where (day_id between 20170802 and 20170903)
and (imei like '%1' or imei like '%2')
and (INTERSRC like '%glike%'  or object like '%glike%')
group by day_id
order by day_id;

select day_id, lower(substr(imei, -1)) tail,
count(case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end) as `访问次数`,
count(distinct (case when OP_TYPE IN ('detail','visit') OR op_type IS NULL OR OP_TYPE LIKE '%jumpf%' then imei end)) as `访问人数`,
count(case when OP_TYPE = 'startdl' then imei end) as `下载次数`,
count(distinct (case when OP_TYPE = 'startdl' then imei end)) as `下载人数`,
count(case when OP_TYPE = 'dlsucess' then imei end) as `下载成功次数`,
count(distinct (case when OP_TYPE = 'dlsucess' then imei end)) as `下载成功人数`
from fact_gamec_log_his
where (day_id between 20171013 and 20171022)
and (INTERSRC like '%glike%'  or object like '%glike%')
and substr(cv,1,5)='1.6.4'
group by lower(substr(imei, -1)), day_id
order by lower(substr(imei, -1)), day_id;

-- 查询上报日志用户数和记录数
select day_id, count(distinct imei) uCount, count(1) rCount from rec_game_data_to_tencent where substr(imei, -1) in ('3','4') group by day_id order by day_id
