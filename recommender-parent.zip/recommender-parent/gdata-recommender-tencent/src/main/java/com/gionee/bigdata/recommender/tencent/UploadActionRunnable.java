package com.gionee.bigdata.recommender.tencent;

import com.gionee.gdata.common.utils.HashUtil;
import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

/**
 * <code>UploadActionRunnable</code>.
 * 行为数据处理
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/14 11:12
 */
public class UploadActionRunnable implements Runnable {

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(UploadActionRunnable.class);

    /**
     * post工具
     */
    private PostUtil postUtil;
    /**
     * 数据列表
     */
    private List<String> lineList = Lists.newArrayList();

    /**
     * 构造函数
     *
     * @param postUtil post工具
     * @param lineList 数据列表
     */
    public UploadActionRunnable(final PostUtil postUtil, final List<String> lineList) {
        this.postUtil = postUtil;
        this.lineList = Lists.newArrayList(lineList);
    }

    @Override
    public void run() {
        StringBuilder pStringBuilder = new StringBuilder("[")
                .append("\"").append(Constants.UPLOAD_ACTION_CODE).append("\",")
                .append("\"").append(Constants.TOKEN).append("\",")
                .append("\"");
        int i = 0;
        for (String line : lineList) {
            String[] fields = line.split(Constants.ACTION_SPLITTER);
            if (fields.length != Constants.ACTION_LENGTH) {
                continue;
            }
            String imei = StringUtils.trim(StringUtils.strip(fields[Constants.ACTION_IMEI_INDEX], "\""));
            // 若长度不为15，则丢弃数据
            if (imei.length() != Constants.ACTION_IMEI_LENGTH) {
                continue;
            }
            // 仅上报imei以0、1、2、3、4结尾的用户行为数据
//            if (!(imei.endsWith("0") ||
//                    imei.endsWith("1") ||
//                    imei.endsWith("2") ||
//                    imei.endsWith("3") ||
//                    imei.endsWith("4"))) {
//                continue;
//            }
            String imeiMd5;
            // 若计算MD5失败，则丢弃数据
            try {
                imeiMd5 = HashUtil.md5Encode(imei);
            } catch (UnsupportedEncodingException e) {
                LOGGER.error("计算imei的md5值失败, imei = {}, {}", imei, e);
                continue;
            } catch (NoSuchAlgorithmException e) {
                LOGGER.error("计算imei的md5值失败, imei = {}, {}", imei, e);
                continue;
            }
            if (!(imeiMd5.endsWith("1") ||
                    imeiMd5.endsWith("2") ||
                    imeiMd5.endsWith("3"))) {
                continue;
            }
            String action = StringUtils.trim(StringUtils.strip(fields[Constants.ACTION_ACTION_INDEX], "\""));
            String version = StringUtils.trim(StringUtils.strip(fields[Constants.ACTION_VERSION_INDEX], "\""));
            String time = StringUtils.trim(StringUtils.strip(fields[Constants.ACTION_TIME_INDEX], "\""));
            String netType = StringUtils.trim(StringUtils.strip(fields[Constants.ACTION_NETTYPE_INDEX], "\""));
            String itemId = StringUtils.trim(StringUtils.strip(fields[Constants.ACTION_ITEMID_INDEX], "\""));
            String referer = StringUtils.trim(StringUtils.strip(fields[Constants.ACTION_REFERER_INDEX], "\""));
            String device = StringUtils.trim(StringUtils.strip(fields[Constants.ACTION_DEVICE_INDEX], "\""));
            pStringBuilder
                    .append("uid=").append(imeiMd5).append("&")
                    .append("oper_time=").append(time).append("&")
                    .append("test_id=").append(Constants.ACTION_TEST_ID).append("&")
                    .append("rule_id=").append(Constants.ACTION_RULE_ID).append("&")
                    .append("trace_id=").append(Constants.ACTION_TRACE_ID).append("&")
                    .append("item_id=").append(itemId).append("&")
                    .append("action_id=").append(Action.valueOf(action).getCode()).append("&")
//                    .append("platform=").append(Constants.ACTION_PLATFORM).append("&")
                    .append("device=").append(device).append("&")
                    .append("network_type=").append(netType).append("&")
                    .append("app_version=").append(version).append("&")
                    .append("report_source=").append(referer);
            i++;
            if (i != lineList.size()) {
                pStringBuilder.append("##");
            }
        }
        pStringBuilder.append("\"").append("]");
        LOGGER.debug("数据上报，请求接口 = {}, data = {}", Constants.UPLOAD_URL, pStringBuilder);

        List<NameValuePair> params = Lists.newArrayList();
        params.add(new BasicNameValuePair("m", "multiDataImport"));
        params.add(new BasicNameValuePair("p", pStringBuilder.toString()));
        try {
            long start = System.currentTimeMillis();
            postUtil.post(Constants.UPLOAD_URL, params);
            long end = System.currentTimeMillis();
            LOGGER.debug("上报完成, 耗时 = {} ms", end - start);
        } catch (Exception e) {
            LOGGER.error("数据上报失败，请求接口 = {}, msg = {},  data = {}", Constants.UPLOAD_URL, e.getLocalizedMessage(), pStringBuilder);
        }
    }
}
