package com.gionee.bigdata.recommender.tencent;

import com.gionee.gdata.common.utils.FileUtil;
import com.gionee.gdata.common.utils.FileUtilCallBack;
import com.google.common.collect.Lists;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * <code>Upload</code>.
 * 腾讯云推荐物品数据上报
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/13 10:30
 */
public final class UploadItem {

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(UploadItem.class);

    /**
     * 线程池
     */
    private ExecutorService executorService;
    /**
     * 批处理大小
     */
    private static final int BATCH_SIZE = 10;
    /**
     * post工具
     */
    private PostUtil postUtil;

    /**
     * @param threadNum     线程数
     * @param connectionNum 连接数
     */
    private UploadItem(final int threadNum, final int connectionNum) {
        this.executorService = Executors.newFixedThreadPool(threadNum);
        this.postUtil = new PostUtil(connectionNum);
    }

    /**
     * @param itemFilePath 物品数据路径
     */
    private void run(final String itemFilePath) {
        FileUtil.readFile(itemFilePath, new FileUtilCallBack() {

            @Override
            public Object readFile(final BufferedReader bufferedReader) {
                List<String> lineList = Lists.newArrayList();
                String line;
                try {
                    while ((line = bufferedReader.readLine()) != null) {
                        lineList.add(line);
                        if (lineList.size() == BATCH_SIZE) {
                            executorService.execute(new UploadItemRunnable(postUtil, lineList));
                            lineList.clear();
                        }
                    }
                    executorService.execute(new UploadItemRunnable(postUtil, lineList));
                } catch (IOException e) {
                    LOGGER.error("读取数据文件异常，file = {}, {}", itemFilePath, e);
                }
                return null;
            }

        });

        executorService.shutdown();
        try {
            executorService.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            LOGGER.error("executorService stop error, {}", e.getLocalizedMessage());
        }
    }

    /**
     * 数据上报程序主函数
     *
     * @param args 命令行参数
     * @throws InterruptedException 略
     */
    public static void main(final String[] args) throws InterruptedException {
        Options options = new Options();
        Option option = new Option("f", "file", true, "指定导入文件");
        option.setRequired(true);
        options.addOption(option);
        option = new Option("t", "threadNum", true, "指定线程数");
        option.setRequired(true);
        options.addOption(option);
        option = new Option("c", "connectionNum", true, "指定连接数");
        option.setRequired(true);
        options.addOption(option);
        option = new Option("h", "help", false, "打印帮助");
        options.addOption(option);

        CommandLineParser parser = new GnuParser();
        CommandLine commandLine;
        try {
            commandLine = parser.parse(options, args);
        } catch (Exception e) {
            new HelpFormatter().printHelp("java -cp gdata-recommender-tencent-upload.jar com.gionee.bigdata.recommender.tencent.UploadItem", options, true);
            return;
        }
        if (commandLine.hasOption('h')) {
            new HelpFormatter().printHelp("java -cp gdata-recommender-tencent-upload.jar com.gionee.bigdata.recommender.tencent.UploadItem", options, true);
            return;
        }

        int threadNum;
        int connectionNum;
        try {
            threadNum = Integer.parseInt(commandLine.getOptionValue('t'));
            connectionNum = Integer.parseInt(commandLine.getOptionValue('c'));
        } catch (NumberFormatException e) {
            new HelpFormatter().printHelp("线程数和连接数必须是整型", options, true);
            return;
        }
        if (connectionNum < threadNum) {
            new HelpFormatter().printHelp("连接数必须大于线程数", options, true);
            return;
        }

        final String itemFilePath = commandLine.getOptionValue('f');
        LOGGER.debug("开始物品数据上报，file = {}, time = {}", itemFilePath, new Date());

        UploadItem uploadItem = new UploadItem(threadNum, connectionNum);
        uploadItem.run(itemFilePath);

        LOGGER.debug("完成物品数据上报，file = {}, time = {}", itemFilePath, new Date());
    }

}
