/**
 * <code>package-info</code>.
 * 腾讯云推荐接入
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/13 10:30
 */
package com.gionee.bigdata.recommender.tencent;
