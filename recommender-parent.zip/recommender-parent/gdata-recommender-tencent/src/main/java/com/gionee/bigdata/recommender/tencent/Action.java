package com.gionee.bigdata.recommender.tencent;

/**
 * <code>Action</code>.
 * 行为定义
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/14 11:37
 */
public enum Action {
    /**
     * 曝光
     */
    visit(101, "非详情页访问点击曝光"),
    /**
     * 点击
     */
    detail(102, "详情页访问"),
    /**
     * 下载
     */
    startdl(103, "详情页访问"),
    /**
     * 关注
     */
    favor(104, "详情页访问"),
    /**
     * 购买
     */
    createordersuc(105, "详情页访问");

    /**
     * 编码
     */
    private final int code;
    /**
     * 说明
     */
    private final String msg;

    /**
     * 构造函数
     *
     * @param code 略
     * @param msg  略
     */
    Action(final int code, final String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

}
