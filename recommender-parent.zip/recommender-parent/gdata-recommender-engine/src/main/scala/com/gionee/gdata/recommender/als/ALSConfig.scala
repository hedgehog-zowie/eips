package com.gionee.gdata.recommender.als

/**
 * <code>ALSConfig</code>.
 * ALS相关配置项
 * @author zweig
 * version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:15
 */
object ALSConfig {

  // spark配置项
  /**
    * 程序名
    */
  val SPARK_NAME_CONFIG = "spark.name"
  /**
    * spark master地址
    */
  val SPARK_MASTER_CONFIG = "spark.master"

  // 模型调优参数
  /**
    * 特征数
    */
  val RANKS_CONFIG = "als.ranks"
  /**
    * 迭代次数
    */
  val ITERATIONS_CONFIG = "als.iterations"
  /**
    * 正规化因子
    */
  val LAMBDAS_CONFIG = "als.lambdas"
  /**
    * 用户block个数
    */
  val USER_BLOCKS_CONFIG = "als.userBlocks"
  /**
    * 物品block个数
    */
  val ITEM_BLOCKS_CONFIG = "als.itemBlocks"
  /**
    * 分区个数
    */
  val PARTITIONS_CONFIG = "als.partitions"

  // 业务参数
  /**
    * 评分表查询sql
    */
  val SCORE_SQL_CONFIG = "als.hive.score.sql"
  /**
    * 模型保存路径
    */
  val MODEL_PATH_CONFIG = "als.model.path"
  /**
    * 用户表，用户与ID对应表
    */
  val USER_ID_TABLE_CONFIG = "als.hive.user.table"
  /**
    * 物品表，物品与ID对应表
    */
  val ITEM_ID_TABLE_CONFIG = "als.hive.item.table"
  /**
    * 待推荐物品查询sql
    */
  val ITEM_SQL_CONFIG = "als.hive.item.sql"
  /**
    * 是否保存结果到hive
    */
  val SAVE_TO_HIVE_CONFIG = "als.save.hive"
  /**
    * 推荐结果表
    */
  val RESULT_TABLE_CONFIG = "als.hive.result.table"
  /**
    * 预测批处理user个数
    */
  val BATCH_CONFIG = "als.predict.batch"
  /**
    * 每用户推荐结果个数
    */
  val RESULT_SIZE_CONFIG = "als.recommend.result.size"
  /**
    * 每个块数据条数
    */
  val BLOCK_SIZE_CONFIG = "als.recommend.block.size"
  /**
    * 用户分区个数
    */
  val USER_PARTITIONS_CONFIG = "als.recommend.user.partitions"
  /**
    * 物品分区分数
    */
  val ITEM_PARTITIONS_CONFIG = "als.recommend.item.partitions"
  /**
    * 是否保存结果到HBase
    */
  val SAVE_TO_HBASE_CONFIG = "als.save.hbase"
  // hbase配置
  val ZK_QUORUM_CONFIG = "als.hbase.zkQuorum"
  val ZK_PORT_CONFIG = "als.hbase.zkPort"
  val HBASE_RESULT_TABLE_CONFIG = "als.hbase.result.tableName"
  val HBASE_RESULT_CF_CONFIG = "als.hbase.result.cf"
}

/**
  * ALS评估配置项
  */
object ALSEvaluateConfig {

  /**
    * 特征数
    */
  val RANKS_CONFIG = "ranks"
  /**
    * 迭代次数
    */
  val ITERATIONS_CONFIG = "iterations"
  /**
    * 正规化因子
    */
  val LAMBDAS_CONFIG = "lambdas"
  /**
    * 用户block个数
    */
  val USER_BLOCKS_CONFIG = "userBlocks"
  /**
    * 物品block个数
    */
  val ITEM_BLOCKS_CONFIG = "itemBlocks"
  /**
    * 样本条数
    */
  val SAMPLES_CONFIG = "samples"

}

/**
  * 常量定义
  */
object ALSConstants {
  val USER_COLUMN_NAME: String = "user"
  val USER_ID_COLUMN_NAME: String = "userId"
  val ITEM_COLUMN_NAME: String = "item"
  val ITEM_ID_COLUMN_NAME: String = "itemId"
  val RATING_COLUMN_NAME: String = "rating"
  val PREDICTION_COLUMN_NAME: String = "prediction"
  val RESULT_COLUMN_NAME: String = "result"
}

/**
  * ALS参数配置
  *
  * @param conf
  */
case class ALSParams(conf: String = null)


/**
  * 用户物品评分类
  *
  * @param user
  * @param userId
  * @param item
  * @param itemId
  * @param rating
  */
case class UserItemRating(user: String, userId: Int, item: String, itemId: Int, rating: Double)
