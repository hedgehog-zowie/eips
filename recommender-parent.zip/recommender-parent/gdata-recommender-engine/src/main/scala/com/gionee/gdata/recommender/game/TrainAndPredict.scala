package com.gionee.gdata.recommender.game

import java.text.SimpleDateFormat

import com.gionee.gdata.common.ConfigLoader
import com.gionee.gdata.recommender.game
import org.apache.log4j.Logger
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
 * <code>TrainAndPredict</code>.
 * 训练模型并预测结果
 * @author zweig
 * version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:18
 */
object TrainAndPredict {

  val logger = Logger.getLogger(TrainAndPredict.getClass)

  def main(args: Array[String]) {
    var props = ConfigLoader.load(ConfigConstants.CONFIG_FILE)
    var gameProps = ConfigLoader.load(GameConfigConstants.CONFIG_FILE)

    val defaultParams = GameParams()
    val parser = new OptionParser[GameParams]("") {
      head("Boot recommender", "1.0")
      opt[String]('c', "conf")
        .valueName("config-file-path")
        .text(s"配置文件，若不配置，则使用默认的配置文件")
        .action { (x, c) => c.copy(conf = x) }
      opt[String]('g', "gameConf")
        .valueName("game-config-file-path")
        .text(s"游戏推荐配置文件，若不配置，则使用默认的配置文件")
        .action { (x, c) => c.copy(gameConf = x) }
      opt[String]('d', "date")
        .required()
        .valueName("<date>")
        .text(s"日期，必选，日期格式必须是 yyyy-MM-dd")
        .action { (x, c) => c.copy(date = x) }
        .validate { x =>
          try {
            new SimpleDateFormat("yyyy-MM-dd").parse(x)
            success
          } catch {
            case ex: Exception => failure("日期格式必须是 yyyy-MM-dd")
          }
        }
      help("help").text("prints this usage text")
    }

    var date: String = ""
    parser.parse(args, defaultParams) match {
      case Some(params) => {
        date = params.date
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
        if (params.gameConf != null)
          gameProps = ConfigLoader.load(params.gameConf)
      }
      case None => System.exit(1)
    }
    date = new SimpleDateFormat("yyyyMMdd").format(new SimpleDateFormat("yyyy-MM-dd").parse(date))

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")
    val gamePropsStr = gameProps.toString
    logger.info(s"game配置信息：$gamePropsStr")

    val sparkConf = new SparkConf().
      setAppName(props.getProperty(ConfigConstants.SPARK_NAME_CONFIG)).
      setMaster(props.getProperty(ConfigConstants.SPARK_MASTER_CONFIG)).
      set("spark.ui.port", props.getProperty(ConfigConstants.SPARK_UI_PORT_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)

    // init game train
    game.TrainModel.init(sc, gameProps)
    game.TrainModel.train(date)

    // init game prediction
    game.PredictRating.init(sc, gameProps)
    game.PredictRating.predictBatch(date)

  }

}
