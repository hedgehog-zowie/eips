package com.gionee.gdata.recommender.game

import java.util.Properties

import com.gionee.gdata.common.ConfigLoader
import com.gionee.gdata.common.utils.MySqlUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
 * <code>SavePredictRating</code>.
 * 预测评分
 * @author zweig
 * version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:17
 */
object SavePredictRating {

  val logger = Logger.getLogger(SavePredictRating.getClass)

  var sc: SparkContext = _
  var hiveContext: HiveContext = _
  var gameTableInHive: String = _
  val top = 10;
  var resultMysql: MySqlUtil = _
  var mysqlResultTable: String = _

  case class SavePredictRatingParams(conf: String = null, gameConf: String = null, tableName: String = null)

  def init(sc: SparkContext, props: Properties): Unit = {
    // hive中保存的游戏数据表
    this.gameTableInHive = props.getProperty(GameConfigConstants.TABLE_IN_HIVE_CONFIG, "dlv_game_recommend_rating_his")

    // spark配置上下文
    this.sc = sc
    this.hiveContext = new HiveContext(sc)

    // 保存结果的MYSQL
    this.resultMysql = MySqlUtil.getInstance(sc, props.getProperty(GameConfigConstants.RESULT_MYSQL_URL_CONFIG))
    // 保存在MYSQL中的结果表名
    this.mysqlResultTable = props.getProperty(GameConfigConstants.MYSQL_RESULT_TABLE_CONFIG, "dlv_game_recommend_mid")
  }

  /**
    * 将结果保存至mysql
    *
    * @param tmpTable
    * @param saveMode
    */
  private def saveToMysql(tmpTable: String, saveMode: SaveMode): Unit = {
    // 将结果的多行转成一行，并保存到mysql
    //    val resultDf = hiveContext.sql(s"select imei, concat_ws(',',collect_list(cast(gameid as string))) game_ids from $tmpTable group by imei")
    // 按IMEI分组排序，并取出前10位的
    val rankSql = s"SELECT * FROM (" +
      s"SELECT t.imei, t.gameid, t.prediction, row_number () over (PARTITION BY t.imei ORDER BY t.prediction DESC) AS rank " +
      s"FROM (" +
      s"SELECT t1.imei, t1.gameid, t1.prediction " +
      s"FROM $tmpTable t1 " +
      s"LEFT JOIN $gameTableInHive t2 " +
      s"ON t1.imei = t2.imei AND t1.gameid = t2.game_id " +
      s"WHERE t2.game_id IS NULL" +
      s") t " +
      s") r WHERE r.rank <= $top"
    val resultDf = hiveContext.sql(s"select mr.imei, concat_ws(',',collect_list(cast(mr.gameid as string))) game_ids " +
      s"from ($rankSql) mr " +
      s"group by mr.imei").persist(StorageLevel.MEMORY_AND_DISK)
    // 保存结果到mysql
    resultMysql.writeTable(resultDf, mysqlResultTable, saveMode)
    resultDf.unpersist(true)
  }

  def main(args: Array[String]) {
    var props = ConfigLoader.load(ConfigConstants.CONFIG_FILE)
    var gameProps = ConfigLoader.load(GameConfigConstants.CONFIG_FILE)

    val defaultParams = SavePredictRatingParams()
    val parser = new OptionParser[SavePredictRatingParams]("") {
      head("PredictRating", "1.0")
      opt[String]('c', "conf")
        .valueName("config-file-path")
        .text(s"配置文件，若不配置，则使用默认的配置文件")
        .action { (x, c) => c.copy(conf = x) }
      opt[String]('g', "gameConf")
        .valueName("game-config-file-path")
        .text(s"游戏推荐配置文件，若不配置，则使用默认的配置文件")
        .action { (x, c) => c.copy(gameConf = x) }
      opt[String]('t', "tableName")
        .required()
        .valueName("<tableName>")
        .text(s"Hive临时结果表名")
        .action { (x, c) => c.copy(tableName = x) }
      help("help").text("prints this usage text")
    }

    var tableName: String = ""
    parser.parse(args, defaultParams) match {
      case Some(params) => {
        tableName = params.tableName
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
        if (params.gameConf != null)
          gameProps = ConfigLoader.load(params.gameConf)
      }
      case None => System.exit(1)
    }

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")
    val gamePropsStr = gameProps.toString
    logger.info(s"game配置信息：$gamePropsStr")

    val sparkConf = new SparkConf()
      .setAppName("SavePredictRating")
      .setMaster(props.getProperty(ConfigConstants.SPARK_MASTER_CONFIG))
      .set("spark.ui.port", props.getProperty(ConfigConstants.SPARK_UI_PORT_CONFIG))
      .set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)

    init(sc, gameProps)
    saveToMysql(tableName, SaveMode.Append);

    sc.stop()
  }

}
