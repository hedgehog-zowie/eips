package com.gionee.gdata.recommender.game

import java.text.SimpleDateFormat
import java.util.Properties

import com.gionee.gdata.common.ConfigLoader
import com.gionee.gdata.common.utils.MySqlUtil
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.ml.recommendation._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.{DataFrame, Row, SaveMode}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

import scala.concurrent.Lock

/**
 * <code>PredictRating</code>.
 * 预测评分
 * @author zweig
 * version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:16
 */
object PredictRating {

  val logger = Logger.getLogger(PredictRating.getClass)
  /**
    * 模型路径
    */
  var gameModelPath: String = _

  var sc: SparkContext = _
  var hiveContext: HiveContext = _
  var model: ALSModel = _

  // 批处理条数
  var batch: Int = _
  val batchDefault = 10

  // 每个用户推荐的游戏数量
  val top: Int = 10

  // 效率测试
  var test: Boolean = _

  // hive中保存的游戏数据表
  var gameTableInHive: String = _
  // 写到HIVE中的临时结果表
  var tmpResultTable: String = _

  // 写入结果数据的MYSQL数据库
  var resultMysql: MySqlUtil = _
  // mysql结果表
  var mysqlResultTable: String = _
  // 查询游戏ID等数据的MYSQL数据库
  var queryMysql: MySqlUtil = _
  // 查找待预测评分游戏ID的表名
  var gameIdTableName: String = _

  val batchLock: Lock = new Lock
  val byGameListLock: Lock = new Lock
  val byGameLock: Lock = new Lock
  val byUserLock: Lock = new Lock
  // 操作临时表的锁
  val tmpTableLock: Lock = new Lock
  // 创建和删除临时表的锁
  val createAndDropLock: Lock = new Lock

  def init(sc: SparkContext, props: Properties): Unit = {
    // hive中保存的游戏数据表
    this.gameTableInHive = props.getProperty(GameConfigConstants.TABLE_IN_HIVE_CONFIG, "dlv_game_recommend_rating_his")
    // 模型保存路径
    this.gameModelPath = props.getProperty(GameConfigConstants.MODEL_PATH_CONFIG, "/data/spark/data/game/model")
    // 保存在HIVE中的临时结果表名
    this.tmpResultTable = props.getProperty(GameConfigConstants.TMP_RESULT_TABLE_CONFIG, "game_predict_tmp_result")
    // 保存结果的MYSQL
    this.resultMysql = MySqlUtil.getInstance(sc, props.getProperty(GameConfigConstants.RESULT_MYSQL_URL_CONFIG))
    // 保存在MYSQL中的结果表名
    this.mysqlResultTable = props.getProperty(GameConfigConstants.MYSQL_RESULT_TABLE_CONFIG, "dlv_game_recommend_mid")
    // 查询游戏数据的MYSQL
    this.queryMysql = MySqlUtil.getInstance(sc, props.getProperty(GameConfigConstants.QUERY_MYSQL_URL_CONFIG))
    // 查找待预测评分游戏ID的表
    this.gameIdTableName = props.getProperty(GameConfigConstants.MYSQL_QUERY_GAME_ID_TABLE_CONFIG, "dlv_gamec_recommend_ids")

    // spark配置上下文
    this.sc = sc
    this.hiveContext = new HiveContext(sc)
    // 加载模型
    this.model = ALSModel.load(gameModelPath)
    // 批量预测条数
    this.batch = props.getProperty(GameConfigConstants.BATCH_CONFIG, batchDefault.toString).toInt
    // 是否是测试效率
    this.test = props.getProperty(GameConfigConstants.TEST_CONFIG, "false").toBoolean
    logger.info(s"PredictRating init, 批量预测条数：$batch")
  }

  /**
    * 批量预测，临时表不可变
    *
    * @param date
    */
  def predictBatch(date: String): Unit = {
    batchLock.acquire()

    // 从Hive中获取需要预测评分的用户ID、IMEI
    val users = findUserFromHive(date).persist(StorageLevel.MEMORY_AND_DISK)
    val userArray = users.collect()
    val numUsers = userArray.length
    if (numUsers == 0) {
      logger.warn(s"用户数为0，不预测评分。")
      return
    }
    logger.info(s"用户数：$numUsers")
    // 从Hive中获取需要预测评分的游戏ID
    // val gameIds = findGameFromHive(date).persist(StorageLevel.MEMORY_AND_DISK)
    // 从MySql中获取需要预测评分的游戏ID
    val gameIds = findGameFromMysql().persist(StorageLevel.MEMORY_AND_DISK)
    val numGames = gameIds.count()
    if (numGames == 0) {
      logger.warn(s"游戏数为0，不预测评分。")
      return
    }
    logger.info(s"游戏数：$numGames")

    val bUsers = sc.broadcast(userArray)
    predict(bUsers, gameIds)
    users.unpersist(true)
    gameIds.unpersist(true)

    batchLock.release()
  }

  /**
    * 根据指定游戏列表预测评分
    *
    * @param gameList
    * @param date
    */
  def predictByGameList(gameList: Array[Int], date: String): Unit = {
    byGameListLock.acquire()

    // 创建临时表
    val tableName = prepareTmpTable()

    // 从Hive中获取需要预测评分的用户ID、IMEI
    val users = findUserFromHive(date).persist(StorageLevel.MEMORY_AND_DISK)
    val userArray = users.collect()
    val numUsers = userArray.length
    if (numUsers == 0) {
      logger.warn(s"用户数为0，不预测评分。")
      return
    }
    logger.info(s"用户数：$numUsers")
    val games = sc.parallelize(gameList).persist(StorageLevel.MEMORY_AND_DISK)
    if (games.count() == 0) {
      logger.warn(s"游戏数为0，不预测评分。")
      return
    }

    val bUsers = sc.broadcast(userArray)
    predict(bUsers, games)
    users.unpersist(true)
    games.unpersist(true)

    byGameListLock.release()
  }

  /**
    * 根据指定游戏预测评分
    *
    * @param gameId
    * @param date
    */
  def predictByGame(gameId: Int, date: String): Unit = {
    byGameLock.acquire()
    // 创建临时表
    val tableName = prepareTmpTable()

    val users = findUserFromHive(date).persist(StorageLevel.MEMORY_AND_DISK)
    val numUsers = users.count()
    if (numUsers == 0) {
      logger.warn(s"用户数为0，不预测评分。")
      return
    }
    logger.info(s"用户数：$numUsers")
    val gameIds = sc.parallelize(List(gameId))
    val userGames = users.cartesian(gameIds).map {
      case ((userId, imei), gameId) =>
        TrainModel.UserGameRating(userId, imei, gameId, 0)
    }.persist(StorageLevel.MEMORY_AND_DISK)
    val predictions = predict(userGames)
    // 保存结果到临时表
    predictions.write.mode(SaveMode.Append).saveAsTable(tableName)
    predictions.unpersist(true)

    // 获取临时表锁，以免在使用时被修改
    tmpTableLock.acquire()
    // 删除旧数据
    resultMysql.exec(s"TRUNCATE TABLE $mysqlResultTable")
    // 从完整的结果表中取出除gameid之外的数据，联合该gameid的临时表，将结果多行转成一行，并保存到mysql
    saveToMysql(s"(select * from $tableName union all select * from $tmpResultTable where gameid <> $gameId)", SaveMode.Append)
    // 修改字段类型
    // resultMysql.exec(s"ALTER TABLE $mysqlResultTable MODIFY COLUMN IMEI VARCHAR(31)")
    tmpTableLock.release()

    userGames.unpersist(true)
    users.unpersist(true)
    dropTmpTable(tableName)
    byGameLock.release()
  }

  /**
    * 根据指定用户评分
    *
    * @param imei
    * @param date
    */
  def predictByUser(imei: String, date: String): Unit = {
    byUserLock.acquire()
    // 创建临时表
    val tableName = prepareTmpTable()
    val users = findUserFromHive(date, imei).persist(StorageLevel.MEMORY_AND_DISK)
    val numUsers = users.count()
    if (numUsers == 0) {
      logger.warn(s"未找到用户，IMEI = $imei，不预测评分。")
      return
    }
    logger.info(s"用户数：$numUsers")
    // 从Hive中获取需要预测评分的游戏ID
    // val gameIds = findGameFromHive(date).persist(StorageLevel.MEMORY_AND_DISK)
    // 从MySql中获取需要预测评分的游戏ID
    val gameIds = findGameFromMysql().persist(StorageLevel.MEMORY_AND_DISK)
    val numGames = gameIds.count()
    if (numGames == 0) {
      logger.warn(s"游戏数为0，不预测评分。")
      return
    }
    logger.info(s"游戏数：$numGames")
    val userGames = users.cartesian(gameIds).map {
      case ((userId, imei), gameId) =>
        TrainModel.UserGameRating(userId, imei, gameId, 0)
    }.persist(StorageLevel.MEMORY_AND_DISK)
    val predictions = predict(userGames)
    // 保存结果到临时表
    predictions.write.mode(SaveMode.Append).saveAsTable(tableName)
    predictions.unpersist(true)

    // 删除旧数据
    resultMysql.execUpdate(s"delete from $mysqlResultTable where imei = $imei")
    saveToMysql(tableName, SaveMode.Append)

    userGames.unpersist(true)
    users.unpersist(true)
    gameIds.unpersist(true)
    dropTmpTable(tableName)
    byUserLock.release()
  }

  private def predict(bUsers: Broadcast[Array[(Int, String)]], games: RDD[Int]): Unit = {
    // 广播users
    // val bUsers = sc.broadcast(users.collect())

    // 创建临时表
    val tableName = prepareTmpTable()

    var gameList: List[Int] = List()
    games.collect().foreach {
      gameId => {
        gameList = gameList ++ List(gameId)
        val size = gameList.size
        if (size == batch) {
          run()
          if (test)
            batch += batch
        }
      }
    }
    run()

    def run(): Unit = {
      val numGames = gameList.size
      if (numGames != 0) {
        logger.info(s"批量预测评分, 游戏数量: $numGames")
        // 广播游戏id
        val bBatchGames = sc.broadcast(gameList);
        val userGames = sc.parallelize(bUsers.value).cartesian(sc.parallelize(bBatchGames.value, 1)).map {
          case ((userId, imei), gameId) =>
            TrainModel.UserGameRating(userId, imei, gameId, 0)
        }.persist(StorageLevel.MEMORY_AND_DISK)
        // 预测评分
        val predictions = predict(userGames)
        val startTime = System.currentTimeMillis()
        // 保存结果，追加
        predictions.write.mode(SaveMode.Append).saveAsTable(tableName)
        predictions.unpersist(true)

        val endTime = System.currentTimeMillis()
        val time = (endTime - startTime) / 1000
        logger.info(s"保存结果完成，批量数：$batch，耗时：$time s")

        userGames.unpersist(true)
      }
      // 清空list
      gameList = List()
    }

    // 删除旧数据
    resultMysql.exec(s"TRUNCATE TABLE $mysqlResultTable")
    // 保存至mysql
    saveToMysql(tableName, SaveMode.Append)
    // 修改字段类型
    // resultMysql.exec(s"ALTER TABLE $mysqlResultTable MODIFY COLUMN IMEI VARCHAR(31)")

    tmpTableLock.acquire()
    // 修改临时表名，不可变
    hiveContext.sql(s"DROP TABLE IF EXISTS $tmpResultTable")
    hiveContext.sql(s"ALTER TABLE $tableName RENAME TO $tmpResultTable")
    tmpTableLock.release()

    dropTmpTable(tableName)
  }

  /**
    * 预测评分
    *
    * @param userGames
    * @return
    */
  private def predict(userGames: RDD[TrainModel.UserGameRating]): DataFrame = {
    val startTime = System.currentTimeMillis()
    //    val result = model.transform(hiveContext.createDataFrame(userGames)).
    //      select("userId", "imei", "gameId", "prediction").
    //      orderBy("userId", "prediction")
    val hc = new HiveContext(sc)
    import hc.implicits._
    val result = model.transform(userGames.toDF()).
      select($"userId", $"imei", $"gameId", $"prediction").
      orderBy($"userId".asc, $"prediction".desc).persist(StorageLevel.MEMORY_AND_DISK)
    val count = result.count()
    val endTime = System.currentTimeMillis()
    val time = (endTime - startTime) / 1000
    logger.info(s"预测完成，批量数：$batch，结果数量：$count，耗时：$time s")
    //    logger.info(s"预测完成，批量数：$batch")
    result
  }

  /**
    * 从Hive中获取需要预测评分的用户ID、IMEI
    *
    * @return
    */
  private def findUserFromHive(date: String): RDD[(Int, String)] = {
    hiveContext.sql(s"SELECT distinct(user_id) userId, imei FROM $gameTableInHive where day_id = $date")
      .map {
        case Row(userId: Long, imei: String) =>
          (userId.toInt, imei)
      }
  }

  private def findUserFromHive(date: String, imei: String): RDD[(Int, String)] = {
    val users: RDD[(Int, String)] =
      hiveContext.sql(s"SELECT user_id userId, imei from $gameTableInHive where day_id = $date and imei = '$imei' group by user_id, imei")
        .map {
          case Row(userId: Long, imei: String) =>
            (userId.toInt, imei)
        }
    val numUsers = users.count()
    logger.info(s"用户数：$numUsers")
    users
  }

  /**
    * 从MYSQL数据库中查找游戏ID
    *
    * @return
    */
  private def findGameFromMysql(): RDD[Int] = {
    queryMysql.loadTable(gameIdTableName).map {
      case Row(gameId: String) => gameId.trim.toInt
    }
  }

  /**
    * 从文件中获取游戏ID
    *
    * @return
    */
  private def findGameFromFile(): RDD[Int] = {
    val gameIds = sc.textFile("game_id.txt").map(_.trim.toInt)
    val numGames = gameIds.count()
    logger.info(s"游戏数：$numGames")
    gameIds
  }

  /**
    * 从Hive中获取需要预测评分的游戏ID
    *
    * @return
    */
  private def findGameFromHive(date: String): RDD[Int] = {
    // todo update 200
    val gameIds = hiveContext.sql(s"SELECT distinct(game_id) gameId from $gameTableInHive where day_id = $date limit 200")
      .map {
        case Row(gameId: String) =>
          gameId.toInt
      }
    val numGames = gameIds.count()
    logger.info(s"游戏数：$numGames")
    gameIds
  }

  /**
    * 将结果保存至mysql
    *
    * @param tmpTable
    * @param saveMode
    */
  private def saveToMysql(tmpTable: String, saveMode: SaveMode): Unit = {
    // 将结果的多行转成一行，并保存到mysql
    //    val resultDf = hiveContext.sql(s"select imei, concat_ws(',',collect_list(cast(gameid as string))) game_ids from $tmpTable group by imei")
    // 按IMEI分组排序，并取出前10位的
    val rankSql = s"SELECT * FROM (" +
      s"SELECT t.imei, t.gameid, t.prediction, row_number () over (PARTITION BY t.imei ORDER BY t.prediction DESC) AS rank " +
      s"FROM (" +
      s"SELECT t1.imei, t1.gameid, t1.prediction " +
      s"FROM $tmpTable t1 " +
      s"LEFT JOIN $gameTableInHive t2 " +
      s"ON t1.imei = t2.imei AND t1.gameid = t2.game_id " +
      s"WHERE t2.game_id IS NULL" +
      s") t " +
      s") r WHERE r.rank <= $top"
    val resultDf = hiveContext.sql(s"select mr.imei, concat_ws(',',collect_list(cast(mr.gameid as string))) game_ids " +
      s"from ($rankSql) mr " +
      s"group by mr.imei").persist(StorageLevel.MEMORY_AND_DISK)
    // 保存结果到mysql
    resultMysql.writeTable(resultDf, mysqlResultTable, saveMode)
    resultDf.unpersist(true)
  }

  /**
    * 准备临时表
    *
    * @return
    */
  private def prepareTmpTable(): String = {
    createAndDropLock.acquire()
    val tableName = tmpResultTable + "_" + System.currentTimeMillis()
    hiveContext.sql(s"CREATE TABLE $tableName(userid INT, imei STRING, gameid INT, prediction DOUBLE) stored AS parquet")
    createAndDropLock.release()
    tableName
  }

  /**
    * 删除临时表
    *
    * @param tableName
    */
  private def dropTmpTable(tableName: String): Unit = {
    createAndDropLock.acquire()
    hiveContext.sql(s"DROP TABLE IF EXISTS $tableName")
    createAndDropLock.release()
  }

  def main(args: Array[String]) {
    var props = ConfigLoader.load(ConfigConstants.CONFIG_FILE)
    var gameProps = ConfigLoader.load(GameConfigConstants.CONFIG_FILE)

    val defaultParams = GameParams()
    val parser = new OptionParser[GameParams]("") {
      head("PredictRating", "1.0")
      opt[String]('c', "conf")
        .valueName("config-file-path")
        .text(s"配置文件，若不配置，则使用默认的配置文件")
        .action { (x, c) => c.copy(conf = x) }
      opt[String]('g', "gameConf")
        .valueName("game-config-file-path")
        .text(s"游戏推荐配置文件，若不配置，则使用默认的配置文件")
        .action { (x, c) => c.copy(gameConf = x) }
      opt[String]('d', "date")
        .required()
        .valueName("<date>")
        .text(s"日期，必选，日期格式必须是 yyyy-MM-dd")
        .action { (x, c) => c.copy(date = x) }
        .validate { x =>
          try {
            new SimpleDateFormat("yyyy-MM-dd").parse(x)
            success
          } catch {
            case ex: Exception => failure("日期格式必须是 yyyy-MM-dd")
          }
        }
      help("help").text("prints this usage text")
    }

    var date: String = ""
    parser.parse(args, defaultParams) match {
      case Some(params) => {
        date = params.date
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
        if (params.gameConf != null)
          gameProps = ConfigLoader.load(params.gameConf)
      }
      case None => System.exit(1)
    }
    date = new SimpleDateFormat("yyyyMMdd").format(new SimpleDateFormat("yyyy-MM-dd").parse(date))

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")
    val gamePropsStr = gameProps.toString
    logger.info(s"game配置信息：$gamePropsStr")

    val sparkConf = new SparkConf().
      setAppName("PredictRating").
      setMaster(props.getProperty(ConfigConstants.SPARK_MASTER_CONFIG)).
      set("spark.ui.port", props.getProperty(ConfigConstants.SPARK_UI_PORT_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)

    init(sc, gameProps)
    predictBatch(date)

    sc.stop()
  }

}
