package com.gionee.gdata.recommender.lr

import java.text.SimpleDateFormat
import java.util.{Date, Properties}

import com.gionee.gdata.common.ConfigLoader
import com.gionee.gdata.common.utils.MySqlUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.mllib.classification.LogisticRegressionModel
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.optimization.{LBFGS, LogisticGradient, SquaredL2Updater}
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.util.MLUtils
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SQLContext, SaveMode}
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
  * <code>Train</code>.
  * 训练模型
  *
  * @author taylor
  *         version: 1.0-SNAPSHOT
  *         date: 2017/6/9 18:19
  */
object Train {

  /**
    * 日志记录器
    */
  val logger = Logger.getLogger(this.getClass)

  // Spark上下文
  var sc: SparkContext = _
  var hiveContext: HiveContext = _

  // 模型参数
  /**
    * 随机种子
    */
  var randomSeed: Int = _
  /**
    * 训练集切割百分比
    */
  var splitProportion: Double = _
  /**
    * 容忍次数
    */
  var lbfgsNumCorrections: Int = _
  /**
    * 容忍阀值
    */
  var lbfgsConvergenceTol: Double = _
  /**
    * 迭代次数
    */
  var lbfgsNumIterations: Int = _
  /**
    * 正交因子
    */
  var lbfgsRegParam: Double = _

  // 业务参数
  /**
    * 训练集查询sql
    */
  var trainSql: String = _
  /**
    * 测试集结果表
    */
  var testResultTable: String = _
  /**
    * MySql地址
    */
  var mysqlUrl: String = _
  /**
    * 模型效果保存表名
    */
  var modelEvaluateTable: String = _
  /**
    * 模型文件保存路径
    */
  var modelPath: String = _
  /**
    * 程序运行时间记录
    */
  var dateTime: String = _

  /**
    * 初始化
    *
    * @param sc
    * @param hiveContext
    * @param props
    */
  def init(sc: SparkContext, hiveContext: HiveContext, props: Properties): Boolean = {

    // 上下文配置项
    this.sc = sc
    this.hiveContext = hiveContext

    // 业务配置项
    this.trainSql = props.getProperty(LRConfig.TRAIN_SQL_CONFIG)
    if (StringUtils.isBlank(this.trainSql)) {
      logger.error("训练集查询SQL必须配置")
      return false
    }
    this.testResultTable = props.getProperty(LRConfig.TEST_RESULT_TABLE)
    if (StringUtils.isBlank(this.testResultTable)) {
      logger.error("测试集结果表名必须配置")
      return false
    }
    this.mysqlUrl = props.getProperty(LRConfig.MYSQL_URL)
    if (StringUtils.isBlank(this.mysqlUrl)) {
      logger.error("模型效果保存MySql URL 地址必须配置")
      return false
    }
    this.modelEvaluateTable = props.getProperty(LRConfig.MYSQL_TABLE)
    if (StringUtils.isBlank(this.modelEvaluateTable)) {
      logger.error("模型效果保存MySql表必须配置")
      return false
    }
    this.modelPath = props.getProperty(LRConfig.MODEL_PATH_CONFIG)
    if (StringUtils.isBlank(this.modelPath)) {
      logger.error("模型保存路径必须配置")
      return false
    }

    // 模型配置项
    this.randomSeed = props.getProperty(LRConfig.RANDOM_SEED, "5").toInt
    this.splitProportion = props.getProperty(LRConfig.SPLIT_PROPORTION, "0.7").toDouble
    this.lbfgsNumCorrections = props.getProperty(LRConfig.LBFGS_NUM_CORRECTIONS, "10").toInt
    this.lbfgsConvergenceTol = props.getProperty(LRConfig.LBFGS_CONVERGENCE_TOL, "0.00001").toDouble
    this.lbfgsNumIterations = props.getProperty(LRConfig.LBFGS_NUM_ITERATIONS, "100").toInt
    this.lbfgsRegParam = props.getProperty(LRConfig.LBFGS_REG_PARAM, "0.0").toDouble

    // 程序运行时间记录
    this.dateTime = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date())

    true
  }

  /**
    * 训练LR模型并保存结果
    *
    */
  def train(): Unit = {

    // 数据集切分
    val Array(trainData, testData) = hiveContext.sql(trainSql).rdd.map {
      case Row(flag: String, feature: String) =>
        LabeledPoint(flag.toDouble, Vectors.dense(feature.split(LRConstants.SPLITTER_BETWEEN_FEATURES).map(_.toDouble)))
    }.randomSplit(Array(splitProportion, 1 - splitProportion), seed = randomSeed)

    // 训练模型数据增加偏倚
    val trainData1 = trainData.map { case LabeledPoint(label, features) =>
      (label, MLUtils.appendBias(features))
    }

    trainData.cache()
    trainData1.cache()
    testData.cache()

    // 使用LBFGS优化算法训练LR模型
    val startTime = System.currentTimeMillis()
    val initialWeightsWithIntercept = Vectors.dense(new Array[Double](trainData.first().features.size + 1))
    val (weightsWithIntercept, _) = LBFGS.runLBFGS(
      trainData1, // 使用偏倚的训练集进行模型训练
      new LogisticGradient(), new SquaredL2Updater(), // 使用Logistic梯度计算和L2更新权重
      lbfgsNumCorrections, lbfgsConvergenceTol, lbfgsNumIterations, lbfgsRegParam, initialWeightsWithIntercept)
    val model = new LogisticRegressionModel(
      Vectors.dense(weightsWithIntercept.toArray.slice(0, weightsWithIntercept.size - 1)),
      weightsWithIntercept(weightsWithIntercept.size - 1)
    ).clearThreshold()
    val endTime = System.currentTimeMillis()
    val duration = endTime - startTime

    // 训练出来的LR模型进行保存
    model.save(sc, modelPath)
    logger.info(s"LR模型训练完成，并保存到HDFS路径下：$modelPath")

    // 对测试集进行模型预测，结果保存在Hive表中
    val scoreAndLabels = testData.map { point =>
      val score = model.predict(point.features)
      (score, point.label)
    }
    val testDataResult = scoreAndLabels.map { line =>
      Record(line._1.toString, line._2.toString)
    }
    hiveContext.implicits
      .rddToDataFrameHolder(testDataResult).toDF() // RDD转DataFrame
      .write.mode(SaveMode.Overwrite).saveAsTable(testResultTable)
    logger.info(s"对测试集进行预测，保存结果在Hive表：$testResultTable")

    // 根据测试集预测出来的结果，计算模型评估指标PR和AUC
    val metrics = new BinaryClassificationMetrics(scoreAndLabels)
    val evaluate = sc.parallelize(Array((
      randomSeed.toString, splitProportion.toString,
      lbfgsNumCorrections.toString, lbfgsConvergenceTol.toString, lbfgsNumIterations.toString, lbfgsRegParam.toString,
      metrics.areaUnderPR().toString, metrics.areaUnderROC().toString, duration.toString, dateTime)) // 评估指标PR和AUC
    ).map(parts => Row(parts._1, parts._2, parts._3, parts._4, parts._5, parts._6, parts._7, parts._8, parts._9, parts._10))

    // 模型效果评估指标保存到MySql表中
    val schemaArray = Array(LRConstants.RANDOM_SEED, LRConstants.SPLIT_PERCENT,
      LRConstants.NUM_CORRECTIONS, LRConstants.CONVERGENCE_TOL, LRConstants.NUM_ITERATIONS, LRConstants.REG_PARAM,
      LRConstants.AREA_UNDER_PR, LRConstants.AREA_UNDER_ROC, LRConstants.DURATION, LRConstants.DATE_TIME) // MySql表中的字段
    val fields = schemaArray.map(fieldName =>
      StructField(fieldName, StringType, nullable = true))
    val evaluateDataFrame = new SQLContext(sc).createDataFrame(evaluate, StructType(fields))
    val mySqlTool = MySqlUtil.getInstance(sc, mysqlUrl)
    mySqlTool.writeTable(evaluateDataFrame, modelEvaluateTable, SaveMode.Append)
    logger.info(s"模型效果评估数据保存到MySql表中：$modelEvaluateTable")

    trainData.unpersist(true)
    trainData1.unpersist(true)
    testData.unpersist(true)
  }

  def main(args: Array[String]) {

    val defaultParams = LRParams()
    val parser = new OptionParser[LRParams]("") {
      head("LR train", "1.0")
      opt[String]('c', "conf")
        .valueName("config-file-path")
        .text(s"配置文件，必选")
        .action {
          (x, c) => c.copy(conf = x)
        }
      help("help").text("prints this usage text")
    }

    var props: Properties = null
    parser.parse(args, defaultParams) match {
      case Some(params) =>
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
      case None => System.exit(-1)
    }

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")

    val sparkConf = new SparkConf().
      setAppName(props.getProperty(LRConfig.SPARK_NAME_CONFIG)).
      setMaster(props.getProperty(LRConfig.SPARK_MASTER_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)
    val hiveContext = new HiveContext(sc)

    if (!init(sc, hiveContext, props))
      System.exit(-1)
    train()

    sc.stop()
  }
}
