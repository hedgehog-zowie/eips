package com.gionee.gdata.recommender.lr

/**
  * <code>LRConfig</code>.
  * LR配置
  *
  * @author taylor
  *         version: 1.0-SNAPSHOT
  *         date: 2017/6/9 18:19
  */
object LRConfig {
  // Spark配置项
  /**
    * 程序名
    */
  val SPARK_NAME_CONFIG = "spark.name"
  /**
    * spark master地址
    */
  val SPARK_MASTER_CONFIG = "spark.master"

  // 模型调优参数
  /**
    * 随机种子
    */
  val RANDOM_SEED = "random.seed"
  /**
    * 训练集切割百分比
    */
  val SPLIT_PROPORTION = "split.proportion"
  /**
    * 容忍次数
    */
  val LBFGS_NUM_CORRECTIONS = "lbfgs.numCorrections"
  /**
    * 容忍阀值
    */
  val LBFGS_CONVERGENCE_TOL = "lbfgs.convergenceTol"
  /**
    * 迭代次数
    */
  val LBFGS_NUM_ITERATIONS = "lbfgs.numIterations"
  /**
    * 正交因子
    */
  val LBFGS_REG_PARAM = "lbfgs.regParam"

  // 业务参数
  /**
    * 训练集查询sql
    */
  val TRAIN_SQL_CONFIG = "lr.hive.train.sql"
  /**
    * 测试集结果表名
    */
  val TEST_RESULT_TABLE = "lr.hive.test.result.table"
  /**
    * 待预测集查询sql
    */
  val PREDICT_SQL_CONFIG = "lr.hive.predict.sql"
  /**
    * 是否需要进行推荐
    */
  val NEED_RECOMMEND_CONFIG = "lr.recommend.need"
  /**
    * 是否保存推荐结果到hive
    */
  val SAVE_TO_HIVE_CONFIG = "lr.save.hive"
  /**
    * 推荐结果表
    */
  val RECOMMEND_TABLE_IN_HIVE_CONFIG = "lr.recommend.table"
  /**
    * 每用户推荐结果个数
    */
  val RECOMMEND_RESULT_SIZE_CONFIG = "lr.recommend.result.size"
  /**
    * MySql地址
    */
  val MYSQL_URL = "mysql.url"
  /**
    * 模型效果保存表名
    */
  val MYSQL_TABLE = "mysql.table"
  /**
    * 模型保存路径
    */
  val MODEL_PATH_CONFIG = "lr.model.path"
}

/**
  * 常量定义
  */
object LRConstants {
  /**
    * 特征间分隔符
    */
  var SPLITTER_BETWEEN_FEATURES = ","
  /**
    * 模型间调优参数分隔符
    */
  var SPLITTER_BETWEEN_MODEL_PARAM = ","

  // 模型评估保存MySql表字段
  val RANDOM_SEED = "randomSeed"
  val SPLIT_PERCENT = "splitPercent"
  val REG_PARAM = "regParam"
  val NUM_CORRECTIONS = "numCorrections"
  val CONVERGENCE_TOL = "convergenceTol"
  val NUM_ITERATIONS = "numIterations"
  val AREA_UNDER_PR = "areaUnderPR"
  val AREA_UNDER_ROC = "areaUnderROC"
  val DURATION = "duration"
  val DATE_TIME = "dateTime"

  // 推荐结果保存Hive表字段
  val USER_COLUMN_NAME: String = "user"
  val USER_ID_COLUMN_NAME: String = "userId"
  val ITEM_COLUMN_NAME: String = "item"
  val ITEM_ID_COLUMN_NAME: String = "itemId"
  val SCORE_COLUMN_NAME: String = "score"
}

/**
  * LR参数配置
  *
  * @param conf
  */
case class LRParams(conf: String = null)

/**
  * 输出到Hive表中的字段
  *
  * @param score
  * @param label
  */
case class Record(score: String, label: String)