package com.gionee.gdata.recommender.kmeans

import org.apache.commons.lang3.StringUtils
import org.apache.spark.mllib.linalg.{Vector, Vectors}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row}

/**
 * <code>FeaturesTool</code>.
 * 特征工具类
 * @author zweig
 * version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:18
 */
object FeaturesTool {

  val NULL_STRING = "null"

  /**
    * 处理物品
    *
    * @param dataFrame
    * @return
    */
  def handleItems(dataFrame: DataFrame): RDD[Item] = {
    dataFrame.map {
      case Row(item, enumFeatures, valueFeatures) =>
        var enumFeaturesSet: Set[String] = Set()
        if (!NULL_STRING.equals(enumFeatures.toString.trim)) {
          val enumFeatureArray = enumFeatures.toString.split(KMeansConstants.SPLITTER_BETWEEN_FEATURES)
          for (enumFeature <- enumFeatureArray) {
            val enumFeatureTrimmed = enumFeature.trim
            if (StringUtils.isNotBlank(enumFeatureTrimmed))
              enumFeaturesSet += enumFeatureTrimmed
          }
        }

        var valueFeaturesMap: Map[String, Double] = Map()
        if (!NULL_STRING.equals(valueFeatures.toString.trim)) {
          val valueFeatureArray = valueFeatures.toString.split(KMeansConstants.SPLITTER_BETWEEN_FEATURES)
          for (valueFeature <- valueFeatureArray) {
            val valueFeatureTrimmed = valueFeature.trim
            if (StringUtils.isNotBlank(valueFeatureTrimmed)) {
              val featureAndValue = valueFeatureTrimmed.split(KMeansConstants.SPLITTER_BETWEEN_FEATURE_AND_VALUE)
              val featureTrimmed = featureAndValue.apply(0).trim
              if (StringUtils.isNotBlank(featureTrimmed)) {
                var weight = KMeansConstants.WEIGHT_DEFAULT
                if (featureAndValue.size > 1)
                  weight = featureAndValue.apply(1).toDouble
                valueFeaturesMap += (featureTrimmed -> weight)
              }
            }
          }
        }

        Item(item.toString, enumFeaturesSet, valueFeaturesMap)
    }
  }

  /**
    * 物品特征化
    *
    * @return
    */
  def handleFeatures(itemRdd: RDD[Item], enumFeaturesArray: Array[String], valueFeaturesArray: Array[String]): RDD[(String, Vector)] = {
    val sortedEnumFeaturesArray = enumFeaturesArray.sortBy(_.toString)
    val sortedValueFeaturesArray = valueFeaturesArray.sortBy(_.toString)
    //    normalize(itemRdd.map {
    itemRdd.map {
      case Item(item, enumFeatures, valueFeatures) =>
        var enumFeaturesVector: List[Double] = List()
        for (enumFeature <- sortedEnumFeaturesArray) {
          if (enumFeatures.contains(enumFeature))
            enumFeaturesVector = enumFeaturesVector :+ 1d
          else
            enumFeaturesVector = enumFeaturesVector :+ 0d
        }

        var valueFeatureVector: List[Double] = List()
        for (valueFeature <- sortedValueFeaturesArray) {
          if (valueFeatures.contains(valueFeature))
            valueFeatureVector = valueFeatureVector :+ valueFeatures.apply(valueFeature)
          else
            valueFeatureVector = valueFeatureVector :+ 0d
        }

        //        (item, enumFeaturesVector, valueFeatureVector)
        val featureVector = enumFeaturesVector ++ valueFeatureVector
        (item, Vectors.dense(featureVector.toArray))
    }
    //    )
  }

  /**
    * 归一化
    *
    * @param rDD
    * @return
    */
  @Deprecated
  def normalize(rDD: RDD[(String, List[Double], List[Double])]): RDD[(String, Vector)] = {
    var maxList: List[Double] = List()
    var minList: List[Double] = List()
    val length = rDD.first._3.size
    val rddCollected = rDD.collect()
    for (idx <- 0 until length) {
      var max: Double = java.lang.Double.MIN_VALUE
      var min: Double = java.lang.Double.MAX_VALUE
      rddCollected.foreach {
        case (item, enumFeaturesVector, valueFeatureVector) =>
          val value = valueFeatureVector.apply(idx)
          if (value > max)
            max = value
          if (value < min)
            min = value
      }
      maxList = maxList :+ max
      minList = minList :+ min
    }
    rDD.map {
      case (item, enumFeaturesVector, valueFeatureVector) =>
        var normalizedValueFeatureVector: List[Double] = List()
        for (idx <- 0 until length) {
          val difference = maxList.apply(idx) - minList.apply(idx)
          var normalizedVector = 0d
          if (difference == 0)
            normalizedVector = valueFeatureVector.apply(idx)
          else
            normalizedVector = (valueFeatureVector.apply(idx) - minList.apply(idx)) / (maxList.apply(idx) - minList.apply(idx))
          normalizedValueFeatureVector = normalizedValueFeatureVector :+ normalizedVector
        }
        val featureVector = enumFeaturesVector ++ normalizedValueFeatureVector
        (item, Vectors.dense(featureVector.toArray))
    }
  }

  /**
    * 行归一化
    *
    * @param list
    * @return
    */
  @Deprecated
  def lineNormalize(list: List[Double]): List[Double] = {
    var min = 0d
    var max = 0d
    var normalizedList: List[Double] = List()
    for (value <- list) {
      if (value < min)
        min = value
      if (value > max)
        max = value
    }
    val gap = max - min
    for (value <- list) {
      normalizedList = normalizedList :+ (value - min) / gap
    }
    normalizedList
  }

}
