package com.gionee.gdata.recommender.kmeans

import java.util.Properties

import com.gionee.gdata.common.ConfigLoader
import com.gionee.gdata.common.utils.FileUtil4S
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.ml.clustering.KMeans
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.Row
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
 * <code>Train</code>.
 * 训练模型
 *
 * @author zweig
 * version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:19
 */
class Train {

  val logger = Logger.getLogger(this.getClass)

  var sc: SparkContext = _
  var hiveContext: HiveContext = _

  // 模型优化参数
  /**
    * 聚类个数
    */
  var clusters: Int = _
  /**
    * 迭代次数
    */
  var iterations: Int = _

  // 业务配置
  /**
    * 训练集查询sql
    */
  var trainSql: String = _
  /**
    * 结果表名
    */
  var resultTable: String = _
  /**
    * 模型保存路径
    */
  var modelPath: String = _
  /**
    * 标称型特征保存路径
    */
  var enumFeaturesPath: String = _
  /**
    * 数值型特征保存路径
    */
  var valueFeaturesPath: String = _

  def init(sc: SparkContext, hiveContext: HiveContext, props: Properties): Boolean = {
    this.resultTable = props.getProperty(KMeansConfig.RECOMMEND_TABLE_IN_HIVE_CONFIG)
    this.trainSql = props.getProperty(KMeansConfig.TRAIN_SQL_CONFIG)
    if (StringUtils.isBlank(this.trainSql)) {
      logger.error("训练集查询SQL必须配置")
      return false
    }
    this.modelPath = props.getProperty(KMeansConfig.MODEL_PATH_CONFIG)
    if (StringUtils.isBlank(this.modelPath)) {
      logger.error("模型保存路径必须配置")
      return false
    }
    this.enumFeaturesPath = props.getProperty(KMeansConfig.ENUM_FEATURES_PATH_CONFIG)
    this.valueFeaturesPath = props.getProperty(KMeansConfig.VALUE_FEATURES_PATH_CONFIG)
    if (StringUtils.isBlank(this.enumFeaturesPath) && StringUtils.isBlank(this.valueFeaturesPath)) {
      logger.error("标称型特征或数值型特征保存路径至少配置一个")
      return false
    }
    if (StringUtils.isNotBlank(this.enumFeaturesPath))
      FileUtil4S.deleteHdfsFile(sc, this.enumFeaturesPath)
    if (StringUtils.isNotBlank(this.valueFeaturesPath))
      FileUtil4S.deleteHdfsFile(sc, this.valueFeaturesPath)
    this.clusters = props.getProperty(KMeansConfig.CLUSTERS_CONFIG, "2").toInt
    this.iterations = props.getProperty(KMeansConfig.ITERATIONS_CONFIG, "20").toInt

    // spark配置上下文
    this.sc = sc
    this.hiveContext = hiveContext

    return true
  }

  def train(): Unit = {
    train(hiveContext.sql(trainSql).map {
      case Row(item, enumFeatures, valueFeatures) =>
        (item.toString, enumFeatures.toString, valueFeatures.toString)
    })
  }

  def train(originalFeaturesRdd: RDD[(String, String, String)]): Unit = {

    val originalItemTable = hiveContext.createDataFrame(originalFeaturesRdd).toDF(
      KMeansConstants.ITEM_COLUMN_NAME, KMeansConstants.ITEM_ENUM_FEATURES_COLUMN_NAME, KMeansConstants.ITEM_VALUE_FEATURES_COLUMN_NAME).
      cache()
    val count = originalItemTable.count()
    if (count == 0) {
      logger.warn(s"不存在物品表，无法进行训练。")
      return
    }
    logger.info(s"物品表数据条数：$count")

    val itemRdd = FeaturesTool.handleItems(originalItemTable).cache()
    // 特征向量
    val enumFeaturesRdd = itemRdd.flatMap {
      case Item(itemId, enumFeatures, valueFeatures) =>
        enumFeatures
    }.distinct()
    val valueFeaturesRdd = itemRdd.flatMap {
      case Item(itemId, enumFeatures, valueFeatures) =>
        valueFeatures.keySet
    }.distinct()
    // 保存全量特征向量
    enumFeaturesRdd.saveAsTextFile(enumFeaturesPath)
    valueFeaturesRdd.saveAsTextFile(valueFeaturesPath)

    val enumFeaturesSet = enumFeaturesRdd.collect()
    val enumFeaturesCount = enumFeaturesSet.size
    logger.info(s"标称型特征个数：$enumFeaturesCount")
    val valueFeaturesSet = valueFeaturesRdd.collect()
    val valueFeaturesCount = valueFeaturesSet.size
    logger.info(s"数值型特征个数：$valueFeaturesCount")

    // 广播
    val bEnumFeaturesSet = sc.broadcast(enumFeaturesSet)
    val bValueFeaturesSet = sc.broadcast(valueFeaturesSet)

    val features = hiveContext.createDataFrame(
      FeaturesTool.handleFeatures(itemRdd, bEnumFeaturesSet.value, bValueFeaturesSet.value)
    ).toDF(KMeansConstants.ITEM_COLUMN_NAME, KMeansConstants.ITEM_FEATURES_COLUMN_NAME).cache()

    val kMeans = new KMeans()
      .setK(clusters)
      .setMaxIter(iterations)
      .setFeaturesCol(KMeansConstants.ITEM_FEATURES_COLUMN_NAME)
      .setPredictionCol(KMeansConstants.PREDICTION_COLUMN_NAME)
    val model = kMeans.fit(features)
    model.write.overwrite().save(modelPath)

    features.unpersist()
    itemRdd.unpersist()
    originalItemTable.unpersist()

    // predict
    //        val result = model.transform(features).select("id", "prediction")
    //        features.unpersist()
    //        result.write.mode(SaveMode.Overwrite).saveAsTable(resultTable)

  }

  //  /**
  //    * 列归一化
  //    *
  //    * @param rdd
  //    * @param valueFeaturesCount
  //    */
  //  def normalize(rdd: RDD[(Int, Array[Double], Array[Double])], valueFeaturesCount: Int): Unit = {
  //    for (i <- 0 until valueFeaturesCount) {
  //      var min = 0d
  //      var max = 0d
  //      rdd.map {
  //        case (itemId, enumFeaturesVector, valueFeatureVector) =>
  //          val value = valueFeatureVector.apply(i)
  //          if (value < min)
  //            min = value
  //          if (value > max)
  //            max = value
  //      }
  //      val gap = max - min
  //      rdd.map {
  //        case (itemId, enumFeaturesVector, valueFeatureVector) =>
  //          val value = valueFeatureVector.apply(i)
  //          valueFeatureVector.update(i, (value - min) / gap)
  //          (itemId, enumFeaturesVector, valueFeatureVector)
  //      }
  //    }
  //  }

  /**
    * 行归一化
    *
    * @param list
    * @return
    */
  def normalize(list: List[Double]): List[Double] = {
    var min = 0d
    var max = 0d
    val normalizedList: List[Double] = List()
    for (value <- list) {
      if (value < min)
        min = value
      if (value > max)
        max = value
    }
    val gap = max - min
    for (value <- list) {
      normalizedList.::((value - min) / gap)
    }
    return normalizedList
  }

  def main(args: Array[String]) {

    val defaultParams = KMeansParams()
    val parser = new OptionParser[KMeansParams]("") {
      head("KMeans train", "1.0")
      opt[String]('c', "conf")
        .valueName("config-file-path")
        .text(s"配置文件，必选")
        .action {
          (x, c) => c.copy(conf = x)
        }
      help("help").text("prints this usage text")
    }

    var props: Properties = null
    parser.parse(args, defaultParams) match {
      case Some(params) => {
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
      }
      case None => System.exit(-1)
    }

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")

    val sparkConf = new SparkConf().
      setAppName(props.getProperty(KMeansConfig.SPARK_NAME_CONFIG)).
      setMaster(props.getProperty(KMeansConfig.SPARK_MASTER_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)
    val hiveContext = new HiveContext(sc)

    if (!init(sc, hiveContext, props))
      System.exit(-1)
    train()

    sc.stop()

  }

}
