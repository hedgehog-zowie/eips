package com.gionee.gdata.recommender.kmeans

import java.util.Properties

import com.gionee.gdata.common.ConfigLoader
import org.apache.log4j.Logger
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
  * <code>TrainAndRecommend</code>.
  * 训练模型并进行推荐
  *
  * @author zweig
  *         version: 1.0-SNAPSHOT
  *         date: 2017/6/9 18:20
  */
object TrainAndRecommend {

  val logger = Logger.getLogger(TrainAndRecommend.getClass)

  def main(args: Array[String]) {

    val defaultParams = KMeansParams()
    val parser = new OptionParser[KMeansParams]("") {
      head("KMeansParams Train", "1.0")
      opt[String]('c', "conf")
        .valueName("config-file-path")
        .text(s"配置文件，必选")
        .action {
          (x, c) => c.copy(conf = x)
        }
      help("help").text("prints this usage text")
    }

    var props: Properties = null
    parser.parse(args, defaultParams) match {
      case Some(params) => {
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
      }
      case None => System.exit(-1)
    }

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")

    val sparkConf = new SparkConf().
      setAppName(props.getProperty(KMeansConfig.SPARK_NAME_CONFIG)).
      setMaster(props.getProperty(KMeansConfig.SPARK_MASTER_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)
    val hiveContext = new HiveContext(sc)

    val train = new Train
    if (!train.init(sc, hiveContext, props))
      System.exit(-1)
    train.train()

    val recommend = new Recommend
    if (!recommend.init(sc, hiveContext, props))
      System.exit(-1)

    val predictions = recommend.predict()
    if (recommend.needRecommend) {
      recommend.recommend(predictions)
    }

    sc.stop()

  }

}
