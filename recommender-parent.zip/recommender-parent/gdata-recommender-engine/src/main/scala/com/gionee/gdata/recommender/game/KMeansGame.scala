package com.gionee.gdata.recommender.game

import java.util.Properties

import org.apache.spark.mllib.clustering.KMeans
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.sql.SQLContext
import org.apache.spark.{SparkConf, SparkContext}

/**
 * <code>KMeansGame</code>.
 * 使用KMeans进行游戏推荐
 * @author dengxiaolong
 * version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:17
 */
object KMeansGame {
  def main(args: Array[String]) {

    val sparkConf = new SparkConf().setAppName("KMeans").setMaster("local[5]")
    val sc = new SparkContext(sparkConf)
    val sqlContext = new SQLContext(sc)
    import sqlContext.implicits._
    //mysql数据库链接
    val url = "jdbc:mysql://10.10.10.138:3306/bidb?user=appuser&password=aaad-fea7!e"

    //读取mysql数据表
    val prop = new Properties()
    val gamecdataDF = sqlContext.read.jdbc(url, "dlv_gamec_recommend_list", prop)
    //提取类型字段，并转换成RDD
    val categoryDataRDD = gamecdataDF.select("category").map { row =>
      val map = row.getValuesMap[Any](Array("category"))
      (map("category").toString())
    }

    val VectorDataRDD = categoryDataRDD
      .map(s => Vectors.dense(s.split(' ').map(_.toDouble)))
      .cache()

    val numClusters = 100 //聚类分类个数
    val numIterations = 20 //迭代次数
    val runTimes = 8
    val initMode = "k-means||"
    val clusters = new KMeans()
      .setInitializationMode(initMode)
      .setK(numClusters)
      .setMaxIterations(numIterations)
      .run(VectorDataRDD)
    //val clusters = KMeans.train(VectorDataRDD, numClusters, numIterations, runTimes)

    /* println("------Predict the existing line in the analyzed data file: " + "game_recoment.txt")
    println("Vector 118 65 10 24 93 belongs to clustering " + clusters.predict(Vectors.dense("118 65 10 24 93".split(' ').map(_.toDouble))))
    
    val wssse = clusters.computeCost(parsedData)
    println("Within Set Sum of Squared Errors = " + wssse)*/
    //把数据重新放到模型跑数，得到每个游戏id及分类的数据：gamec_resource_id，detail_num_int，dl_num_int，res

    //提取结果到dataframe
    val gameList_res = gamecdataDF.map { row =>
      val map = row.getValuesMap[Any](Array("gamec_resource_id", "detail_num", "dl_num", "category"))
      val ord = clusters.predict(Vectors.dense(map("category").toString().split(' ').map(_.toDouble)))
      gameList(map("gamec_resource_id").toString().toInt, map("detail_num").toString().toInt, map("dl_num").toString().toInt, ord)
    }.toDF()
    //注册成临时表
    gameList_res.registerTempTable("gameList_table")

    //写入到mysql数据库
    gameList_res.insertIntoJDBC(url, "dlv_game_kmeans", true)

    //打印查看结果
    //gameList_res.take(10).foreach(println)

    sc.stop()
  }

  case class gameList(gamec_resource_id: Int, detail_num: Int, dl_num: Int, ord: Int)

}