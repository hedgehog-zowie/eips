package com.gionee.gdata.recommender.als.mllib

import java.util.Properties

import com.gionee.gdata.common.ConfigLoader
import com.gionee.gdata.ml.ext.ExtMatrixFactorizationModelHelper
import com.gionee.gdata.recommender.als.{ALSConfig, ALSConstants, ALSParams}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.mllib.recommendation.MatrixFactorizationModel
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.{DataFrame, Row, SaveMode}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
  * <code>Recommend</code>.
  * 预测评分
  *
  * @author zweig
  *         version: 1.0-SNAPSHOT
  *         date: 2017/6/9 18:16
  */
object Recommend {

  val logger = Logger.getLogger(Recommend.getClass)

  // spark相关参数
  var sc: SparkContext = _
  var hiveContext: HiveContext = _
  var model: MatrixFactorizationModel = _

  // 业务参数
  /**
    * 模型保存路径
    */
  var modelPath: String = _
  /**
    * 评分表查询sql
    */
  var scoreSql: String = _
  /**
    * 用户表，用户与ID对应表
    */
  var userIdTableName: String = _
  /**
    * 物品表，物品与ID对应表
    */
  var itemIdTableName: String = _
  /**
    * 是否保存结果到hive
    */
  var saveToHive: Boolean = false
  /**
    * 推荐结果表
    */
  var resultHiveTable: String = _
  /**
    * 每用户推荐结果个数
    */
  var resultSize: Int = _
  /**
    * 每个块数据条数
    */
  var blockSize: Int = _
  /**
    * 用户分区个数
    */
  var userPartitions: Int = _
  /**
    * 物品分区分数
    */
  var itemPartitions: Int = _

  def init(sc: SparkContext, hiveContext: HiveContext, props: Properties): Boolean = {
    // spark配置上下文
    this.sc = sc
    this.hiveContext = hiveContext

    // 模型保存路径
    this.modelPath = props.getProperty(ALSConfig.MODEL_PATH_CONFIG)
    if (StringUtils.isBlank(this.modelPath)) {
      logger.error("模型保存路径必须配置")
      return false
    }
    // 用户表，用户与ID对应表
    this.userIdTableName = props.getProperty(ALSConfig.USER_ID_TABLE_CONFIG)
    if (StringUtils.isBlank(this.userIdTableName)) {
      logger.error("用户ID对应表必须配置")
      return false
    }
    // 物品表，物品与ID对应表
    this.itemIdTableName = props.getProperty(ALSConfig.ITEM_ID_TABLE_CONFIG)
    if (StringUtils.isBlank(this.itemIdTableName)) {
      logger.error("物品ID对应表必须配置")
      return false
    }
    // 评分表查询sql
    this.scoreSql = props.getProperty(ALSConfig.SCORE_SQL_CONFIG)
    if (StringUtils.isBlank(this.scoreSql)) {
      logger.error("评分表查询sql必须配置")
      return false
    }

    // 每用户推荐结果个数
    this.resultSize = props.getProperty(ALSConfig.RESULT_SIZE_CONFIG, "10").toInt

    // 每个块数据条数
    this.blockSize = props.getProperty(ALSConfig.BLOCK_SIZE_CONFIG, "4096").toInt
    // 用户分区个数
    this.userPartitions = props.getProperty(ALSConfig.USER_PARTITIONS_CONFIG, "100").toInt
    // 物品分区分数
    this.itemPartitions = props.getProperty(ALSConfig.ITEM_PARTITIONS_CONFIG, "100").toInt

    // 加载模型
    this.model = MatrixFactorizationModel.load(this.sc, modelPath)

    // 保存结果到hive相关配置
    val saveToHiveConfig = props.getProperty(ALSConfig.SAVE_TO_HIVE_CONFIG)
    if (StringUtils.isNotBlank(saveToHiveConfig))
      this.saveToHive = saveToHiveConfig.toBoolean
    this.resultHiveTable = props.getProperty(ALSConfig.RESULT_TABLE_CONFIG)
    if (saveToHive) {
      if (StringUtils.isBlank(this.resultHiveTable)) {
        logger.error("需要保存推荐结果到Hive，Hive推荐结果表必须配置")
        return false
      }
    }

    return true
  }

  /**
    * 批量预测
    */
  def recommend(): Unit = {
    val userIdTable = hiveContext.sql(s"select ${ALSConstants.USER_COLUMN_NAME}, ${ALSConstants.USER_ID_COLUMN_NAME} from ${userIdTableName}").persist(StorageLevel.MEMORY_AND_DISK_SER)
    val itemIdTable = hiveContext.sql(s"select ${ALSConstants.ITEM_COLUMN_NAME}, ${ALSConstants.ITEM_ID_COLUMN_NAME} from ${itemIdTableName}").persist(StorageLevel.MEMORY_AND_DISK_SER)
    // 用户已评分物品
    val scores = hiveContext.sql(scoreSql).toDF(ALSConstants.USER_COLUMN_NAME, ALSConstants.ITEM_COLUMN_NAME, ALSConstants.RATING_COLUMN_NAME).persist(StorageLevel.MEMORY_AND_DISK_SER)
    recommend(userIdTable, itemIdTable, scores)
    userIdTable.unpersist()
    itemIdTable.unpersist()
    scores.unpersist()
  }

  /**
    * 批量预测
    *
    * @param userIdTable
    * @param itemIdTable
    * @param scores
    */
  def recommend(userIdTable: DataFrame, itemIdTable: DataFrame, scores: DataFrame): Unit = {

    //    val recommendations = hiveContext.createDataFrame(
    //      model.recommendProductsForUsers(resultSize).flatMap { case (userId, ratings) => ratings }).
    //      toDF(ALSConstants.userIdColumnName, ALSConstants.itemIdColumnName, ALSConstants.predictionColumnName)

    val recommendations = hiveContext.createDataFrame(
      ExtMatrixFactorizationModelHelper.recommendProductsForUsers(model, resultSize, blockSize, userPartitions, itemPartitions, StorageLevel.MEMORY_AND_DISK_SER).
        flatMap { case (userId, ratings) => ratings }).
      toDF(ALSConstants.USER_ID_COLUMN_NAME, ALSConstants.ITEM_ID_COLUMN_NAME, ALSConstants.PREDICTION_COLUMN_NAME)

    // 过滤已评分物品
    val joinedPredictions = recommendations.
      join(userIdTable, ALSConstants.USER_ID_COLUMN_NAME).
      join(itemIdTable, ALSConstants.ITEM_ID_COLUMN_NAME).
      select(userIdTable(ALSConstants.USER_COLUMN_NAME),
        recommendations(ALSConstants.USER_ID_COLUMN_NAME),
        itemIdTable(ALSConstants.ITEM_COLUMN_NAME),
        recommendations(ALSConstants.ITEM_ID_COLUMN_NAME),
        recommendations(ALSConstants.PREDICTION_COLUMN_NAME)).
      join(scores, Seq(ALSConstants.USER_COLUMN_NAME, ALSConstants.ITEM_COLUMN_NAME), "left")
    val filteredPredictions = joinedPredictions.where(joinedPredictions(ALSConstants.RATING_COLUMN_NAME).isNull).
      select(joinedPredictions(ALSConstants.USER_COLUMN_NAME),
        joinedPredictions(ALSConstants.USER_ID_COLUMN_NAME),
        joinedPredictions(ALSConstants.ITEM_COLUMN_NAME),
        joinedPredictions(ALSConstants.ITEM_ID_COLUMN_NAME),
        joinedPredictions(ALSConstants.PREDICTION_COLUMN_NAME)
      )
    val results = generateToResult(filteredPredictions).coalesce(100).persist(StorageLevel.MEMORY_AND_DISK_SER)
    // 保存结果
    if (saveToHive)
      results.write.mode(SaveMode.Overwrite).saveAsTable(resultHiveTable)

  }

  /**
    * 得出推荐结果
    *
    * @return
    */
  private def generateToResult(predictions: DataFrame): DataFrame = {
    hiveContext.createDataFrame(
      predictions.map {
        case Row(user, userId, item, itemId, prediction) =>
          ((user.toString, userId.toString.toInt), (item.toString, itemId.toString.toInt, prediction.toString.toDouble))
      }.groupByKey().map {
        grouped => {
          var resultStr = ""
          val size = grouped._2.size
          var i = 0
          grouped._2.map(temp => {
            i += 1
            resultStr += temp._1.trim + ":" + "%.2f".format(temp._3)
            if (i != size)
              resultStr += ","
          })
          (grouped._1._1, resultStr)
        }
      }
    ).toDF(ALSConstants.USER_COLUMN_NAME, ALSConstants.RESULT_COLUMN_NAME)
  }

  def main(args: Array[String]) {

    val defaultParams = ALSParams()
    val parser = new OptionParser[ALSParams]("") {
      head("MLLib ALS Recommend", "1.0")
      opt[String]('c', "conf")
        .required()
        .valueName("config-file-path")
        .text(s"配置文件，必选")
        .action {
          (x, c) => c.copy(conf = x)
        }
      help("help").text("prints this usage text")
    }

    var props: Properties = null
    parser.parse(args, defaultParams) match {
      case Some(params) => {
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
      }
      case None => System.exit(1)
    }

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")

    val sparkConf = new SparkConf().
      setAppName(props.getProperty(ALSConfig.SPARK_NAME_CONFIG)).
      setMaster(props.getProperty(ALSConfig.SPARK_MASTER_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)
    val hiveContext = new HiveContext(sc)
    new org.apache.spark.sql.SQLContext(sc)

    if (!init(sc, hiveContext, props))
      System.exit(-1)
    recommend()

    sc.stop()
  }

}
