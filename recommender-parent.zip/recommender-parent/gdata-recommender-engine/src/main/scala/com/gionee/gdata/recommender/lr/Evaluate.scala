package com.gionee.gdata.recommender.lr

import java.text.SimpleDateFormat
import java.util.{Date, Properties}

import com.gionee.gdata.common.ConfigLoader
import com.gionee.gdata.common.utils.MySqlUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.mllib.classification.LogisticRegressionModel
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.optimization.{LBFGS, LogisticGradient, SquaredL2Updater}
import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.util.MLUtils
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SQLContext, SaveMode}
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
  * <code>Evaluate</code>.
  * 评估模型
  *
  * @author taylor
  *         version: 1.0-SNAPSHOT
  *         date: 2017/6/9 18:18
  */
object Evaluate {

  /**
    * 日志记录器
    */
  val logger = Logger.getLogger(this.getClass)

  // Spark上下文
  var sc: SparkContext = _
  var hiveContext: HiveContext = _

  // 模型参数
  /**
    * 随机种子
    */
  var randomSeed: String = _
  /**
    * 训练集切割百分比
    */
  var splitProportion: String = _
  /**
    * 容忍次数
    */
  var lbfgsNumCorrections: String = _
  /**
    * 容忍因子
    */
  var lbfgsConvergenceTol: String = _
  /**
    * 迭代次数
    */
  var lbfgsNumIterations: String = _
  /**
    * 正交因子
    */
  var lbfgsRegParam: String = _

  // 业务参数
  /**
    * 训练集查询sql
    */
  var trainSql: String = _
  /**
    * MySql地址
    */
  var mysqlUrl: String = _
  /**
    * 模型效果保存表名
    */
  var modelEvaluateTable: String = _
  /**
    * 程序运行时间记录
    */
  var dateTime: String = _

  /**
    * 初始化
    *
    * @param sc
    * @param hiveContext
    * @param props
    */
  def init(sc: SparkContext, hiveContext: HiveContext, props: Properties): Boolean = {

    // 上下文配置项
    this.sc = sc
    this.hiveContext = hiveContext

    // 模型配置项
    randomSeed = props.getProperty(LRConfig.RANDOM_SEED)
    if (StringUtils.isBlank(randomSeed)) {
      logger.error("随机种子必须配置")
      return false
    }
    splitProportion = props.getProperty(LRConfig.SPLIT_PROPORTION)
    if (StringUtils.isBlank(splitProportion)) {
      logger.error("数据切分比例必须配置")
      return false
    }
    lbfgsNumCorrections = props.getProperty(LRConfig.LBFGS_NUM_CORRECTIONS)
    if (StringUtils.isBlank(lbfgsNumCorrections)) {
      logger.error("容忍次数必须配置")
      return false
    }
    lbfgsConvergenceTol = props.getProperty(LRConfig.LBFGS_CONVERGENCE_TOL)
    if (StringUtils.isBlank(lbfgsConvergenceTol)) {
      logger.error("容忍阀值必须配置")
      return false
    }
    lbfgsNumIterations = props.getProperty(LRConfig.LBFGS_NUM_ITERATIONS)
    if (StringUtils.isBlank(lbfgsNumIterations)) {
      logger.error("模型迭代次数必须配置")
      return false
    }
    lbfgsRegParam = props.getProperty(LRConfig.LBFGS_REG_PARAM)
    if (StringUtils.isBlank(lbfgsRegParam)) {
      logger.error("模型正交因子必须配置")
      return false
    }

    // 业务配置项
    this.trainSql = props.getProperty(LRConfig.TRAIN_SQL_CONFIG)
    if (StringUtils.isBlank(this.trainSql)) {
      logger.error("训练集查询SQL必须配置")
      return false
    }
    this.mysqlUrl = props.getProperty(LRConfig.MYSQL_URL)
    if (StringUtils.isBlank(this.mysqlUrl)) {
      logger.error("模型效果保存MySql URL 地址必须配置")
      return false
    }
    this.modelEvaluateTable = props.getProperty(LRConfig.MYSQL_TABLE)
    if (StringUtils.isBlank(this.modelEvaluateTable)) {
      logger.error("模型效果保存MySql表必须配置")
      return false
    }

    // 程序运行时间记录
    this.dateTime = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date())

    true
  }

  /**
    * 模型参数调优
    *
    */
  def evaluate(): Unit = {

    // 模型效果MySql字段定义
    val schemaArray = Array(LRConstants.RANDOM_SEED, LRConstants.SPLIT_PERCENT,
      LRConstants.NUM_CORRECTIONS, LRConstants.CONVERGENCE_TOL, LRConstants.NUM_ITERATIONS, LRConstants.REG_PARAM,
      LRConstants.AREA_UNDER_PR, LRConstants.AREA_UNDER_ROC, LRConstants.DURATION, LRConstants.DATE_TIME)
    val fields = schemaArray.map(fieldName =>
      StructField(fieldName, StringType, nullable = true))

    val splitProportionArray = splitProportion.split(LRConstants.SPLITTER_BETWEEN_MODEL_PARAM)
    val randomSeedArray = randomSeed.split(LRConstants.SPLITTER_BETWEEN_MODEL_PARAM)
    for (splitProportion <- splitProportionArray) {
      for (randomSeed <- randomSeedArray) {
        // 生成训练模型数据集和测试模型数据集
        val Array(trainData, testData) = hiveContext.sql(trainSql).rdd.map {
          case Row(flag: String, feature: String) =>
            LabeledPoint(flag.toDouble, Vectors.dense(feature.split(LRConstants.SPLITTER_BETWEEN_FEATURES).map(_.toDouble)))
        }.randomSplit(Array(splitProportion.toDouble, 1 - splitProportion.toDouble), seed = randomSeed.toInt)
        // 训练模型数据增加偏倚
        val trainData1 = trainData.map { case LabeledPoint(label, features) =>
          (label, MLUtils.appendBias(features))
        }

        trainData.cache()
        trainData1.cache()
        testData.cache()

        // 模型训练参数调优
        val lbfgsNumCorrectionsArray = lbfgsNumCorrections.split(LRConstants.SPLITTER_BETWEEN_MODEL_PARAM)
        val lbfgsConvergenceTolArray = lbfgsConvergenceTol.split(LRConstants.SPLITTER_BETWEEN_MODEL_PARAM)
        val lbfgsNumIterationsArray = lbfgsNumIterations.split(LRConstants.SPLITTER_BETWEEN_MODEL_PARAM)
        val lbfgsRegParamArray = lbfgsRegParam.split(LRConstants.SPLITTER_BETWEEN_MODEL_PARAM)
        for (numCorrections <- lbfgsNumCorrectionsArray) {
          for (convergenceTol <- lbfgsConvergenceTolArray) {
            for (numIterations <- lbfgsNumIterationsArray) {
              for (regParam <- lbfgsRegParamArray) {
                // 使用LBFGS优化算法训练LR模型
                val startTime = System.currentTimeMillis()
                val initialWeightsWithIntercept = Vectors.dense(new Array[Double](trainData.first().features.size + 1))
                val (weightsWithIntercept, _) = LBFGS.runLBFGS(trainData1, // 使用偏倚的训练集进行模型训练
                  new LogisticGradient(), new SquaredL2Updater(), // 使用Logistic梯度计算和L2更新权重
                  numCorrections.toInt, convergenceTol.toDouble, numIterations.toInt, regParam.toDouble,
                  initialWeightsWithIntercept)
                val model = new LogisticRegressionModel(
                  Vectors.dense(weightsWithIntercept.toArray.slice(0, weightsWithIntercept.size - 1)),
                  weightsWithIntercept(weightsWithIntercept.size - 1)
                ).clearThreshold()
                val endTime = System.currentTimeMillis()
                val duration = endTime - startTime

                // 根据测试集预测出来的结果，计算模型评估指标PR和AUC
                val scoreAndLabels = testData.map { point =>
                  val score = model.predict(point.features)
                  (score, point.label)
                }
                val metrics = new BinaryClassificationMetrics(scoreAndLabels)
                val evaluate = sc.parallelize(Array((
                  randomSeed.toString, splitProportion.toString,
                  numCorrections.toString, convergenceTol.toString, numIterations.toString, regParam.toString,
                  metrics.areaUnderPR().toString, metrics.areaUnderROC().toString, duration.toString, dateTime)) // 评估指标PR和AUC
                ).map(parts => Row(parts._1, parts._2, parts._3, parts._4, parts._5, parts._6, parts._7, parts._8, parts._9, parts._10))

                // 模型效果评估指标保存到MySql表中
                val evaluateDataFrame = new SQLContext(sc).createDataFrame(evaluate, StructType(fields))
                val mySqlTool = MySqlUtil.getInstance(sc, mysqlUrl)
                mySqlTool.writeTable(evaluateDataFrame, modelEvaluateTable, SaveMode.Append)
                logger.info(s"模型效果评估数据保存到MySql表中：$modelEvaluateTable")
              }
            }
          }
        }
        trainData.unpersist(true)
        trainData1.unpersist(true)
        testData.unpersist(true)
      }
    }

  }

  def main(args: Array[String]) {
    val defaultParams = LRParams()
    val parser = new OptionParser[LRParams]("") {
      head("LR Evaluate Train", "1.0")
      opt[String]('c', "conf")
        .valueName("config-file-path")
        .text(s"配置文件，必选")
        .action {
          (x, c) => c.copy(conf = x)
        }
      help("help").text("prints this usage text")
    }

    var props: Properties = null
    parser.parse(args, defaultParams) match {
      case Some(params) =>
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
      case None => System.exit(-1)
    }

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")

    val sparkConf = new SparkConf().
      setAppName(props.getProperty(LRConfig.SPARK_NAME_CONFIG)).
      setMaster(props.getProperty(LRConfig.SPARK_MASTER_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)
    val hiveContext = new HiveContext(sc)

    if (init(sc, hiveContext, props))
      evaluate()

    sc.stop()
  }
}
