package com.gionee.gdata.recommender.kmeans

/**
 * <code>KMeansConfig</code>.
 * KMeans配置
 * @author zweig
 * version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:19
 */
object KMeansConfig {

  // spark配置项
  /**
    * 程序名
    */
  val SPARK_NAME_CONFIG = "spark.name"
  /**
    * spark master地址
    */
  val SPARK_MASTER_CONFIG = "spark.master"

  // 模型调优参数
  /**
    * 聚类个数
    */
  val CLUSTERS_CONFIG = "kmeans.clusters"
  /**
    * 迭代次数
    */
  val ITERATIONS_CONFIG = "kmeans.iterations"

  // 业务参数
  /**
    * 模型保存路径
    */
  val MODEL_PATH_CONFIG = "kmeans.model.path"
  /**
    * 标称型特征保存路径
    */
  val ENUM_FEATURES_PATH_CONFIG = "kmeans.features.enum.path"
  /**
    * 数值型特征保存路径
    */
  val VALUE_FEATURES_PATH_CONFIG = "kmeans.features.value.path"
  /**
    * 是否需要进行推荐
    */
  val NEED_RECOMMEND_CONFIG = "kmeans.recommend.need"
  /**
    * 是否保存结果到hive
    */
  val SAVE_TO_HIVE_CONFIG = "kmeans.save.hive"
  /**
    * 推荐结果表
    */
  val RECOMMEND_TABLE_IN_HIVE_CONFIG = "kmeans.recommend.table"
  /**
    * 每用户推荐结果个数
    */
  val RECOMMEND_RESULT_SIZE_CONFIG = "kmeans.recommend.result.size"
  /**
    * 是否保存聚类结果
    */
  val SAVE_CLUSTER_CONFIG = "kmeans.cluster.save"
  /**
    * 聚类结果表
    */
  val CLUSTER_TABLE_CONFIG = "kmeans.cluster.table"
  /**
    * 是否需要在线推荐
    */
  val RECOMMEND_ONLINE_CONFIG = "kmeans.recommend.online"
  /**
    * 物品、聚类、评分表
    */
  val ITEM_CLUSTER_SCORE_TABLE_CONFIG = "kmeans.item.cluster.table"
  /**
    * 聚类、物品、评分表
    */
  val CLUSTER_ITEM_SCORE_TABLE_CONFIG = "kmeans.cluster.item.table"
  /**
    * 用户、物品、聚类、评分表
    */
  val USER_ITEM_CLUSTER_SCORE_TABLE_CONFIG = "kmeans.cluster.user.table"
  /**
    * 训练集查询sql
    */
  val TRAIN_SQL_CONFIG = "kmeans.hive.features.sql"
  /**
    * 待预测集查询sql
    */
  val PREDICT_SQL_CONFIG = "kmeans.hive.predict.sql"
  /**
    * 用户评分查询sql
    */
  val SCORE_SQL_CONFIG = "kmeans.hive.score.sql"
  /**
    * 是否保存结果到HBase
    */
  val SAVE_TO_HBASE_CONFIG = "kmeans.save.hbase"
  // hbase配置
  val ZK_QUORUM_CONFIG = "kmeans.hbase.zkQuorum"
  val ZK_PORT_CONFIG = "kmeans.hbase.zkPort"
  val HBASE_RESULT_TABLE_CONFIG = "kmeans.hbase.result.tableName"
  val HBASE_RESULT_CF_CONFIG = "kmeans.hbase.result.cf"
}

/**
  * kMeans评估配置项
  */
object KMeansEvaluateConfig {
  // 模型调优参数
  /**
    * 聚类个数
    */
  val CLUSTERS_CONFIG = "kmeans.evaluate.clusters"
  /**
    * 迭代次数
    */
  val ITERATIONS_CONFIG = "kmeans.evaluate.iterations"
  /**
    * 物品特征查询sql
    */
  val ITEMSQL_CONFIG = "kmeans.evaluate.sql"
}

/**
  * 常量定义
  */
object KMeansConstants {
  val USER_COLUMN_NAME: String = "user"
  val USER_ID_COLUMN_NAME: String = "userId"
  val ITEM_COLUMN_NAME: String = "item"
  val ITEM_ID_COLUMN_NAME: String = "itemId"
  val ITEM_ENUM_FEATURES_COLUMN_NAME: String = "enumFeatures"
  val ITEM_VALUE_FEATURES_COLUMN_NAME: String = "valueFeatures"
  val ITEM_FEATURES_COLUMN_NAME: String = "features"
  val PREDICTION_COLUMN_NAME: String = "prediction"
  val SCORE_COLUMN_NAME: String = "score"
  val RESULT_COLUMN_NAME: String = "result"

  /**
    * 特征间分隔符
    */
  var SPLITTER_BETWEEN_FEATURES = ","
  /**
    * 特征与权重分隔符
    */
  var SPLITTER_BETWEEN_FEATURE_AND_VALUE = ":"
  /**
    * 默认权重
    */
  val WEIGHT_DEFAULT = 1d

}

/**
  * KMeans参数配置
  *
  * @param conf
  */
case class KMeansParams(conf: String = null)

/**
  * 物品定义
  *
  * @param itemId
  * @param enumFeatures  标称型特征
  * @param valueFeatures 数值型特征
  */
case class Item(itemId: String, enumFeatures: Set[String], valueFeatures: Map[String, Double])

/**
  * 用户物品评分类
  *
  * @param user
  * @param item
  * @param score
  */
case class UserItemScore(user: String, item: String, score: Double)
