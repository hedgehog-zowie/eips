package com.gionee.gdata.recommender.game

import org.apache.spark.ml.recommendation.ALSModel
import org.apache.spark.mllib.recommendation.MatrixFactorizationModel
import org.jblas.DoubleMatrix

/**
 * <code>SimilarGame</code>.
 * 游戏相似度计算，暂停
 * @author zweig
 * version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:17
 */
@Deprecated
object SimilarGame {

  def computeGameSimilar(gameId: Int): Unit = {
    val model = ALSModel.load("/data/spark/data/game/model")
    val gameFactors = model.itemFactors.filter(s"id = 5028")
    val gameFeatures = gameFactors.select("id", "features").head()
    gameFeatures.get(1)
    gameFeatures.getSeq[Float](1).toArray[Float]
    val data = gameFeatures.getSeq[Float](1)
    val da = new Array[Double](data.length)
    //    data.copyToArray[Double](da)
    for (i <- 0 to data.length - 1)
      da(i) = data(i)
    val gameVector = new DoubleMatrix(da)
    val model2 = MatrixFactorizationModel.load(null, "")
    val data2 = model2.productFeatures.first()._2
    val gameVector2 = new DoubleMatrix(data2)

    //    val gameFeatures = gameFactors.select("id", "features").map {
    //      case Row(id: Int,
    //      (
    //        f0, f1, f2, f3, f4, f5, f6, f7, f8, f9,
    //        f10, f11, f12, f13, f14, f15, f16, f17, f18, f19,
    //        f20, f21, f22, f23, f24, f25, f26, f27, f28, f29,
    //        f30, f31, f32, f33, f34, f35, f36, f37, f38, f39,
    //        f40, f41, f42, f43, f44, f45, f46, f47, f48, f49
    //        )
    //      ) =>
    //        (
    //          f0, f1, f2, f3, f4, f5, f6, f7, f8, f9,
    //          f10, f11, f12, f13, f14, f15, f16, f17, f18, f19,
    //          f20, f21, f22, f23, f24, f25, f26, f27, f28, f29,
    //          f30, f31, f32, f33, f34, f35, f36, f37, f38, f39,
    //          f40, f41, f42, f43, f44, f45, f46, f47, f48, f49
    //          )
    //    }.first()

    //    var gameArray = Array[Double]()
    //    for (gameFeature <- gameFeatures)
    //      gameArray += 1
    //    val gameVector = new DoubleMatrix(gameArray)
    //    val sims = model.itemFactors.map {
    //      case Row(id, features) =>
    //        var array = Array[Double]()
    //        for (feature <- features)
    //          array += feature
    //        val factorVector = new DoubleMatrix(array)
    //        val sim = cosineSimilarity(factorVector, gameVector)
    //        (id, sim)
    //    }
  }

  private def cosineSimilarity(vec1: DoubleMatrix, vec2: DoubleMatrix): Double = {
    vec1.dot(vec2) / (vec1.norm2() * vec2.norm2())
  }

}
