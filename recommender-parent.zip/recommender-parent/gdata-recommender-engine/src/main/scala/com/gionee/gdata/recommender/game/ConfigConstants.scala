package com.gionee.gdata.recommender.game

/**
 * <code>ConfigConstants</code>.
 * 配置项
 * @author zweig
 * version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:16
 */
object ConfigConstants {

  // 游戏推荐默认配置文件名，该文件放在classpath中
  val CONFIG_FILE = "config.properties"

  // 应用配置项
  val APP_HOST_CONFIG = "host"
  val APP_PORT_CONFIG = "port"
  // spark配置项
  val SPARK_NAME_CONFIG = "spark.name"
  val SPARK_MASTER_CONFIG = "spark.master"
  val SPARK_DRIVER_MEM_CONFIG = "spark.driver.mem"
  val SPARK_EXECUTOR_MEM_CONFIG = "spark.executor.mem"
  val SPARK_UI_PORT_CONFIG = "spark.ui.port"

}

/**
  * 游戏配置项
  */
object GameConfigConstants {

  // 游戏推荐默认配置文件名，该文件放在classpath中
  val CONFIG_FILE = "game.properties"

  // 效率测试
  val TEST_CONFIG = "test"
  // 批处理游戏数量
  val BATCH_CONFIG = "batch"
  // hive中保存的游戏数据表
  val TABLE_IN_HIVE_CONFIG = "hive.game.table"
  // 模型保存路径
  val MODEL_PATH_CONFIG = "model.path"
  // 中间结果表
  val TMP_RESULT_TABLE_CONFIG = "result.table.tmp"
  // mysql配置项
  val RESULT_MYSQL_URL_CONFIG = "mysql.result.url"
  // 保存到mysql中的结果表
  val MYSQL_RESULT_TABLE_CONFIG = "mysql.result.table"
  val QUERY_MYSQL_URL_CONFIG = "mysql.query.url"
  // 查找游戏ID的表
  val MYSQL_QUERY_GAME_ID_TABLE_CONFIG = "mysql.query.table"

  // 特征数
  val RANKS_CONFIG = "ranks"
  // 迭代次数
  val ITERATIONS_CONFIG = "iterations"
  // 正规化因子
  val LAMBDAS_CONFIG = "lambdas"
  // block个数
  val USER_BLOCKS_CONFIG = "userBlocks"
  val ITEM_BLOCKS_CONFIG = "itemBlocks"

}

/**
  * 评估配置项
  */
object GameEvaluateConfig {

  // 游戏推荐默认配置文件名，该文件放在classpath中
  val CONFIG_FILE = "evaluate.properties"

  // 特征数
  val ALS_RANKS_CONFIG = "als.ranks"
  // 迭代次数
  val ALS_ITERATIONS_CONFIG = "als.iterations"
  // 正规化因子
  val ALS_LAMBDAS_CONFIG = "als.lambdas"
  // block个数
  val ALS_USER_BLOCKS_CONFIG = "als.userBlocks"
  val ALS_ITEM_BLOCKS_CONFIG = "als.itemBlocks"

  // 样本条数
  val SAMPLES_CONFIG = "als.samples"

  // 聚类个数
  val KMEANS_CLUSTER_CONFIG = "kmeans.k"
  // 聚类迭代次数
  val KMEANS_ITERATIONS_CONFIG = "kmeans.iterations"
  // 分区个数
  val KMEANS_PARTITIONS_CONFIG = "kmeans.partitions"

}

/**
  * 游戏推荐命令行参数
  *
  * @param conf
  * @param gameConf
  * @param date
  */
case class GameParams(conf: String = null, gameConf: String = null, date: String = null)

/**
  * 评估模型命令行参数
  *
  * @param conf
  * @param evaluateConf
  * @param date
  */
case class GameEvaluateParams(conf: String = null, evaluateConf: String = null, date: String = null)