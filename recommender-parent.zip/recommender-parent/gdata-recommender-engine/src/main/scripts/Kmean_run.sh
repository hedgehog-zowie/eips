#!/bin/bash
#echo
day_id=$(date +%Y%m%d)

/usr/bin/mysql -u appuser -h10.10.10.138 -paaad-fea7!e -P3306 -A bidb  <<EOF

INSERT INTO ETL_JOB_LOG(DAY_ID,JOB_NAME,EVENT_NAME) 
SELECT "$day_id","KMean_recommend","START";

truncate table dlv_category_detail;

INSERT INTO dlv_category_detail
SELECT a.gamec_resource_id,
CASE WHEN a.detail_num IS NULL OR a.detail_num=0 THEN 1 ELSE a.detail_num END  AS detail_num,
CASE WHEN a.dl_num IS NULL OR a.dl_num=0 THEN 1 ELSE a.dl_num END  AS dl_num,
IFNULL(b.category_code,0) AS gamec_category_name,
       IFNULL(c.category_code,0) AS detail_type,
       IFNULL(d.category_code,0) AS con_type,
       IFNULL(e.category_code,0) AS pic_type,
       IFNULL(f.category_code,0) AS two_type
 FROM RPT_GAMEC_RECOMENT_DAILY a
 LEFT JOIN dlv_gamec_category_id b ON a.gamec_category_name=b.category_name AND b.type_name='99'
 LEFT JOIN dlv_gamec_category_id c ON a.detail_type=c.category_name  AND c.type_name='106'
 LEFT JOIN dlv_gamec_category_id d ON a.con_type=d.category_name  AND d.type_name='108'
 LEFT JOIN dlv_gamec_category_id e ON a.pic_type=e.category_name  AND e.type_name='109'
 LEFT JOIN dlv_gamec_category_id f ON a.two_type=f.category_name AND f.type_name='103'
WHERE a.status=1;

TRUNCATE TABLE dlv_gamec_recommend_list;

INSERT INTO dlv_gamec_recommend_list
(gamec_resource_id,detail_num,dl_num,category)
SELECT
  gamec_resource_id,
  detail_num,
  dl_num,
  CONCAT(ROUND((gamec_category_name - min_category_id)/dis_category_id,4) ,' ',
  ROUND((detail_type - min_detail_type)/dis_detail_type,4) ,' ',
  ROUND((con_type - min_con_type)/dis_con_type,4),' ',
  ROUND((pic_type - min_pic_type)/dis_pic_type,4),' ',
  ROUND((two_type - min_two_type)/dis_two_type,4))
FROM
  dlv_category_detail a,
  (SELECT
    MAX(gamec_category_name) AS max_category_id,
    MIN(gamec_category_name) AS min_category_id,
    MAX(gamec_category_name) - MIN(gamec_category_name) AS dis_category_id,
    MAX(detail_type) AS max_detail_type,
    MIN(detail_type) AS min_detail_type,
    MAX(detail_type) - MIN(detail_type) AS dis_detail_type,
    MAX(con_type) AS max_con_type,
    MIN(con_type) AS min_con_type,
    MAX(con_type) - MIN(con_type) AS dis_con_type,
    MAX(pic_type) AS max_pic_type,
    MIN(pic_type) AS min_pic_type,
    MAX(pic_type) - MIN(pic_type) AS dis_pic_type,
    MAX(two_type) AS max_two_type,
    MIN(two_type) AS min_two_type,
    MAX(two_type) - MIN(two_type) AS dis_two_type
  FROM
    dlv_category_detail) f;

EOF

#/home/hadoop/spark/bin/spark-submit --conf spark.ui.port=4089 --class com.ml.recommender.KMeansGame --master spark://10.10.10.111:7077 /data/dxl/KMeansGame.jar
/home/hadoop/spark/bin/spark-submit --conf spark.ui.port=4089 --class com.gionee.gdata.recommender.game.KMeansGame --master spark://10.10.10.111:7077 /home/hadoop/recommender/recommender.jar

/usr/bin/mysql -u appuser -h10.10.10.138 -paaad-fea7!e -P3306 -A bidb  <<EOF

TRUNCATE TABLE dlv_game_recommend;
INSERT INTO dlv_game_recommend(gamec_resource_id,gamec_recommend_id,rank)
SELECT gamec_resource_id,gamec_recommend_id,rank FROM (
SELECT gamec_resource_id,gamec_recommend_id,
               @rownum := @rownum + 1,
               IF(@gamec_resource_id = b.gamec_resource_id, @rank := @rank + 1, @rank := 1) AS rank,
               @gamec_resource_id :=  b.gamec_resource_id FROM(
SELECT a.gamec_resource_id,b.gamec_resource_id AS gamec_recommend_id,b.rank
FROM dlv_game_kmeans a,(
SELECT gamec_resource_id, detail_num,dl_num,ORD,rank
  FROM (SELECT res.gamec_resource_id,
               res.detail_num,
               res.dl_num,
               res.ord,
               @rownum := @rownum + 1,
               IF(@ord_id = res.ord, @rank := @rank + 1, @rank := 1) AS rank,
               @ord_id := res.ord
          FROM (SELECT gamec_resource_id, detail_num,dl_num,ORD
                  FROM dlv_game_kmeans
                  WHERE GAMEC_RESOURCE_ID NOT IN( 117,1971)
                 ORDER BY ORD ASC, dl_num DESC) res,
               (SELECT @rownum := 0, @ord_id := NULL, @rank := 0) a) RESULT
               WHERE rank<6) b WHERE a.ord=b.ord AND a.gamec_resource_id<>b.gamec_resource_id )b,
               (SELECT @rownum := 0, @gamec_resource_id := NULL, @rank := 0)c) d WHERE rank<5;

INSERT INTO ETL_JOB_LOG(DAY_ID,JOB_NAME,EVENT_NAME)
SELECT "$day_id","KMean_recommend","END";
EOF
