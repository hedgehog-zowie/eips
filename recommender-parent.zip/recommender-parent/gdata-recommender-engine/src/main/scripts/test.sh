#!/bin/bash
# train test
curl -X POST -H "Content-Type: application/json" -H "Accept: application/json" -d '{}' --connect-timeout 3600 --max-time 3600 "http://10.10.10.111:8888/recommend/game/train"
curl -X POST -H "Content-Type: application/json" -H "Accept: application/json" --connect-timeout 3600 --max-time 3600 "http://10.10.10.111:8888/recommend/game/train"
# predictBatch test
curl -X POST -H "Content-Type: application/json" -H "Accept: application/json" -d '{"date":"20160828"}' --connect-timeout 3600 --max-time 3600 "http://10.10.10.111:8888/recommend/game/predictBatch"
curl -X POST -H "Content-Type: application/json" -H "Accept: application/json" -d '{"date":"20160828", "gameId":5208}' --connect-timeout 3600 --max-time 3600 "http://10.10.10.111:8888/recommend/game/predictByGame"
curl -X POST -H "Content-Type: application/json" -H "Accept: application/json" -d '{"userId":1, "imei":"fffe799c9f394cb", "gameId":5208}' --connect-timeout 3600 --max-time 3600 "http://10.10.10.111:8888/recommend/game/predictByUserAndGame"
# stop test
curl -X POST -H "Content-Type: application/json" -H "Accept: application/json" --connect-timeout 3600 --max-time 3600 "http://10.10.10.111:8888/recommend/game/stop"
