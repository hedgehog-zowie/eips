#!/bin/bash
# 运行主题推荐程序，部署于10.10.10.88服务器
SPARK_HOME=/home/hadoop/spark-1.6.1-bin-2.2.0
SQOOP_HOME=/home/hadoop/sqoop-1.4.4
RECOMMENDER_HOME=/home/hadoop/recommender
HBASE_HOME=/home/hadoop/hbase-0.96.2-hadoop2
# 数据库配置
dbHost=10.10.10.84
dnPort=3306
dbUser=appuser
dbPassword=se9@3ge1-
dbDatabase=bidb
MYSQL="mysql -h${dbHost} -P ${dnPort} -u${dbUser} -p${dbPassword} --default-character-set=utf8 -A -N ${dbDatabase}"
# 日志表名
logTableName=etl_job_log
# 日志表中job_name字段
jobName=RUN_THEME_RECOMMENDER_SH
# 日志表中event_name字段
eventStart=START
eventEnd=END

# 停止可能存在的尚未完成的任务
kill -9 `ps -ef | grep TrainAndRecommend | grep theme | grep -v grep | awk '{print $2}'`

if [ $# -eq 0 ]
then
  dayId=`date -d "1 days ago" "+%Y%m%d"`
else
  dayId=$1
fi

# 记录日志 - 开始
${MYSQL} -e "INSERT INTO ${logTableName}(day_id, job_name, event_name) VALUES(${dayId}, '${jobName}', '${eventStart}')"

configFile=${RECOMMENDER_HOME}/config/theme.properties
mv ${configFile} ${configFile}.bak
# 修改配置
grep -v "kmeans.hive.features.sql" ${configFile}.bak | grep -v "kmeans.hive.predict.sql" | grep -v "kmeans.hive.score.sql" > ${configFile}
echo "kmeans.hive.features.sql=select theme_id, 'null' as enum_features, concat('type_id', ':', type_id, ',', 'color_id', ':', color_id, ',', 'shape_id', ':', shape_id, ',', 'style_id', ':', style_id, ',', 'artistry_id', ':', artistry_id) as value_features from fact_theme_resource where theme_id is not null and type_id is not null and color_id is not null and shape_id is not null and artistry_id is not null and othertype_id is not null and day_id = ${dayId}" >> ${configFile}
echo "kmeans.hive.predict.sql=select theme_id, 'null' as enum_features, concat('type_id', ':', type_id, ',', 'color_id', ':', color_id, ',', 'shape_id', ':', shape_id, ',', 'style_id', ':', style_id, ',', 'artistry_id', ':', artistry_id) as value_features from fact_theme_resource where theme_id is not null and type_id is not null and color_id is not null and shape_id is not null and artistry_id is not null and othertype_id is not null and day_id = ${dayId}" >> ${configFile}
echo "kmeans.hive.score.sql=select a.imei, a.seq_id, a.score from fact_theme_imei_score a join fact_theme_resource b on a.seq_id = b.theme_id where a.prod_name = 'theme' and a.imei is not null and a.seq_id is not null and a.score is not null and a.score <> 0 and (b.price = 0 or b.price is null) and a.day_id = ${dayId} and b.day_id = ${dayId}" >> ${configFile}
# 执行spark建模与预测
/home/hadoop/spark-1.6.1-bin-2.2.0/bin/spark-submit --class com.gionee.gdata.recommender.kmeans.TrainAndRecommend --conf spark.eventLog.enabled=true --conf spark.eventLog.dir=/home/hadoop/recommender/eventLog --conf spark.ui.port=4089 --conf spark.driver.maxResultSize=4g --driver-memory 16g --executor-memory 1g --executor-cores 1 /home/hadoop/recommender/recommender.jar -c /home/hadoop/recommender/config/theme.properties > /home/hadoop/recommender/log/theme/kmeans_TrainAndRecommend.log 2>&1

# 删除旧表，创建新表
# update 20170711 -- 不再使用HBase
# ${HBASE_HOME}/bin/hbase shell << EOF
# disable 'theme_model'
# drop 'theme_model'
# create 'theme_model', {NAME => 'f', BLOCKSIZE => 16384, IN_MEMORY => true}, {NUMREGIONS => 40, SPLITALGO => 'HexStringSplit'}
# disable 'theme_tag'
# drop 'theme_tag'
# create 'theme_tag', {NAME => 'f', BLOCKSIZE => 16384, IN_MEMORY => true}, {NUMREGIONS => 40, SPLITALGO => 'HexStringSplit'}
# EOF

# 远程到10.10.10.100服务器上执行map-reduce程序，将theme_model和theme_tag两个表的数据导入到HBase
# update 20170711 -- 不再使用HBase
# ssh -n 10.10.10.100 /home/hadoop/gdata-tools/theme_100.sh

# 将数据导出到mysql
# 导出表名（用户、主题、聚类、评分表），需提前建表
HIVE_TABLE_NAME_THEME_KMEANS_USER_ITEM_CLUSTER_SCORE_EXP="theme_kmeans_user_item_cluster_score_exp"
# 导出表名（主题、聚类、评分表），需提前建表
HIVE_TABLE_NAME_THEME_KMEANS_ITEM_CLUSTER_SCORE_EXP="theme_kmeans_item_cluster_score_exp"
# 导出表名（主题机型表），需提前建表
HIVE_TABLE_NAME_THEME_MODEL_EXP="theme_model_exp"
# 导出表名（主题标签表），需提前建表
HIVE_TABLE_NAME_THEME_TAG_EXP="theme_tag_exp"

# 导出数据提取语句（用户、主题、聚类、评分表）
THEME_KMEANS_USER_ITEM_CLUSTER_SCORE_EXP_SQL="insert overwrite table ${HIVE_TABLE_NAME_THEME_KMEANS_USER_ITEM_CLUSTER_SCORE_EXP} select md5(user), user, item, prediction, score from theme_kmeans_user_item_cluster_score"
# 导出数据提取语句（主题、聚类、评分表）
THEME_KMEANS_ITEM_CLUSTER_SCORE_EXP_SQL="insert overwrite table ${HIVE_TABLE_NAME_THEME_KMEANS_ITEM_CLUSTER_SCORE_EXP} select * from theme_kmeans_item_cluster_score"
# 导出数据提取语句（主题机型表）
THEME_MODEL_EXP_SQL="insert overwrite table ${HIVE_TABLE_NAME_THEME_MODEL_EXP} select theme_id, 'model', modeltype from dim_theme_file_attribute_rec"
# 导出数据提取语句（主题标签表）
THEME_TAG_EXP_SQL="insert overwrite table ${HIVE_TABLE_NAME_THEME_TAG_EXP} select theme_id, 'color', color_id from fact_theme_resource where day_id = ${dayId} union all select theme_id, 'style', style_id from fact_theme_resource where day_id = ${dayId} union all select theme_id, 'series', series_id from fact_theme_resource where day_id = ${dayId}"

# 使用spark-sql -e执行上述语句，组织需要导出的数据
${SPARK_HOME}/bin/spark-sql -e "${THEME_KMEANS_USER_ITEM_CLUSTER_SCORE_EXP_SQL}"
${SPARK_HOME}/bin/spark-sql -e "${THEME_KMEANS_ITEM_CLUSTER_SCORE_EXP_SQL}"
${SPARK_HOME}/bin/spark-sql -e "${THEME_MODEL_EXP_SQL}"
${SPARK_HOME}/bin/spark-sql -e "${THEME_TAG_EXP_SQL}"

# 导入表名（用户、主题、聚类、评分表）
MYSQL_TABLE_NAME_THEME_KMEANS_USER_ITEM_CLUSTER_SCORE="theme_kmeans_user_item_cluster_score"
# 导入表名（主题、聚类、评分表）
MYSQL_TABLE_NAME_THEME_KMEANS_ITEM_CLUSTER_SCORE="theme_kmeans_item_cluster_score"
# 导入表名（主题标签表，将机型合并到此表）
MYSQL_TABLE_NAME_THEME_TAG="theme_item_tag"

# 清空旧表
MYSQL_CMD_BASIC="mysql -h10.10.10.119 -P3306 -urecuser -prec)2-gsf49 --default-character-set=utf8 -A -N rec"
${MYSQL_CMD_BASIC} -e "truncate table ${MYSQL_TABLE_NAME_THEME_KMEANS_USER_ITEM_CLUSTER_SCORE}_tmp"
${MYSQL_CMD_BASIC} -e "truncate table ${MYSQL_TABLE_NAME_THEME_KMEANS_ITEM_CLUSTER_SCORE}_tmp"
${MYSQL_CMD_BASIC} -e "truncate table ${MYSQL_TABLE_NAME_THEME_TAG}_tmp"

# 使用sqoop命令导出，先导入tmp表，再改表名，无缝切换
SQOOP_EXPORT_CMD_BASIC="${SQOOP_HOME}/bin/sqoop export --connect jdbc:mysql://10.10.10.119:3306/rec --username recuser --password rec)2-gsf49 --driver com.mysql.jdbc.Driver"
${SQOOP_EXPORT_CMD_BASIC} --table ${MYSQL_TABLE_NAME_THEME_KMEANS_USER_ITEM_CLUSTER_SCORE}_tmp --export-dir /user/hive/warehouse/${HIVE_TABLE_NAME_THEME_KMEANS_USER_ITEM_CLUSTER_SCORE_EXP} --input-fields-terminated-by '\001'
${SQOOP_EXPORT_CMD_BASIC} --table ${MYSQL_TABLE_NAME_THEME_KMEANS_ITEM_CLUSTER_SCORE}_tmp --export-dir /user/hive/warehouse/${HIVE_TABLE_NAME_THEME_KMEANS_ITEM_CLUSTER_SCORE_EXP} --input-fields-terminated-by '\001'
${SQOOP_EXPORT_CMD_BASIC} --table ${MYSQL_TABLE_NAME_THEME_TAG}_tmp --export-dir /user/hive/warehouse/${HIVE_TABLE_NAME_THEME_MODEL_EXP} --input-fields-terminated-by '\001'
${SQOOP_EXPORT_CMD_BASIC} --table ${MYSQL_TABLE_NAME_THEME_TAG}_tmp --export-dir /user/hive/warehouse/${HIVE_TABLE_NAME_THEME_TAG_EXP} --input-fields-terminated-by '\001'

# 修改表名
${MYSQL_CMD_BASIC} -e "rename table ${MYSQL_TABLE_NAME_THEME_KMEANS_USER_ITEM_CLUSTER_SCORE} to ${MYSQL_TABLE_NAME_THEME_KMEANS_USER_ITEM_CLUSTER_SCORE}_bak"
${MYSQL_CMD_BASIC} -e "rename table ${MYSQL_TABLE_NAME_THEME_KMEANS_ITEM_CLUSTER_SCORE} to ${MYSQL_TABLE_NAME_THEME_KMEANS_ITEM_CLUSTER_SCORE}_bak"
${MYSQL_CMD_BASIC} -e "rename table ${MYSQL_TABLE_NAME_THEME_TAG} to ${MYSQL_TABLE_NAME_THEME_TAG}_bak"
${MYSQL_CMD_BASIC} -e "rename table ${MYSQL_TABLE_NAME_THEME_KMEANS_USER_ITEM_CLUSTER_SCORE}_tmp to ${MYSQL_TABLE_NAME_THEME_KMEANS_USER_ITEM_CLUSTER_SCORE}"
${MYSQL_CMD_BASIC} -e "rename table ${MYSQL_TABLE_NAME_THEME_KMEANS_ITEM_CLUSTER_SCORE}_tmp to ${MYSQL_TABLE_NAME_THEME_KMEANS_ITEM_CLUSTER_SCORE}"
${MYSQL_CMD_BASIC} -e "rename table ${MYSQL_TABLE_NAME_THEME_TAG}_tmp to ${MYSQL_TABLE_NAME_THEME_TAG}"
${MYSQL_CMD_BASIC} -e "rename table ${MYSQL_TABLE_NAME_THEME_KMEANS_USER_ITEM_CLUSTER_SCORE}_bak to ${MYSQL_TABLE_NAME_THEME_KMEANS_USER_ITEM_CLUSTER_SCORE}_tmp"
${MYSQL_CMD_BASIC} -e "rename table ${MYSQL_TABLE_NAME_THEME_KMEANS_ITEM_CLUSTER_SCORE}_bak to ${MYSQL_TABLE_NAME_THEME_KMEANS_ITEM_CLUSTER_SCORE}_tmp"
${MYSQL_CMD_BASIC} -e "rename table ${MYSQL_TABLE_NAME_THEME_TAG}_bak to ${MYSQL_TABLE_NAME_THEME_TAG}_tmp"

# 更新缓存
# 测试环境
# UPDATE_URL=http://16.6.10.132:9999/recommender-api/theme/update_cache
# 正式环境
UPDATE_URL=http://yjapi-theme.gionee.com/theme-rec-api/theme/update_cache
curl ${UPDATE_URL}

# 记录日志 - 结束
${MYSQL} -e "INSERT INTO ${logTableName}(day_id, job_name, event_name) VALUES(${dayId}, '${jobName}', '${eventEnd}')"
