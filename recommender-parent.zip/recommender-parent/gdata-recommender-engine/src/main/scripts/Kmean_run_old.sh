#!/bin/bash
#echo
day_id=$(date +%Y%m%d)

/usr/bin/mysql -u appuser -h10.10.10.138 -paaad-fea7!e -P3306 -A bidb  <<EOF

INSERT INTO ETL_JOB_LOG(DAY_ID,JOB_NAME,EVENT_NAME) 
SELECT "$day_id","KMean_recommend","START";

TRUNCATE TABLE dlv_gamec_recommend_list;

INSERT INTO dlv_gamec_recommend_list 
SELECT a.gamec_resource_id,
CASE WHEN a.detail_num IS NULL OR a.detail_num=0 THEN 1 ELSE a.detail_num END  AS detail_num,
CASE WHEN a.dl_num IS NULL OR a.dl_num=0 THEN 1 ELSE a.dl_num END  AS dl_num,
CONCAT(IFNULL(b.id,999),' ',IFNULL(c.id,999),' ',IFNULL(d.id,999),' ',IFNULL(e.id,999),' ',IFNULL(f.id,999)) AS category
 FROM RPT_GAMEC_RECOMENT_DAILY a
 LEFT JOIN dlv_gamec_category_id b ON a.gamec_category_name=b.category_name AND b.type_name='99'
 LEFT JOIN dlv_gamec_category_id c ON a.detail_type=c.category_name  AND c.type_name='106'
 LEFT JOIN dlv_gamec_category_id d ON a.con_type=d.category_name  AND d.type_name='108'
 LEFT JOIN dlv_gamec_category_id e ON a.pic_type=e.category_name  AND e.type_name='109'
 LEFT JOIN dlv_gamec_category_id f ON a.two_type=f.category_name AND f.type_name='103'
WHERE a.status=1;

EOF

#/home/hadoop/spark/bin/spark-submit --conf spark.ui.port=4089 --class com.ml.recommender.KMeansGame --master spark://10.10.10.111:7077 /data/dxl/KMeansGame.jar
/home/hadoop/spark/bin/spark-submit --conf spark.ui.port=4089 --class com.gionee.gdata.recommender.game.KMeansGame --master spark://10.10.10.111:7077 /home/hadoop/recommender/recommender.jar

/usr/bin/mysql -u appuser -h10.10.10.138 -paaad-fea7!e -P3306 -A bidb  <<EOF

TRUNCATE TABLE dlv_game_recommend;
INSERT INTO dlv_game_recommend(gamec_resource_id,gamec_recommend_id,rank) 
SELECT gamec_resource_id,gamec_recommend_id,rank FROM (
SELECT gamec_resource_id,gamec_recommend_id,
               @rownum := @rownum + 1,
               IF(@gamec_resource_id = b.gamec_resource_id, @rank := @rank + 1, @rank := 1) AS rank,
               @gamec_resource_id :=  b.gamec_resource_id FROM(
SELECT a.gamec_resource_id,b.gamec_resource_id AS gamec_recommend_id,b.rank 
FROM dlv_game_kmeans a,(
SELECT gamec_resource_id, detail_num,dl_num,ORD,rank
  FROM (SELECT res.gamec_resource_id,
               res.detail_num,
               res.dl_num,
               res.ord,
               @rownum := @rownum + 1,
               IF(@ord_id = res.ord, @rank := @rank + 1, @rank := 1) AS rank,
               @ord_id := res.ord
          FROM (SELECT gamec_resource_id, detail_num,dl_num,ORD
                  FROM dlv_game_kmeans
                  WHERE GAMEC_RESOURCE_ID NOT IN( 117,1971)
                 ORDER BY ORD ASC, dl_num DESC) res,
               (SELECT @rownum := 0, @ord_id := NULL, @rank := 0) a) RESULT
               WHERE rank<6) b WHERE a.ord=b.ord AND a.gamec_resource_id<>b.gamec_resource_id )b,
               (SELECT @rownum := 0, @gamec_resource_id := NULL, @rank := 0)c) d WHERE rank<5;

INSERT INTO ETL_JOB_LOG(DAY_ID,JOB_NAME,EVENT_NAME) 
SELECT "$day_id","KMean_recommend","END";
EOF
