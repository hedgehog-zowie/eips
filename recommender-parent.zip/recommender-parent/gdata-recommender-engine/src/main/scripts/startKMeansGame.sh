#!/bin/bash
/home/hadoop/spark/bin/spark-submit --conf spark.ui.port=4089 --class com.gionee.gdata.recommender.game.KMeansGame recommender.jar --master spark://10.10.10.111:7077