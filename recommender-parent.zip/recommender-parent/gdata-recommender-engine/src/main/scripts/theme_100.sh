#!/bin/bash
# 由于82集群的hbase版本导致gdata-tools导入数据失败，因此将该数据导入HBase过程放到141集群运行
# 部署于10.10.10.100服务器
GDATA_TOOLS_HOME=/home/hadoop/gdata-tools
# 清除缓存URL，测试环境
url=http://16.6.10.132:9999/recommender-api/theme/clean_cache
# 清除缓存URL，线上环境
# url=

# 导入theme_tag
${GDATA_TOOLS_HOME}/themeTag2HBase.sh > ${GDATA_TOOLS_HOME}/themeTag2HBase.log 2>&1
# 导入theme_model
${GDATA_TOOLS_HOME}/themeModel2HBase.sh > ${GDATA_TOOLS_HOME}/themeModel2HBase.log 2>&1
# 清空缓存
curl ${url}
