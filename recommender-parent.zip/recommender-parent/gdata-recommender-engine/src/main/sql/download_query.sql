-- 下载管理埋点数据查询
select * from dim_sta_tool_app  where app_name = '下载管理';
select * from dim_sta_tool_app  where app_name like '%下载管理%';
select * from fact_sta_tool_user_defined_his where day_id in(20170731, 20170801, 20170802, 20170803) and app_id = 3058 and imei in ('008600211200638','008600216200633') limit 10;
select * from fact_sta_tool_user_defined_his where day_id = 20170807 and app_id = 3058 and imei in ('008600211321988','008600216321983') limit 10;
