-- 1
DROP TABLE IF EXISTS game_user_mac_item_feature_vector;
CREATE TABLE game_user_mac_item_feature_vector(
  user_md5 VARCHAR(255) NOT NULL,
  item_id VARCHAR(255) NOT NULL,
  vector TEXT NOT NULL,
  updated_time TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY(user_md5, item_id)
)ENGINE=InnoDB DEFAULT CHARSET=gb2312;

-- 2
DROP TABLE IF EXISTS game_user_first_tag_feature_vector;
CREATE TABLE game_user_first_tag_feature_vector(
  user_md5 VARCHAR(255) NOT NULL,
  item_id VARCHAR(255) NOT NULL,
  vector DOUBLE NOT NULL,
  updated_time TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY(user_md5, item_id)
)ENGINE=InnoDB DEFAULT CHARSET=gb2312;

-- 3
DROP TABLE IF EXISTS game_user_package_level_feature_vector;
CREATE TABLE game_user_package_level_feature_vector(
  user_md5 VARCHAR(255) NOT NULL,
  item_id VARCHAR(255) NOT NULL,
  vector DOUBLE NOT NULL,
  updated_time TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY(user_md5, item_id)
)ENGINE=InnoDB DEFAULT CHARSET=gb2312;

-- 4
DROP TABLE IF EXISTS game_user_item_similarity_feature_vector;
CREATE TABLE game_user_item_similarity_feature_vector(
  user_md5 VARCHAR(255) NOT NULL,
  item_id VARCHAR(255) NOT NULL,
  vector TEXT NOT NULL,
  updated_time TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY(user_md5, item_id)
)ENGINE=InnoDB DEFAULT CHARSET=gb2312;

-- 5
DROP TABLE IF EXISTS game_item_set;
CREATE TABLE game_item_set(
  item_id VARCHAR(255) NOT NULL,
  updated_time TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY(item_id)
)ENGINE=InnoDB DEFAULT CHARSET=gb2312;

-- 6
DROP TABLE IF EXISTS game_item_default_feature_vector;
CREATE TABLE game_item_default_feature_vector (
  item_id VARCHAR(255) NOT NULL,
  vector1 TEXT NOT NULL,
  vector2 TEXT NOT NULL,
  vector3 TEXT NOT NULL,
  vector4 TEXT NOT NULL,
  updated_time TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY(item_id)
)ENGINE=InnoDB DEFAULT CHARSET=gb2312;