USE game_hall;

SET mapred.reduce.tasks = 15;
SET hive.auto.convert.join = true;
SET mapred.reduce.slowstart.completed.maps = 1.0;

SET mapreduce.map.memory.mb= 4096;
SET mapreduce.map.java.opts= -Xmx3686m;

ADD jar /home/hadoop/taylor/game_hall/udfmd5.jar;
CREATE TEMPORARY function md5 as 'albert_hadoop.Md5';

-- 1、曝光下载基础数据
DROP TABLE IF EXISTS v101_pcvr_recommend;
CREATE TABLE v101_pcvr_recommend AS
SELECT
  md5(imei) AS user_md5,
  gamec_resource_id AS item_id,
  IF(active_type=0, '0', '1') AS flag,
  net_id,
  PMOD(
    DATEDIFF(
      FROM_UNIXTIME(
        UNIX_TIMESTAMP(SUBSTR(do_time, 1, 8),'yyyymmdd'),'yyyy-mm-dd'
      ), '1920-01-01'
    ) - 3, 7)
  AS week,
  CAST(SUBSTR(do_time, 9, 10) AS INT) AS hr
FROM fact_gamec_home_recommend
WHERE (active_type='0' OR active_type='3') AND (net_id='1' OR net_id='2' OR net_id='3' OR net_id='4') AND (LENGTH(imei)=15 AND imei<>'000000000000000');

-- 2、特征向量化
DROP TABLE IF EXISTS v101_pcvr_recommend_vector;
CREATE TABLE v101_pcvr_recommend_vector AS
SELECT
  t1.user_md5,
  t1.item_id,
  t1.flag,
  CONCAT_WS(',',
    t2.vector,
    CAST(t3.vector AS STRING),
    CAST(t4.vector AS STRING),
    t5.vector,
    CASE
        WHEN t1.net_id='1' THEN '1,0,0,0'
        WHEN t1.net_id='2' THEN '0,1,0,0'
        WHEN t1.net_id='3' THEN '0,0,1,0'
        WHEN t1.net_id='4' THEN '0,0,0,1' END,
    CASE
        WHEN t1.week=1 THEN '1,0,0,0,0,0,0'
        WHEN t1.week=2 THEN '0,1,0,0,0,0,0'
        WHEN t1.week=3 THEN '0,0,1,0,0,0,0'
        WHEN t1.week=4 THEN '0,0,0,1,0,0,0'
        WHEN t1.week=5 THEN '0,0,0,0,1,0,0'
        WHEN t1.week=6 THEN '0,0,0,0,0,1,0'
        WHEN t1.week=0 THEN '0,0,0,0,0,0,1' END,
    CASE
        WHEN t1.hr=0 THEN '1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=1 THEN '0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=2 THEN '0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=3 THEN '0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=4 THEN '0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=5 THEN '0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=6 THEN '0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=7 THEN '0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=8 THEN '0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=9 THEN '0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=10 THEN '0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=11 THEN '0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=12 THEN '0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=13 THEN '0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=14 THEN '0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0'
        WHEN t1.hr=15 THEN '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0'
        WHEN t1.hr=16 THEN '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0'
        WHEN t1.hr=17 THEN '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0'
        WHEN t1.hr=18 THEN '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0'
        WHEN t1.hr=19 THEN '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0'
        WHEN t1.hr=20 THEN '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0'
        WHEN t1.hr=21 THEN '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0'
        WHEN t1.hr=22 THEN '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0'
        WHEN t1.hr=23 THEN '0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1' END
  ) AS vector
FROM v101_pcvr_recommend t1
JOIN game_user_mac_item_feature_vector t2
ON (t1.user_md5=t2.user_md5 AND t1.item_id=t2.item_id)
JOIN game_user_first_tag_feature_vector t3
ON (t1.user_md5=t3.user_md5 AND t1.item_id=t3.item_id)
JOIN game_user_package_level_feature_vector t4
ON (t1.user_md5=t4.user_md5 AND t1.item_id=t4.item_id)
JOIN game_user_item_similarity_feature_vector t5
ON (t1.user_md5=t5.user_md5 AND t1.item_id=t5.item_id);