-- 主题推荐-用户、物品、聚类、评分导出表
drop table if exists theme_kmeans_user_item_cluster_score_exp;
create table theme_kmeans_user_item_cluster_score_exp(
  user_md5 string comment '用户MD5',
  userId string comment 'imei',
  itemId string comment '主题id',
  prediction int comment '聚类',
  rating double comment '评分'
)
comment '主题推荐-用户、物品、聚类、评分导出表';

-- 主题推荐-物品、聚类、评分导出表
drop table if exists theme_kmeans_item_cluster_score_exp;
create table theme_kmeans_item_cluster_score_exp(
  itemId string comment '主题id',
  prediction int comment '聚类',
  rating double comment '评分'
)
comment '主题推荐-物品、聚类、评分导出表';

-- 主题推荐-主题机型导出表
drop table if exists theme_model_exp;
create table theme_model_exp(
  itemId string comment '主题id',
  tag_name string comment '标签名',
  tag_value string comment '标签值'
)
comment '主题推荐-主题机型导出表';

-- 主题推荐-主题标签导出表
drop table if exists theme_tag_exp;
create table theme_tag_exp(
  itemId string comment '主题id',
  tag_name string comment '标签名',
  tag_value string comment '标签值'
)
comment '主题推荐-主题标签导出表';

-- 测试语句
insert overwrite table theme_kmeans_user_item_cluster_score_exp select md5(userId), userId, itemId, prediction, rating from theme_kmeans_user_item_cluster_score;
insert overwrite table theme_kmeans_item_cluster_score_exp select * from theme_kmeans_item_cluster_score;
insert overwrite table theme_model_exp select theme_id, 'model', modeltype from dim_theme_file_attribute_rec;
insert overwrite table theme_tag_exp select theme_id, 'color', color_id from fact_theme_resource where day_id = 20170717 union select theme_id, 'style', style_id from fact_theme_resource where day_id = 20170717;



-- 主题推荐-用户、物品、聚类、评分导入mysql表
drop index idx_theme_kmeans_user_item_cluster_score_user_md5 on theme_kmeans_user_item_cluster_score;
drop table if exists theme_kmeans_user_item_cluster_score;
create table theme_kmeans_user_item_cluster_score
(
   user_md5             varchar(32) not null,
   userId                 varchar(32) not null comment '用户',
   itemId                 varchar(32) not null comment '物品',
   cluster              int not null comment '聚类',
   rating                double not null comment '评分'
);
alter table theme_kmeans_user_item_cluster_score comment '用户物品聚类评分表——主题';
create index idx_theme_kmeans_user_item_cluster_score_user_md5 on theme_kmeans_user_item_cluster_score(user_md5);

-- 主题推荐-物品、聚类、评分导入mysql表
drop index idx_theme_kmeans_item_cluster_score_cluster on theme_kmeans_item_cluster_score;
drop index idx_theme_kmeans_item_cluster_score_item on theme_kmeans_item_cluster_score;
drop table if exists theme_kmeans_item_cluster_score;
create table theme_kmeans_item_cluster_score
(
   itemId                 varchar(32) not null comment '物品',
   cluster              int not null comment '聚类',
   rating                double not null comment '评分'
);
alter table theme_kmeans_item_cluster_score comment '物品聚类评分表——主题';
create index idx_theme_kmeans_item_cluster_score_item on theme_kmeans_item_cluster_score(itemId);
create index idx_theme_kmeans_item_cluster_score_cluster on theme_kmeans_item_cluster_score(cluster);

-- 主题推荐-主题标签（合并机型）导入mysql表
drop index idx_item_tag_value on theme_item_tag;
drop index idx_item_tag_name on theme_item_tag;
drop index idx_item_tag_item on theme_item_tag;
drop table if exists theme_item_tag;
create table theme_item_tag
(
   itemId                 varchar(32) not null,
   tag_name             varchar(32) not null,
   tag_value            varchar(32) not null
);
alter table theme_item_tag comment '物品标签表——主题';
create index idx_item_tag_item on theme_item_tag(itemId);
create index idx_item_tag_name on theme_item_tag(tag_name);
create index idx_item_tag_value on theme_item_tag(tag_value);

-- 导出测试语句
sqoop export --connect jdbc:mysql://10.10.10.119:3306/rec --username 'recuser' --password 'rec)2-gsf49' --driver com.mysql.jdbc.Driver --table theme_kmeans_user_item_cluster_score --export-dir /userId/hive/warehouse/theme_kmeans_user_item_cluster_score_exp --input-fields-terminated-by '\001'
sqoop export --connect jdbc:mysql://10.10.10.119:3306/rec --username 'recuser' --password 'rec)2-gsf49' --driver com.mysql.jdbc.Driver --table theme_kmeans_item_cluster_score --export-dir /userId/hive/warehouse/theme_kmeans_item_cluster_score_exp --input-fields-terminated-by '\001'
sqoop export --connect jdbc:mysql://10.10.10.119:3306/rec --username 'recuser' --password 'rec)2-gsf49' --driver com.mysql.jdbc.Driver --table theme_item_tag --export-dir /userId/hive/warehouse/theme_model_exp --input-fields-terminated-by '\001'
sqoop export --connect jdbc:mysql://10.10.10.119:3306/rec --username 'recuser' --password 'rec)2-gsf49' --driver com.mysql.jdbc.Driver --table theme_item_tag --export-dir /userId/hive/warehouse/theme_tag_exp --input-fields-terminated-by '\001'

