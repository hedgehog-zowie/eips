#!/bin/bash
# Gionee game hall Recommend daily version-1.0 游戏大厅每日一荐统一调度脚本 (version-1.0)
# Date     : 2017-11-20
# Added by taylor.huang, don't modify the script file, in addition to me.

# read user valiable
source ~/.bash_profile

#****[LOG VARIABLE START]****************************************************************
starttime=$(date +%s)
logtime=$(date +%Y%m%d)
logname="game_hall.daily.recommend.${logtime}.log"
filepath=$(cd "$(dirname "$0")"; pwd)
logdir=$filepath"/logs"
logfile=$logdir/$logname
#****[LOG VARIABLE END]******************************************************************

echo "***************************************${logtime}**********************************" >> $logfile
echo "Start.Time[`date +%Y-%m-%d\ %H:%M:%S`]: Feature vector extraction for train data job is beginning." >> $logfile

echo "Step1.Time[`date +%Y-%m-%d\ %H:%M:%S`]: 
/home/hadoop/hive/bin/hive --hivevar filepath=$filepath -f $filepath/t_features_work.sql" >> $logfile
/home/hadoop/hive/bin/hive --hivevar filepath=$filepath -f $filepath/t_features_work.sql

echo "Step2.Time[`date +%Y-%m-%d\ %H:%M:%S`]:
/home/hadoop/hadoop-2.2.0/bin/hadoop fs -rm -r hdfs://bis-newdatanode-s2c-89:9000/user/game_hall/daily/lr/*
/home/hadoop/spark-1.6.1-bin-2.2.0/bin/spark-submit
  --master spark://10.10.10.121:7077
  --driver-memory 4g --executor-memory 6g --executor-cores 6
  --class com.gionee.gdata.recommender.lr.Train $filepath/recommender.jar -c $filepath/lr.game.hall.properties" >> $logfile
/home/hadoop/hadoop-2.2.0/bin/hadoop fs -rm -r hdfs://bis-newdatanode-s2c-89:9000/user/game_hall/daily/lr/*
/home/hadoop/spark-1.6.1-bin-2.2.0/bin/spark-submit \
  --master spark://10.10.10.121:7077 \
  --driver-memory 4g --executor-memory 6g --executor-cores 6 \
  --class com.gionee.gdata.recommender.lr.Train $filepath/recommender.jar -c $filepath/lr.game.hall.properties

echo "Step3.Time[`date +%Y-%m-%d\ %H:%M:%S`]:
/home/hadoop/hive/bin/hive --hivevar filepath=$filepath -f $filepath/p_features_work.sql" >> $logfile
/home/hadoop/hive/bin/hive --hivevar filepath=$filepath -f $filepath/p_features_work.sql

filepath1="/data/dataget/recommend/game_hall/daily"
echo "Step4.Time[`date +%Y-%m-%d\ %H:%M:%S`]:
/home/hadoop/hive/bin/hive -e 'SELECT * FROM game_hall.p_fact_imei_vector'>$filepath1/feature_vector/p_fact_imei_vector" >> $logfile
/home/hadoop/hive/bin/hive -e 'SELECT * FROM game_hall.p_fact_imei_vector'>$filepath1/feature_vector/p_fact_imei_vector
echo "DEFAULT_USER  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0" >>$filepath1/p_fact_imei_vector

echo "Step5.Time[`date +%Y-%m-%d\ %H:%M:%S`]:
/home/hadoop/hive/bin/hive -e 'SELECT * FROM game_hall.p_fact_item_vector'>$filepath1/feature_vector/p_fact_item_vector" >> $logfile
/home/hadoop/hive/bin/hive -e 'SELECT * FROM game_hall.p_fact_item_vector'>$filepath1/feature_vector/p_fact_item_vector

echo "Step6.Time[`date +%Y-%m-%d\ %H:%M:%S`]:
/home/hadoop/hive/bin/hive -e 'SELECT * FROM game_hall.p_fact_imei_item_vector'>$filepath1/feature_vector/p_fact_imei_item_vector" >> $logfile
/home/hadoop/hive/bin/hive -e 'SELECT * FROM game_hall.p_fact_imei_item_vector'>$filepath1/feature_vector/p_fact_imei_item_vector
echo "DEFAULT_USER  DEFAULT_ITEM  0,0,0">>$filepath1/p_fact_imei_item_vector

echo "Step7.Time[`date +%Y-%m-%d\ %H:%M:%S`]:
rm -r $filepath1/model/lr
/home/hadoop/hadoop-2.2.0/bin/hadoop fs -get hdfs://bis-newdatanode-s2c-89:9000/user/game_hall/daily/lr $filepath1/model" >> $logfile
rm -r $filepath1/model/lr
/home/hadoop/hadoop-2.2.0/bin/hadoop fs -get hdfs://bis-newdatanode-s2c-89:9000/user/game_hall/daily/lr $filepath1/model

endtime=$(date +%s)
interval_s=$[$endtime-$starttime]
echo "Time[`date +%Y-%m-%d\ %H:%M:%S`]: Successful. Time consuming ${interval_s}s!" >>  $logfile
echo "***************************************${logtime}**********************************" >> $logfile

echo "Time[`date +%Y-%m-%d\ %H:%M:%S`]: Generated file [$logfile]!"
#############################xiaojp @20171125 add#####################################
echo "[`date +%Y-%m-%d\ %H:%M:%S`]:             start trasfer file to aliyun server" >>  $logfile
echo "[`date +%Y-%m-%d\ %H:%M:%S`]:             trasfer model file to 114.55.13.60"  >>  $logfile
scp -P 34543 -r /data/dataget/recommend/game_hall/daily/model gamerecdev@114.55.13.60:/data/recommender/game_hall/daily 2>&1 >>$logfile
echo "[`date +%Y-%m-%d\ %H:%M:%S`]:             start tar and compress the directory"  >>  $logfile
if [[ -f /data/dataget/recommend/game_hall/gamerec.tgz ]]; then
                rm -rf /data/dataget/recommend/game_hall/gamerec.tgz
fi
cd /data/dataget/recommend/game_hall/daily && tar -zcvf /data/dataget/recommend/game_hall/gamerec.tgz . >>$logfile 2>&1
echo "[`date +%Y-%m-%d\ %H:%M:%S`]:             end tar and compress "  >>  $logfile
echo "[`date +%Y-%m-%d\ %H:%M:%S`]:             start push tgz file to 114.55.12.22"  >>  $logfile
scp -P 34543 -r /data/dataget/recommend/game_hall/gamerec.tgz gamerecdev@114.55.12.22:/data/recommender/game_hall/daily/ 2>&1 >>$logfile
echo "[`date +%Y-%m-%d\ %H:%M:%S`]:             end push"  >>  $logfile
echo "[`date +%Y-%m-%d\ %H:%M:%S`]:             generate md5 value to md5_file"  >>  $logfile
md5sum /data/dataget/recommend/game_hall/gamerec.tgz >/data/dataget/recommend/game_hall/md5_file
echo "[`date +%Y-%m-%d\ %H:%M:%S`]:             push md5 file "  >>  $logfile
scp -P 34543 -r /data/dataget/recommend/game_hall/md5_file gamerecdev@114.55.12.22:/data/recommender/game_hall/daily/ 2>&1 >>$logfile
echo "[`date +%Y-%m-%d\ %H:%M:%S`]:             end program "  >>  $logfile