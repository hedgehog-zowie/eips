------------------------------------------------------------------------------------------------------
-- 1、40款待推荐列表，按批次分区
------------------------------------------------------------------------------------------------------
SET mapred.reduce.tasks = 15;
SET hive.auto.convert.join = true;
SET mapred.reduce.slowstart.completed.maps = 1.0;

DROP TABLE IF EXISTS recommended_game;
CREATE TABLE IF NOT EXISTS recommended_game (
 game_id STRING
) PARTITIONED BY (recommend_id STRING)
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
STORED AS textfile;

LOAD DATA LOCAL INPATH '/data/hcb/game_hall/daily/game_id_1.txt'
INTO TABLE recommended_game partition(recommend_id='20171213');

LOAD DATA LOCAL INPATH '/data/hcb/game_hall/daily/game_id_2.txt'
INTO TABLE recommended_game partition(recommend_id='20171214');


------------------------------------------------------------------------------------------------------
-- 2.1 腾讯算法效果评估
------------------------------------------------------------------------------------------------------
SELECT
  day_id ,
  COUNT(CASE WHEN op_type='exposure' THEN imei END),
  COUNT(CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END),
  COUNT(CASE WHEN dl_flag='1' THEN imei END),
  COUNT(DISTINCT CASE WHEN op_type='exposure' THEN imei END),
  COUNT(DISTINCT CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END),
  COUNT(DISTINCT CASE WHEN dl_flag='1' THEN imei END)
FROM (
  SELECT
    t1.*,
    t2.GAMEC_RESOURCE_ID AS game_id1
  FROM fact_gamec_exposure_detail_NEW
 t1
  INNER JOIN dim_gamec_game t2
  ON (t1.game_id=t2.gamec_id AND t2.gamec_source='game')
  WHERE t1.day_id>=20171213
  AND  t1.location_id='0'
  AND (md5(t1.imei) LIKE '%1' OR md5(t1.imei) LIKE '%2' OR md5(t1.imei) LIKE '%3')
) a
INNER JOIN (
  SELECT * FROM dim_gamec_game_recommend
) b
ON a.game_id1=b.game_id
GROUP BY a.day_id;

------------------------------------------------------------------------------------------------------
-- 2.2 金立算法效果评估
------------------------------------------------------------------------------------------------------
SELECT
  day_id ,
  COUNT(CASE WHEN op_type='exposure' THEN imei END),
  COUNT(CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END),
  COUNT(CASE WHEN dl_flag='1' THEN imei END),
  COUNT(DISTINCT CASE WHEN op_type='exposure' THEN imei END),
  COUNT(DISTINCT CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END),
  COUNT(DISTINCT CASE WHEN dl_flag='1' THEN imei END)
FROM (
  SELECT
    t1.*,
    t2.GAMEC_RESOURCE_ID AS game_id1
  FROM fact_gamec_exposure_detail_NEW
 t1
  INNER JOIN dim_gamec_game t2
  ON (t1.game_id=t2.gamec_id AND t2.gamec_source='game')
  WHERE t1.day_id>=20171213
  AND  t1.location_id='0'
  AND (md5(t1.imei) LIKE '%a' OR md5(t1.imei) LIKE '%b' OR md5(t1.imei) LIKE '%c')
) a
INNER JOIN (
  SELECT * FROM default.dim_gamec_game_recommend
) b
ON a.game_id1=b.game_id
GROUP BY a.day_id;

------------------------------------------------------------------------------------------------------
-- 2.3 游戏运营效果评估
------------------------------------------------------------------------------------------------------
SELECT
  day_id ,
  COUNT(CASE WHEN op_type='exposure' THEN imei END),
  COUNT(CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END),
  COUNT(CASE WHEN dl_flag='1' THEN imei END),
  COUNT(DISTINCT CASE WHEN op_type='exposure' THEN imei END),
  COUNT(DISTINCT CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END),
  COUNT(DISTINCT CASE WHEN dl_flag='1' THEN imei END)
FROM (
  SELECT
    t1.*,
    t2.GAMEC_RESOURCE_ID AS game_id1
  FROM fact_gamec_exposure_detail_NEW
 t1
  INNER JOIN dim_gamec_game t2
  ON (t1.game_id=t2.gamec_id AND t2.gamec_source='game')
  WHERE t1.day_id>=20171213
  AND  t1.location_id='0'
  AND !(md5(t1.imei) LIKE '%1' OR md5(t1.imei) LIKE '%2' OR md5(t1.imei) LIKE '%3' OR md5(t1.imei) LIKE '%a' OR md5(t1.imei) LIKE '%b' OR md5(t1.imei) LIKE '%c')
) a
INNER JOIN (
  SELECT * FROM default.dim_gamec_game_recommend
) b
ON a.game_id1=b.game_id
GROUP BY a.day_id ORDER BY a.day_id;

------ 82机器上新的评估算法

add jar /data/hcb/udfmd5.jar;
create temporary function md5 as 'albert_hadoop.Md5';

-- 金立算法
SELECT
  day_id ,b.game_id,a.name,
  COUNT(CASE WHEN op_type='exposure' THEN imei END) as a1,
  COUNT(CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END) as a2,
  COUNT(CASE WHEN dlsucess_flag='1' THEN imei END) as a3,
  round(COUNT(CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END)/COUNT(CASE WHEN op_type='exposure' THEN imei END),4) as a31,
  round(COUNT(CASE WHEN dlsucess_flag='1' THEN imei END)/COUNT(CASE WHEN op_type='exposure' THEN imei END),4) as a4,
  COUNT(DISTINCT CASE WHEN op_type='exposure' THEN imei END) as a5,
  COUNT(DISTINCT CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END) as a6,
  COUNT(DISTINCT CASE WHEN dlsucess_flag='1' THEN imei END) as a7,
  round(COUNT(DISTINCT CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END)/COUNT(DISTINCT CASE WHEN op_type='exposure' THEN imei END),4) as a71,
  round(COUNT(DISTINCT CASE WHEN dlsucess_flag='1' THEN imei END)/COUNT(DISTINCT CASE WHEN op_type='exposure' THEN imei END),4) as a8
FROM (
  SELECT
    t1.*,
    t2.GAMEC_RESOURCE_ID AS game_id1,
    t2.name
  FROM fact_gamec_exposure_detail_NEW
 t1
  INNER JOIN dim_gamec_game t2
  ON (t1.game_id=t2.gamec_id AND t2.gamec_source='game')
  WHERE t1.day_id>=20180211 AND t1.day_id<=20180222
  AND  t1.location_id='0'
  AND (md5(t1.imei) LIKE '%a' OR md5(t1.imei) LIKE '%b' OR md5(t1.imei) LIKE '%c')
) a
INNER JOIN (
  SELECT game_id FROM dim_gamec_game_recommend
) b
ON a.game_id1=b.game_id
GROUP BY a.day_id,b.game_id,a.name
ORDER BY a.day_id,b.game_id,a.name;

-- 腾讯算法
SELECT
  day_id ,b.game_id,a.name,
  COUNT(CASE WHEN op_type='exposure' THEN imei END) as a1,
  COUNT(CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END) as a2,
  COUNT(CASE WHEN dlsucess_flag='1' THEN imei END) as a3,
  round(COUNT(CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END)/COUNT(CASE WHEN op_type='exposure' THEN imei END),4) as a31,
  round(COUNT(CASE WHEN dlsucess_flag='1' THEN imei END)/COUNT(CASE WHEN op_type='exposure' THEN imei END),4) as a4,
  COUNT(DISTINCT CASE WHEN op_type='exposure' THEN imei END) as a5,
  COUNT(DISTINCT CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END) as a6,
  COUNT(DISTINCT CASE WHEN dlsucess_flag='1' THEN imei END) as a7,
  round(COUNT(DISTINCT CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END)/COUNT(DISTINCT CASE WHEN op_type='exposure' THEN imei END),4) as a71,
  round(COUNT(DISTINCT CASE WHEN dlsucess_flag='1' THEN imei END)/COUNT(DISTINCT CASE WHEN op_type='exposure' THEN imei END),4) as a8
FROM (
  SELECT
    t1.*,
    t2.GAMEC_RESOURCE_ID AS game_id1,
    t2.name
  FROM fact_gamec_exposure_detail_NEW
 t1
  INNER JOIN dim_gamec_game t2
  ON (t1.game_id=t2.gamec_id AND t2.gamec_source='game')
  WHERE t1.day_id>=20180211 AND t1.day_id<=20180222
  AND  t1.location_id='0'
  AND (md5(t1.imei) LIKE '%1' OR md5(t1.imei) LIKE '%2' OR md5(t1.imei) LIKE '%3')
) a
INNER JOIN (
  SELECT game_id FROM dim_gamec_game_recommend
) b
ON a.game_id1=b.game_id
GROUP BY a.day_id,b.game_id,a.name
ORDER BY a.day_id,b.game_id,a.name;

-- 金立运营
SELECT
  day_id ,b.game_id,a.name,
  COUNT(CASE WHEN op_type='exposure' THEN imei END) as a1,
  COUNT(CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END) as a2,
  COUNT(CASE WHEN dlsucess_flag='1' THEN imei END) as a3,
  round(COUNT(CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END)/COUNT(CASE WHEN op_type='exposure' THEN imei END),4) as a31,
  round(COUNT(CASE WHEN dlsucess_flag='1' THEN imei END)/COUNT(CASE WHEN op_type='exposure' THEN imei END),4) as a4,
  COUNT(DISTINCT CASE WHEN op_type='exposure' THEN imei END) as a5,
  COUNT(DISTINCT CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END) as a6,
  COUNT(DISTINCT CASE WHEN dlsucess_flag='1' THEN imei END) as a7,
  round(COUNT(DISTINCT CASE WHEN (dl_flag='1' AND dl_intersrc NOT LIKE '%gamedetail%') OR (object LIKE 'gdetail%') THEN imei END)/COUNT(DISTINCT CASE WHEN op_type='exposure' THEN imei END),4) as a71,
  round(COUNT(DISTINCT CASE WHEN dlsucess_flag='1' THEN imei END)/COUNT(DISTINCT CASE WHEN op_type='exposure' THEN imei END),4) as a8
FROM (
  SELECT
    t1.*,
    t2.GAMEC_RESOURCE_ID AS game_id1,
    t2.name
  FROM fact_gamec_exposure_detail_NEW
 t1
  INNER JOIN dim_gamec_game t2
  ON (t1.game_id=t2.gamec_id AND t2.gamec_source='game')
  WHERE t1.day_id>=20180211 AND t1.day_id<=20180222
  AND  t1.location_id='0'
  AND !(md5(t1.imei) LIKE '%a' OR md5(t1.imei) LIKE '%b' OR md5(t1.imei) LIKE '%c' OR md5(t1.imei) LIKE '%1' OR md5(t1.imei) LIKE '%2' OR md5(t1.imei) LIKE '%3')
) a
INNER JOIN (
  SELECT game_id FROM dim_gamec_game_recommend
) b
ON a.game_id1=b.game_id
GROUP BY a.day_id,b.game_id,a.name
ORDER BY a.day_id,b.game_id,a.name;