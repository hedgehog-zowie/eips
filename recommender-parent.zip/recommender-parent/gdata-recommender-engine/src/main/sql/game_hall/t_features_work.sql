USE game_hall;

set mapred.reduce.tasks = 15;
SET hive.auto.convert.join = true;
SET mapred.reduce.slowstart.completed.maps = 1.0;


------------------------------------------------------------------------------------------------------
-- 1、  生成40款待推荐物品表（fact_item） 记录数：40
-- SELECT
--  PERCENTILE_APPROX(
--    CAST(package_size AS INT), ARRAY(0.25, 0.5, 0.75)
--  )
-- FROM fact_gamec_home_recommend;
------------------------------------------------------------------------------------------------------
DROP TABLE IF EXISTS fact_item;
CREATE TABLE fact_item AS
SELECT
  t1.gamec_resource_id AS item_id,
  CASE
    WHEN package_size <=36 THEN 0.25
    WHEN package_size >36 AND package_size <=38 THEN 0.5
    WHEN package_size >38 AND package_size <=430 THEN 0.75
    WHEN package_size >430 THEN 1 END
  AS package_size_level,
  ROUND (
    IF (t2.gamec_resource_id IS NOT NULL, t2.game_click_ct, 0)/t1.game_imp_ct, 5
  ) AS item_ctr_user
FROM (
  SELECT
    gamec_resource_id,
    CAST (COLLECT_SET(package_size)[0] AS INT) AS package_size,
    COUNT(1) AS game_imp_ct
  FROM fact_gamec_home_recommend
  WHERE active_type='0' GROUP BY gamec_resource_id
) t1
LEFT OUTER JOIN (
  SELECT
    gamec_resource_id,
    COUNT(1) AS game_click_ct
  FROM fact_gamec_home_recommend
  WHERE active_type='1' GROUP BY gamec_resource_id
) t2
ON (t1.gamec_resource_id=t2.gamec_resource_id);

------------------------------------------------------------------------------------------------------
-- 2、 用户-40款待推荐游戏物品相似度评分表（fact_imei_item） 记录数：5796594
------------------------------------------------------------------------------------------------------
DROP TABLE IF EXISTS fact_imei_item;
CREATE TABLE fact_imei_item AS
SELECT
  t4.imei,
  t4.item_id,
  t4.score,
  IF (t5.imei IS NOT NULL AND t5.gamec_resource_id IS NOT NULL, '1,0', '0,1') AS is_follow
FROM (
  SELECT
    t3.imei,
    t3.item_id,
    SUM(t3.similar_score) AS score
  FROM (
    SELECT
      t1.imei,
      t1.game_id,
      t2.itemid AS item_id,
      t2.similar_score
    FROM (
      SELECT
        t.imei,
        t.gamec_resource_id AS game_id
      FROM (
        SELECT DISTINCT imei, gamec_resource_id FROM fact_gamec_home_recommend_imei WHERE imp_flag='1' AND click_flag='1'
      ) t
    ) t1 JOIN default.dlv_item_03 t2
    ON (t1.game_id=t2.similar_item)
  ) t3 GROUP BY t3.imei, t3.item_id
) t4
LEFT OUTER JOIN (
  SELECT
    DISTINCT imei,
      gamec_resource_id
    FROM fact_gamec_home_recommend WHERE active_type='2'
) t5
ON (t4.imei=t5.imei AND t4.item_id=t5.gamec_resource_id);

------------------------------------------------------------------------------------------------------
-- 3、 机型表（fact_mac） 记录数：133
------------------------------------------------------------------------------------------------------
DROP TABLE IF EXISTS fact_mac;
CREATE TABLE fact_mac AS
SELECT
  t5.mac_id,
  t5.mac_ctr_item,
  IF (t6.mac_ctr_game IS NOT NULL, t6.mac_ctr_game, 0) AS mac_ctr_game
FROM (
  SELECT
    t1.mac_id,
    IF (t2.mac_id IS NOT NULL, t2.mac_click_ct_1, 0)/t1.mac_imp_ct_1 AS mac_ctr_item
  FROM (
    SELECT
      mac_id,
      COUNT (1) AS mac_imp_ct_1
    FROM fact_gamec_home_recommend WHERE active_type='0' AND mac_id !='null'
    GROUP BY mac_id
  ) t1
  LEFT OUTER JOIN (
    SELECT
      mac_id,
      COUNT (1) AS mac_click_ct_1
    FROM fact_gamec_home_recommend WHERE active_type='1'
    GROUP BY mac_id
  ) t2
  ON (t1.mac_id=t2.mac_id)
) t5
LEFT OUTER JOIN (
  SELECT
    t3.mac_id,
    IF (t4.mac_id IS NOT NULL, t4.mac_click_ct, 0)/t3.mac_imp_ct AS mac_ctr_game
  FROM (
    SELECT
      mac_id,
      COUNT (1) AS mac_imp_ct
    FROM fact_gamec_home_recommend_imei WHERE imp_flag='1'
    GROUP BY mac_id
  ) t3
  LEFT OUTER JOIN (
    SELECT
      mac_id,
      COUNT (1) AS mac_click_ct
    FROM fact_gamec_home_recommend_imei WHERE imp_flag='1' AND click_flag='1'
    GROUP BY mac_id
  ) t4
  ON (t3.mac_id=t4.mac_id)
) t6
ON (t5.mac_id=t6.mac_id);

------------------------------------------------------------------------------------------------------
-- 4、 用户表（fact_imei）  用户标签偏好得分表记录：14936247  用户表：113732188
------------------------------------------------------------------------------------------------------
ADD FILE udf_1.py;
DROP TABLE IF EXISTS imei_prefer_tag_score;
CREATE TABLE imei_prefer_tag_score AS
SELECT
  TRANSFORM (t2.imei, t2.scores)
USING 'python udf_1.py'
AS (
  imei,
  p_1, p_2, p_3, p_4, p_5, p_6, p_7, p_8, p_9, p_10, p_11, p_12, p_13, p_14)
FROM (
  SELECT t1.imei,
  CONCAT_WS(',', COLLECT_SET(t1.score)) AS scores
  FROM (
    SELECT
      imei,
      CONCAT_WS(':', first_tab_id, prefer_score) AS score
    FROM fact_game_first_score
  ) t1
  GROUP BY t1.imei
) t2;

DROP TABLE IF EXISTS fact_imei;
CREATE TABLE fact_imei AS
SELECT
  t1.imei,
  t1.gamec_resource_id AS item_id,
  t1.active_type AS flag,
  t4.imei_ctr_item,
  t7.imei_ctr_game,
  t8.p_1,
  t8.p_2,
  t8.p_3,
  t8.p_4,
  t8.p_5,
  t8.p_6,
  t8.p_7,
  t8.p_8,
  t8.p_9,
  t8.p_10,
  t8.p_11,
  t8.p_12,
  t8.p_13,
  t8.p_14,
  t1.mac_id,
  CASE
    WHEN t1.net_id='1' THEN '1,0,0,0'
    WHEN t1.net_id='2' THEN '0,1,0,0'
    WHEN t1.net_id='3' THEN '0,0,1,0'
    WHEN t1.net_id='4' THEN '0,0,0,1' END
  AS net_id,
  PMOD(
    DATEDIFF(
      FROM_UNIXTIME(
        UNIX_TIMESTAMP(SUBSTR(t1.do_time, 1, 8),'yyyymmdd'),'yyyy-mm-dd'
      ), '1920-01-01'
    ) - 3, 7
  ) AS week,
  SUBSTR(t1.do_time, 9, 10) AS hr
FROM (
  SELECT * FROM fact_gamec_home_recommend
  WHERE (active_type='0' OR active_type='1') AND (net_id='1' OR net_id='2' OR net_id='3' OR net_id='4')
) t1
JOIN (
  SELECT
    t2.imei,
    IF (t3.imei IS NOT NULL, t3.user_click_ct_1, 0)/t2.user_imp_ct_1 AS imei_ctr_item
  FROM (
    SELECT
      imei,
      COUNT (1) AS user_imp_ct_1
    FROM fact_gamec_home_recommend WHERE active_type='0'
    GROUP BY imei
  ) t2
  LEFT OUTER JOIN (
    SELECT
      imei,
      COUNT (1) AS user_click_ct_1
    FROM fact_gamec_home_recommend WHERE active_type='1'
    GROUP BY imei
  ) t3
  ON (t2.imei=t3.imei)
) t4
ON (t1.imei=t4.imei)
JOIN (
  SELECT
    t5.imei,
    if (t6.imei is not null, t6.user_click_ct, 0)/t5.user_imp_ct AS imei_ctr_game
  FROM (
    SELECT
      imei,
      COUNT (1) AS user_imp_ct
    FROM fact_gamec_home_recommend_imei WHERE imp_flag='1'
    GROUP BY imei
  ) t5
  LEFT OUTER JOIN (
    SELECT
      imei,
      COUNT (1) AS user_click_ct
    FROM fact_gamec_home_recommend_imei WHERE click_flag='1' AND imp_flag='1'
    GROUP BY imei
  ) t6
  ON (t5.imei=t6.imei)
) t7
ON (t1.imei=t7.imei)
JOIN imei_prefer_tag_score t8
ON (t1.imei=t8.imei);

------------------------------------------------------------------------------------------------------
-- 5、 生成训练集表
------------------------------------------------------------------------------------------------------
-- 5.1 游戏特征  记录数：15315764
DROP TABLE IF EXISTS recommend_train;
CREATE TABLE recommend_train AS
SELECT
  t1.imei,
  t1.item_id,
  t1.flag,
  t1.imei_ctr_item,
  t1.imei_ctr_game,
  t4.mac_ctr_item,
  t4.mac_ctr_game,
  t1.p_1,
  t1.p_2,
  t1.p_3,
  t1.p_4,
  t1.p_5,
  t1.p_6,
  t1.p_7,
  t1.p_8,
  t1.p_9,
  t1.p_10,
  t1.p_11,
  t1.p_12,
  t1.p_13,
  t1.p_14,
  t2.package_size_level,
  t2.item_ctr_user,
  t3.score,
  t3.is_follow,
  t1.net_id,
  t1.week,
  t1.hr
FROM fact_imei t1
JOIN fact_item t2
ON (t1.item_id=t2.item_id)
JOIN fact_imei_item t3
ON (t1.imei=t3.imei AND t1.item_id=t3.item_id)
JOIN fact_mac t4
ON (t1.mac_id=t4.mac_id);

------------------------------------------------------------------------------------------------------
-- 6、 生成训练特征向量表
------------------------------------------------------------------------------------------------------
-- 6.1 游戏特征训练集 特征向量化  记录数：13786684  用户数：140601
ADD FILE udf_2.py;
DROP TABLE IF EXISTS recommend_train_vector;
CREATE TABLE recommend_train_vector AS
SELECT
  TRANSFORM (
    imei,
    item_id,
    flag,
    imei_ctr_item,
    imei_ctr_game,
    mac_ctr_item,
    mac_ctr_game,
    p_1,
    p_2,
    p_3,
    p_4,
    p_5,
    p_6,
    p_7,
    p_8,
    p_9,
    p_10,
    p_11,
    p_12,
    p_13,
    p_14,
    package_size_level,
    item_ctr_user,
    score,
    is_follow,
    net_id,
    week,
    hr)
USING 'python udf_2.py'
AS (
  imei,
  item_id,
  flag,
  feature_vector)
FROM recommend_train;
