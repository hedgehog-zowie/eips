package com.gionee.gdata.common

import com.gionee.gdata.recommender.game.GameConfigConstants

/**
  * Created by Zweig on 2016/9/1.
  * Email: hedgehog.zowie@gmail.com
  */
object ConfigLoaderTest {

  def main(args: Array[String]) {
    val properties = ConfigLoader.load("test.properties")
    println(properties)
    val batchSize = properties.getProperty(GameConfigConstants.BATCH_CONFIG, "10").toInt
    println(s"batchSize: $batchSize")
  }


}
