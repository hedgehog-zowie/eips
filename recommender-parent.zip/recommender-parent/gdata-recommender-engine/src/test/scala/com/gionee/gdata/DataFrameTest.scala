package com.gionee.gdata

import org.apache.spark.sql.{DataFrame, Row, SQLContext}
import org.apache.spark.{SparkConf, SparkContext}

/**
  * Created by Zweig on 2017/4/19.
  * Email: hedgehog.zowie@gmail.com
  */
object DataFrameTest {

  val sparkConf = new SparkConf().setAppName("test").setMaster("local[*]")
  val sc = new SparkContext(sparkConf)
  val sqlContext = new SQLContext(sc)

  val dataList: List[(Int, String, Int, Double, String, Int, Int, Int, Int)] = List(
    (1, "male", 37, 10d, "no", 3, 18, 7, 4),
    (2, "female", 27, 4d, "no", 4, 14, 6, 4),
    (3, "female", 32, 15d, "yes", 1, 12, 1, 4),
    (4, "male", 57, 15d, "yes", 5, 18, 6, 5),
    (5, "male", 22, 0.75d, "no", 2, 17, 6, 3),
    (6, "female", 32, 1.5d, "no", 2, 17, 5, 5),
    (7, "female", 22, 0.75d, "no", 2, 12, 1, 3),
    (8, "male", 57, 15d, "yes", 2, 14, 4, 4),
    (9, "female", 32, 15d, "yes", 4, 16, 1, 2),
    (10, "male", 22, 1.5d, "no", 4, 14, 4, 5),
    (11, "male", 37, 15d, "yes", 2, 20, 7, 2),
    (12, "male", 27, 4d, "yes", 4, 18, 6, 4),
    (13, "male", 47, 15d, "yes", 5, 17, 6, 4),
    (14, "female", 22, 1.5d, "no", 2, 17, 5, 4),
    (15, "female", 27, 4d, "no", 4, 14, 5, 4),
    (16, "female", 37, 15d, "yes", 1, 17, 5, 5),
    (17, "female", 37, 15d, "yes", 2, 18, 4, 3),
    (18, "female", 22, 0.75d, "no", 3, 16, 5, 4),
    (19, "female", 22, 1.5d, "no", 2, 16, 5, 5),
    (20, "female", 27, 10d, "yes", 2, 14, 1, 5),
    (21, "female", 22, 1.5d, "no", 2, 16, 5, 5),
    (22, "female", 22, 1.5d, "no", 2, 16, 5, 5),
    (23, "female", 27, 10d, "yes", 4, 16, 5, 4),
    (24, "female", 32, 10d, "yes", 3, 14, 1, 5),
    (25, "male", 37, 4d, "yes", 2, 20, 6, 4))

  val data = sqlContext.createDataFrame(dataList).toDF("id", "gender", "age", "yearsmarried",
    "children", "religiousness", "education", "occupation", "rating")

  val dataList2: List[(Int, String, Int, Double, String, Int, Int, Int, Int)] = List(
    (1, "male", 37, 10d, "no", 3, 18, 7, 4),
    (2, "female", 27, 4d, "no", 4, 14, 6, 4)
  )
  val data2 = sqlContext.createDataFrame(dataList2).toDF("id", "gender", "age", "yearsmarried",
    "children", "religiousness", "education", "occupation", "rating")

  def main(args: Array[String]): Unit = {
    data.foreach {
      case Row(id, gender, age, yearsmarried, children, religiousness, education, occupation, rating) =>
        println(id)
    }

    //    testJoinNotExist(data)
    //    data.printSchema()
    //    useCode(data)
    //    useSql(data)
  }

  def testJoinNotExist(dataFrame: DataFrame): Unit = {
    val exDataFrame = data.where(data("age").equalTo(37))
    exDataFrame.show()
    val joined = data.join(data2, Seq("id"), "left")
    joined.show()
    //    val exJoined = data.join(data2, Seq("id"), "left").select(
    //      data("id"), data("gender"), data("age"), data("yearsmarried"),data("children"),
    //      data("religiousness"), data("education"), data("occupation"), data("rating"),
    //      data2("id"), data2("gender"), data2("age"), data2("yearsmarried"),data2("children"),
    //      data2("religiousness"), data2("education"), data2("occupation"), data2("rating")
    //    )
    val exJoined = data.join(data2, Seq("id", "age"), "left").where(data2("gender").isNull)
    exJoined.show()
  }

  def useCode(dataFrame: DataFrame): Unit = {
    //    dataFrame.repartition(dataFrame("gender")).mapPartitions()
    //      .orderBy("age").show(100)
  }

  //  def useSql(dataFrame: DataFrame): Unit = {
  //    data.registerTempTable("Affairs")
  //    val s1 = "row_number() over(partition by gender order by age) as rowNumber, "
  //    val s2 = "rank() over(partition by gender order by age) as ranks, "
  //    val s3 = "dense_rank() over(partition by gender order by age) as denseRank, "
  //    val s4 = "percent_rank() over(partition by gender order by age) as percentRank "
  //    val df = sqlContext.sql("select gender, age, " + s1 + s2 + s3 + s4 + " from Affairs")
  //    df.show(50)
  //  }

}
