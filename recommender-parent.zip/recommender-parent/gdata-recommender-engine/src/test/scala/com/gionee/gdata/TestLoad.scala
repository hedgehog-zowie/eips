package com.gionee.gdata

import org.apache.spark.mllib.classification.LogisticRegressionModel
import org.apache.spark.mllib.linalg.Vector
import org.apache.spark.{SparkConf, SparkContext}

/**
  * Created by Zweig on 2017/5/22.
  * Email: hedgehog.zowie@gmail.com
  */
object TestLoad {
  def main(args: Array[String]) {
    val conf = new SparkConf().setAppName("abc").setMaster("local[*]")
    val sparkContext = new SparkContext(conf)
    val logisticRegressionModel3: LogisticRegressionModel = LogisticRegressionModel.load(sparkContext, "data/test_logistic_model")
    val vector: Vector = logisticRegressionModel3.weights
  }
}
