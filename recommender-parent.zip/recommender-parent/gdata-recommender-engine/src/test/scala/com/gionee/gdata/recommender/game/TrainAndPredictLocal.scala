package com.gionee.gdata.recommender.game

import com.gionee.gdata.common.utils.FileUtil4S
import org.apache.spark.ml.recommendation._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SQLContext, SaveMode}
import org.apache.spark.{SparkConf, SparkContext}

/**
  * Created by Zweig on 2016/8/27.
  * Email: hedgehog.zowie@gmail.com
  */
object TrainAndPredictLocal {

  case class UserGameRating(userId: Int, imei: String, gameId: Int, rating: Float)

  object UserGameRating {
    def parse(str: String): UserGameRating = {
      val fields = str.split(",")
      UserGameRating(fields(0).trim.toInt, fields(1).trim, fields(2).trim.toInt, fields(3).trim.toFloat)
    }
  }

  val path = "/data/spark/data/game/"
  val gameModelPath = path + "model"
  val gameResultPath = path + "evaluate"
  val gamePredictPath = path + "predict"

  def main(args: Array[String]) {
    val sparkConf = new SparkConf().setAppName("TrainAndPredict").setMaster("local[*]")
    val sc = new SparkContext(sparkConf)
    val sqlContext = new SQLContext(sc)

    // 从文件中读取
    val userGameRatings = sc.textFile("userGames.csv").map(UserGameRating.parse(_)).cache()
    val numRatings = userGameRatings.count()
    println(s"Got $numRatings ratings")

    test(userGameRatings)

    //    trainModel(sc, userGameRatings)

    //    evaluateModel(sc, userGameRatings)

    //    predict(sc, userGameRatings)

    sc.stop()
  }

  def test(userGameRatings: RDD[UserGameRating]): Unit = {
    val r1 = userGameRatings.map {
      ugr => (ugr.userId, Seq(ugr.gameId, ugr.rating))
    }
    var r_first = r1.first()
    println(s"r1.first = $r_first")

    val r2 = r1.reduceByKey(_ ++ _)
    r_first = r2.first()
    println(s"r2.first = $r_first")

    val rr1 = userGameRatings.map {
      ugr => (ugr.userId, 1)
    }
    var rr_first = rr1.first()
    println(s"rr1.first = $rr_first")
    val rr2 = rr1.reduceByKey(_ + _)
    rr_first = rr2.first()
    println(s"rr2.first = $rr_first")

    val rrr1 = userGameRatings.map {
      ugr => (ugr.userId, "astr,")
    }
    var rrr_first = rrr1.first()
    println(s"rrr1.first = $rrr_first")
    val rrr2 = rrr1.reduceByKey(_ + _)
    rrr_first = rrr2.first()
    println(s"rrr2.first = $rrr_first")
  }

  def trainModel(sc: SparkContext, userGameRatings: RDD[UserGameRating]): Unit = {
    val sqlContext = new SQLContext(sc)
    import sqlContext.implicits._

    val als = new ALS()
      .setUserCol("userId")
      .setItemCol("gameId")
      .setRatingCol("rating")
      .setPredictionCol("prediction")
      .setRank(50)
      .setMaxIter(10)
      .setRegParam(0.0001)
      .setNumBlocks(4)
    val model = als.fit(userGameRatings.toDF())

    // 保存模型
    FileUtil4S.deleteHdfsFile(sc, gameModelPath)
    model.save(gameModelPath)
  }

  def evaluateModel(sc: SparkContext, testRatings: RDD[UserGameRating]): Unit = {
    val sqlContext = new SQLContext(sc)
    import sqlContext.implicits._

    val model = ALSModel.load(gameModelPath)
    val predictions = model.transform(testRatings.toDF()).cache()

    // 保存结果
    FileUtil4S.deleteHdfsFile(sc, gameResultPath)
    predictions.select("userId", "imei", "gameId", "rating", "prediction").rdd.map {
      case Row(userId: Int, imei: String, gameId: Int, rating: Float, prediction: Float) =>
        userId + "," + imei + "," + gameId + "," + rating + "," + prediction.toString
    }.saveAsTextFile(gameResultPath)

    val mse = predictions.select("rating", "prediction").rdd
      .flatMap { case Row(rating: Float, prediction: Float) =>
        val err = rating.toDouble - prediction
        val err2 = err * err
        if (err2.isNaN) {
          None
        } else {
          Some(err2)
        }
      }.mean()
    val rmse = math.sqrt(mse)
    println(s"Test RMSE = $rmse.")
  }

  def predict(sc: SparkContext, userGameRatings: RDD[UserGameRating]): Unit = {
    val sqlContext = new SQLContext(sc)
    import sqlContext.implicits._

    val users = userGameRatings.map {
      ugr => (ugr.userId, ugr.imei)
    }.distinct().cache()
    val games = userGameRatings.map(_.gameId).distinct().cache()
    // 用户、游戏笛卡尔积
    val userGames = users.cartesian(games).map {
      case ((userId, imei), gameId) =>
        UserGameRating(userId, imei, gameId, 0)
    }.cache()
    val numUsers = users.count()
    val numGames = games.count()
    val numUserGames = userGames.count()
    println(s"评测 $numUsers 个用户、$numGames 款游戏 共 $numUserGames 个组合的评分")

    val model = ALSModel.load(gameModelPath)
    var tUserId = 0
    val tStr = ""
    val tMap: java.util.HashMap[java.lang.Integer, java.lang.String] = new java.util.HashMap()
    val pivotPredictions = model.transform(userGames.toDF()).cache().
      select("userId", "imei", "gameId", "prediction").
      orderBy($"userId".asc, $"prediction".desc)
    //      groupBy("userId", "imei").
    //      pivot("gameId").
    //      avg("prediction").
    //      orderBy($"userId".asc).
    //      show()

    pivotPredictions.printSchema()
    saveResultToMysql(pivotPredictions)

  }

  def saveResultToMysql(df: DataFrame): Unit = {
    val prop = new java.util.Properties
    prop.setProperty("user", "appuser")
    prop.setProperty("password", "se9@3ge1-")
    df.write.mode(SaveMode.Append).jdbc("jdbc:mysql://10.10.10.84:3306/test", "dlv_game_recommend_test", prop)
  }

}
