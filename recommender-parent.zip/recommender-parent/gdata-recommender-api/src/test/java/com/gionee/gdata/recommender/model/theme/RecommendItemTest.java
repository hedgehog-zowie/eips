package com.gionee.gdata.recommender.model.theme;

import com.gionee.gdata.recommender.common.ABID;
import com.gionee.gdata.recommender.common.Operation;
import com.gionee.gdata.recommender.model.RecommendItem;
import com.google.common.collect.Sets;
import org.junit.Test;

import java.util.Set;

import static org.junit.Assert.assertEquals;

/**
 * <code>RecommendItemTest</code>.
 * ${DESCRIPTION}
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/8/30 19:01
 */
public class RecommendItemTest {

    @Test
    public void testGetOpeThemeList() {
        Set<RecommendItem> set = Sets.newLinkedHashSet();
        set.add(new RecommendItem("itemId0", Operation.theme_hot, ABID.REC_THEME_K.toString()));
        set.add(new RecommendItem("itemId0", Operation.theme_hot, ABID.REC_THEME_K.toString()));
        set.add(new RecommendItem("itemId1", Operation.theme_hot, ABID.REC_THEME_K.toString()));
        assertEquals(set.size(), 2);
    }

}
