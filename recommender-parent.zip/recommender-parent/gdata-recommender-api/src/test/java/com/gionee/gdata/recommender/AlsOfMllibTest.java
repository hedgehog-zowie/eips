package com.gionee.gdata.recommender;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.mllib.recommendation.MatrixFactorizationModel;
import org.databene.contiperf.junit.ContiPerfRule;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;

/**
 * <code>AlsOfMllibTest</code>.
 * ${DESCRIPTION}
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/28 15:26
 */
public class AlsOfMllibTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(AlsOfMllibTest.class);

    private static final String modelPath = "E:\\gdata\\trunk\\models\\download\\als\\model_mllib";
    /**
     * spark配置
     */
    private static final SparkConf SPARK_CONF = new SparkConf().
            setAppName("als_mllib").
            setMaster("local[*]");
    /**
     * spark上下文
     */
    private static final SparkContext SPARK_CONTEXT = new SparkContext(SPARK_CONF);

    private static MatrixFactorizationModel model;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        model = MatrixFactorizationModel.load(SPARK_CONTEXT, modelPath);
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Rule
    public ContiPerfRule i = new ContiPerfRule();

    @org.junit.Test
    public void test() {
        Date startDate = new Date();
        model.recommendProducts(0, 100);
        Date endDate = new Date();
        LOGGER.info("完成推荐，开始时间【{}】，结束时间【{}】，，耗时【{} ms】", startDate, endDate, endDate.getTime() - startDate.getTime());
    }

}
