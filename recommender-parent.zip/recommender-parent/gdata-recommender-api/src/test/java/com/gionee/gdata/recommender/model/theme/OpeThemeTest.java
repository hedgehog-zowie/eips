package com.gionee.gdata.recommender.model.theme;

import com.clearspring.analytics.util.Lists;
import com.gionee.gdata.common.utils.JsonUtil;
import com.gionee.gdata.recommender.common.Operation;
import com.gionee.gdata.recommender.common.ThemeScene;
import org.junit.Test;

import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * <code>OpeThemeTest</code>.
 * ${DESCRIPTION}
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/8/23 16:40
 */
public class OpeThemeTest {

    @Test
    public void testGetOpeThemeList() {
        List<OperationTheme> opeThemeList = Lists.newArrayList();
        opeThemeList.add(new OperationTheme("itemId0", "itemInfo", ThemeScene.theme_new, Operation.theme_new_urgent, "ruleKey", "ruleValue", new Date().getTime()));
        opeThemeList.add(new OperationTheme("itemId1", "itemInfo", ThemeScene.theme_new, Operation.theme_new_urgent, "ruleKey", "ruleValue", new Date().getTime()));
        System.out.println(JsonUtil.toJson(opeThemeList));
    }

}
