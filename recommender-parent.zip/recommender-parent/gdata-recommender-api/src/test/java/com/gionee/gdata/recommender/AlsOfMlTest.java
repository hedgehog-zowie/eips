package com.gionee.gdata.recommender;

import com.clearspring.analytics.util.Lists;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.ml.recommendation.ALSModel;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.databene.contiperf.junit.ContiPerfRule;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.List;

/**
 * <code>AlsOfMlTest</code>.
 * ${DESCRIPTION}
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/28 15:26
 */
public class AlsOfMlTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(AlsOfMlTest.class);

    private static final String modelPath = "E:\\gdata\\trunk\\models\\download\\als\\model_ml";
    /**
     * spark配置
     */
    private static final SparkConf SPARK_CONF = new SparkConf().
            setAppName("als_ml").
            setMaster("local[*]");
    /**
     * spark上下文
     */
    private static final SparkContext SPARK_CONTEXT = new SparkContext(SPARK_CONF);
    private static final SQLContext sqlContext = new SQLContext(SPARK_CONTEXT);

    private static ALSModel alsModel;
    private static int itemSize0 = 24;
    private static DataFrame userItems0;
    private static int itemSize1 = 242;
    private static DataFrame userItems1;
    private static int itemSize2 = 2427;
    private static DataFrame userItems2;
    private static int itemSize3 = 24270;
    private static DataFrame userItems3;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        alsModel = ALSModel.load(modelPath);
        List<UserItem> userItemList0 = Lists.newArrayList();
        for (int i = 0; i < itemSize0; i++) {
            userItemList0.add(new UserItem(0, i));
        }
        List<UserItem> userItemList1 = Lists.newArrayList();
        for (int i = 0; i < itemSize1; i++) {
            userItemList1.add(new UserItem(0, i));
        }
        List<UserItem> userItemList2 = Lists.newArrayList();
        for (int i = 0; i < itemSize2; i++) {
            userItemList2.add(new UserItem(0, i));
        }
        List<UserItem> userItemList3 = Lists.newArrayList();
        for (int i = 0; i < itemSize3; i++) {
            userItemList3.add(new UserItem(0, i));
        }
        userItems0 = sqlContext.createDataFrame(userItemList0, UserItem.class);
        userItems1 = sqlContext.createDataFrame(userItemList1, UserItem.class);
        userItems2 = sqlContext.createDataFrame(userItemList2, UserItem.class);
        userItems3 = sqlContext.createDataFrame(userItemList3, UserItem.class);
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Rule
    public ContiPerfRule i = new ContiPerfRule();

    @org.junit.Test
    public void test() {
        LOGGER.info("开始预测，物品数量【{}】，开始时间【{}】", itemSize0, new Date());
        alsModel.transform(userItems0).show();
        LOGGER.info("完成预测，物品数量【{}】，开始时间【{}】", itemSize0, new Date());

        LOGGER.info("开始预测，物品数量【{}】，开始时间【{}】", itemSize1, new Date());
        alsModel.transform(userItems1).show();
        LOGGER.info("完成预测，物品数量【{}】，开始时间【{}】", itemSize1, new Date());

        LOGGER.info("开始预测，物品数量【{}】，开始时间【{}】", itemSize2, new Date());
        alsModel.transform(userItems2).show();
        LOGGER.info("完成预测，物品数量【{}】，开始时间【{}】", itemSize2, new Date());

        LOGGER.info("开始预测，物品数量【{}】，开始时间【{}】", itemSize3, new Date());
        alsModel.transform(userItems3).show();
        LOGGER.info("完成预测，物品数量【{}】，开始时间【{}】", itemSize3, new Date());
    }

    static public class UserItem {
        private int userId;
        private int itemId;
        private double rating;
        private double prediction;

        public UserItem(){}

        public UserItem(int user, int item) {
            this.userId = user;
            this.itemId = item;
        }

        public int getUserId() {
            return userId;
        }

        public void setUserId(int userId) {
            this.userId = userId;
        }

        public int getItemId() {
            return itemId;
        }

        public void setItemId(int itemId) {
            this.itemId = itemId;
        }

        public double getRating() {
            return rating;
        }

        public void setRating(double rating) {
            this.rating = rating;
        }

        public double getPrediction() {
            return prediction;
        }

        public void setPrediction(double prediction) {
            this.prediction = prediction;
        }
    }

}
