package com.gionee.gdata.recommender.service;

import com.gionee.gdata.data.mybatis.mapper.recommender.gamehall.GameItemFeatureVectorMapper;
import com.gionee.gdata.data.mybatis.mapper.recommender.gamehall.GameUserFeatureVectorMapper;
import com.gionee.gdata.data.mybatis.mapper.recommender.gamehall.GameUserItemFeatureVectorMapper;
import com.gionee.gdata.data.mybatis.mapper.recommender.gamehall.GameVariableFeatureVectorMapper;
import com.gionee.gdata.data.redis.repository.recommender.game.GameUserFeatureVectorRepository;
import com.gionee.gdata.data.redis.repository.recommender.game.GameUserItemFeatureVectorRepository;
import com.gionee.gdata.data.redis.repository.recommender.game.GameVariableFeatureVectorRepository;
import com.gionee.gdata.recommender.common.FeatureCode;
import com.gionee.gdata.recommender.service.gamehall.GameFeatureService;
import org.apache.spark.mllib.linalg.Vector;
import org.databene.contiperf.PerfTest;
import org.databene.contiperf.junit.ContiPerfRule;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Calendar;
import java.util.Map;

/**
 * <code>GameFeatureServiceTest</code>.
 * ${DESCRIPTION}
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2018/1/10 15:36
 */
public class GameFeatureServiceTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(GameFeatureServiceTest.class);

    private static GameFeatureService gameFeatureService;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        String[] configs = {
                "/config/redis/spring-gdata-data-redis.xml",
                "/config/mybatis/spring-gdata-data-mybatis.xml",
        };
        AbstractApplicationContext context = new ClassPathXmlApplicationContext(
                configs, GameFeatureServiceTest.class);
        LOGGER.info("GameFeatureServiceTest Running.");
        context.registerShutdownHook();

        GameUserFeatureVectorMapper gameUserFeatureVectorMapper = context.getBean(GameUserFeatureVectorMapper.class);
        GameItemFeatureVectorMapper gameItemFeatureVectorMapper = context.getBean(GameItemFeatureVectorMapper.class);
        GameUserItemFeatureVectorMapper gameUserItemFeatureVectorMapper = context.getBean(GameUserItemFeatureVectorMapper.class);
        GameVariableFeatureVectorMapper gameVariableFeatureVectorMapper = context.getBean(GameVariableFeatureVectorMapper.class);

        GameUserFeatureVectorRepository gameUserFeatureVectorRepository = context.getBean(GameUserFeatureVectorRepository.class);
        GameUserItemFeatureVectorRepository gameUserItemFeatureVectorRepository = context.getBean(GameUserItemFeatureVectorRepository.class);
        GameVariableFeatureVectorRepository gameVariableFeatureVectorRepository = context.getBean(GameVariableFeatureVectorRepository.class);

        gameFeatureService = new GameFeatureService();
        gameFeatureService.setGameUserFeatureVectorMapper(gameUserFeatureVectorMapper);
        gameFeatureService.setGameItemFeatureVectorMapper(gameItemFeatureVectorMapper);
        gameFeatureService.setGameUserItemFeatureVectorMapper(gameUserItemFeatureVectorMapper);
        gameFeatureService.setGameVariableFeatureVectorMapper(gameVariableFeatureVectorMapper);
        gameFeatureService.setGameUserFeatureVectorRepository(gameUserFeatureVectorRepository);
        gameFeatureService.setGameUserItemFeatureVectorRepository(gameUserItemFeatureVectorRepository);
        gameFeatureService.setGameVariableFeatureVectorRepository(gameVariableFeatureVectorRepository);
        gameFeatureService.cacheFeatureVector();
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Rule
    public ContiPerfRule i = new ContiPerfRule();

    @Test
    public void testGenerateVector() {
        Vector vector = gameFeatureService.generateVector("0.0,0.0,0.08001726204747063,0.2026891717116591,1.8868830499999993,0.14084945,0.9567770999999998,0.2816989,0.7600874499999999,0,0.16876955,0,0.16876955,0.42254834999999996,0.5913179,0,0.14084945,0.2816989");
        System.out.println(vector);
    }

    @Test
    public void testAllGenerateVector() {
        String userMd5 = "0000a1abf4784e76d9bce237ad1363c3";
        String net = "wf";
        Calendar calendar = Calendar.getInstance();
        String dayOfWeek = String.valueOf(calendar.get(Calendar.DAY_OF_WEEK));
        String hourOfDay = String.valueOf(calendar.get(Calendar.HOUR_OF_DAY));
        Map<String, Vector> vectorMap = gameFeatureService.generateVector(userMd5, net, dayOfWeek, hourOfDay);
        for (Map.Entry<String, Vector> entry : vectorMap.entrySet()) {
            System.out.println(entry.getKey() + ":" + entry.getValue());
        }
    }

    @Test
    @PerfTest(invocations = 10000, threads = 10, duration = 10000)
//    @Required(throughput = 3000)
    public void testGenerateVectorPerformance() {
        gameFeatureService.generateVector("0.0,0.0,0.08001726204747063,0.2026891717116591,1.8868830499999993,0.14084945,0.9567770999999998,0.2816989,0.7600874499999999,0,0.16876955,0,0.16876955,0.42254834999999996,0.5913179,0,0.14084945,0.2816989");
    }

    @Test
    @PerfTest(invocations = 10000, threads = 10, duration = 10000)
//    @Required(throughput = 3000)
    public void testAllGenerateVectorPerformance() {
        String userMd5 = "0000a1abf4784e76d9bce237ad1363c3";
        String net = "wf";
        Calendar calendar = Calendar.getInstance();
        String dayOfWeek = String.valueOf(calendar.get(Calendar.DAY_OF_WEEK));
        String hourOfDay = String.valueOf(calendar.get(Calendar.HOUR_OF_DAY));
        gameFeatureService.generateVector(userMd5, net, dayOfWeek, hourOfDay);
    }

    @Test
    @PerfTest(invocations = 10000, threads = 10, duration = 10000)
//    @Required(throughput = 3000)
    public void testGenerateUserVectorPerformance() {
        gameFeatureService.generateUserVector("0000a1abf4784e76d9bce237ad1363c3");
    }

    @Test
    @PerfTest(invocations = 10000, threads = 10, duration = 10000)
//    @Required(throughput = 3000)
    public void testGenerateNetVariableVectorPerformance() {
        gameFeatureService.generateVariableVector(FeatureCode.NET.getCode(), "wf");
    }

    @Test
    @PerfTest(invocations = 10000, threads = 10, duration = 10000)
//    @Required(throughput = 3000)
    public void testGenerateWeekVariableVectorPerformance() {
        Calendar calendar = Calendar.getInstance();
        String dayOfWeek = String.valueOf(calendar.get(Calendar.DAY_OF_WEEK));
        gameFeatureService.generateVariableVector(FeatureCode.NET.getCode(), dayOfWeek);
    }

    @Test
    @PerfTest(invocations = 10000, threads = 10, duration = 10000)
//    @Required(throughput = 3000)
    public void testGenerateHourVariableVectorPerformance() {
        Calendar calendar = Calendar.getInstance();
        String hourOfDay = String.valueOf(calendar.get(Calendar.HOUR_OF_DAY));
        gameFeatureService.generateVariableVector(FeatureCode.NET.getCode(), hourOfDay);
    }

}
