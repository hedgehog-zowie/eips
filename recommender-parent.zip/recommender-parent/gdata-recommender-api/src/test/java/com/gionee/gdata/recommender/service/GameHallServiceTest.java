package com.gionee.gdata.recommender.service;

import com.gionee.gdata.data.mybatis.mapper.message.MessageMapper;
import com.gionee.gdata.data.mybatis.mapper.message.OriginalMessageMapper;
import com.gionee.gdata.recommender.model.gamehall.GameDailyRecommendResult;
import com.gionee.gdata.recommender.service.gamehall.GameHallService;
import org.apache.spark.mllib.linalg.Vector;
import org.databene.contiperf.PerfTest;
import org.databene.contiperf.Required;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * <code>GameHallServiceTest</code>.
 * ${DESCRIPTION}
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2018/1/10 14:52
 */
//@RunWith(SpringJUnit4ClassRunner.class)
// 1.4以前版本
//@SpringApplicationConfiguration(classes = Application.class)
// 1.4以后版本
//@SpringBootTest(classes=Application.class)
public class GameHallServiceTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(GameHallServiceTest.class);

    @Autowired
    private static GameHallService gameHallService;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        String[] configs = {
                "/config/redis/spring-gdata-data-redis.xml",
                "/config/mybatis/spring-gdata-data-mybatis.xml",
        };
        AbstractApplicationContext context = new ClassPathXmlApplicationContext(
                configs, GameHallServiceTest.class);
        LOGGER.info("GameHallServiceTest Running.");
        context.registerShutdownHook();

        gameHallService = context.getBean(GameHallService.class);
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testGetDailyRecommendResult() {
        GameDailyRecommendResult gameDailyRecommendResult = gameHallService.getDailyRecommendResult("000030ecbb4da5744dc66e5cdb95b1bc", "wf");
        System.out.println(gameDailyRecommendResult);
    }

    @Test
    @PerfTest(invocations = 10000, threads = 10, duration = 10000)
    @Required(throughput = 10000)
    public void testGetDailyRecommendResultPerformance() {
        gameHallService.getDailyRecommendResult("000030ecbb4da5744dc66e5cdb95b1bc", "wf");
    }

}
