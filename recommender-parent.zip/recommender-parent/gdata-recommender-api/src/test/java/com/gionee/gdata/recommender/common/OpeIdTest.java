package com.gionee.gdata.recommender.common;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * <code>OperationStrategyTest</code>.
 * ${DESCRIPTION}
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/8/22 11:17
 */
public class OpeIdTest {

    @Test
    public void testGetStrategy() {
        assertEquals(Operation.valueOf("theme_new_force"), Operation.theme_new_force);
        assertEquals(Operation.valueOf("theme_new_random"), Operation.theme_new_random);
        assertEquals(Operation.valueOf("theme_new_urgent"), Operation.theme_new_urgent);
        assertEquals(Operation.valueOf("theme_hot"), Operation.theme_hot);
        assertEquals(Operation.valueOf(""), null);
    }

}
