/**
 * <code>package-info</code>.
 * 推荐系统接口
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:57
 */
package com.gionee.gdata.recommender;
