package com.gionee.gdata.recommender.common.comparator;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Map;

/**
 * <code>IntegerKeyDoubleValueComparator</code>.
 * String为key, Integer为value的map比较器
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/13 15:57
 */
public class IntegerKeyDoubleValueComparator implements Comparator<Integer>, Serializable {

    /**
     * 略
     */
    private Map<Integer, Double> base;

    /**
     * 略
     *
     * @param base 略
     */
    IntegerKeyDoubleValueComparator(final Map<Integer, Double> base) {
        this.base = base;
    }

    /**
     * 略
     *
     * @param a 略
     * @param b 略
     * @return 略
     */
    @Override
    public int compare(final Integer a, final Integer b) {
        return base.get(a) > base.get(b) ? -1 : 1;
    }

}
