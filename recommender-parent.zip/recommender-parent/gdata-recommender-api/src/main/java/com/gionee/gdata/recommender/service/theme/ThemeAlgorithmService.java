package com.gionee.gdata.recommender.service.theme;

import com.gionee.gdata.data.mybatis.entity.recommender.theme.ItemClusterScore;
import com.gionee.gdata.data.mybatis.entity.recommender.theme.ThemeUserItemFilter;
import com.gionee.gdata.data.mybatis.entity.recommender.theme.UserItemClusterScore;
import com.gionee.gdata.data.mybatis.mapper.recommender.theme.ThemeUserItemFilterMapper;
import com.gionee.gdata.data.mybatis.mapper.recommender.theme.UserItemClusterScoreMapper;
import com.gionee.gdata.data.redis.entity.recommender.theme.Result;
import com.gionee.gdata.recommender.common.ABID;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * <code>ThemeAlgorithmService</code>.
 * 主题算法服务类
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/8/28 10:39
 */
@Service
public class ThemeAlgorithmService {

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ThemeAlgorithmService.class);

    /**
     * 用户物品聚类评分mapper
     */
    @Autowired
    private UserItemClusterScoreMapper userItemClusterScoreMapper;

    /**
     * 用户推荐未下载过滤mapper
     */
    @Autowired
    private ThemeUserItemFilterMapper themeUserItemFilterMapper;

    /**
     * 主题机型服务
     */
    @Autowired
    private ThemeModelService themeModelService;

    /**
     * 主题聚类服务
     */
    @Autowired
    private ThemeClusterService themeClusterService;

    /**
     * 下载的评分
     */
    @Value(value = "${recommender.api.theme.downloadScore}")
    private Double downloadScore;

    /**
     * 使用聚类算法计算结果
     *
     * @param imeiMd5 imei号的md5
     * @param model   机型编号
     * @return 结果列表
     */
    public List<Result> computeResultListUseKMeans(final String imeiMd5, final String model, final Integer resultSize) {
        List<Result> resultList = Lists.newArrayList();

        // 获取用户物品聚类评分
        List<UserItemClusterScore> userItemClusterScoreList = userItemClusterScoreMapper.findUserItemClusterScoreByUserMd5(imeiMd5);
        // 若没有获取到用户物品聚类评分，则直接返回
        if (userItemClusterScoreList == null || userItemClusterScoreList.size() == 0) {
            return resultList;
        }

        // 获取机型下的主题
        Set<String> themeSet = themeModelService.getItemByModel(model);
        // 若该机型下没有可用主题，则直接返回
        if (themeSet.size() == 0) {
            return resultList;
        }

        // 聚类集合
        Set<Integer> clusterSet = Sets.newHashSet();
        // 已下载过的主题集合
        // Set<String> downloadedItemSet = Sets.newHashSet();
        // 聚类评分
        Map<Integer, Double> userClusterScoreMap = Maps.newHashMap();
        Map<Integer, Integer> userClusterTimesMap = Maps.newHashMap();
        for (UserItemClusterScore userItemClusterScore : userItemClusterScoreList) {
            Integer cluster = userItemClusterScore.getCluster();
            LOGGER.info("聚类：" + cluster);
            if (cluster != null) {
                clusterSet.add(cluster);
            }
            String item = userItemClusterScore.getItem();
            Double score = userItemClusterScore.getScore();
            // 评分>=downloadScore的物品才是下载过的物品
//            if (item != null && score != null && score >= downloadScore) {
//                downloadedItemSet.add(userItemClusterScore.getItem());
//            }
            // 用户聚类评分求和并计数
            Integer oldTimes = userClusterTimesMap.get(cluster);
            if (oldTimes == null) {
                userClusterTimesMap.put(cluster, 1);
            } else {
                userClusterTimesMap.put(cluster, oldTimes + 1);
            }
            Double newScore = userItemClusterScore.getScore();
            Double oldScore = userClusterScoreMap.get(cluster);
            if (oldScore == null) {
                userClusterScoreMap.put(cluster, newScore);
            } else {
                userClusterScoreMap.put(cluster, oldScore + newScore);
            }
        }
        // 用户聚类评分求平均
        for (Map.Entry<Integer, Double> entry : userClusterScoreMap.entrySet()) {
            Integer key = entry.getKey();
            Double value = entry.getValue();
            Integer times = userClusterTimesMap.get(key);
            // 使用log10降权
            entry.setValue(Math.log10(value / times + 10));
        }

        // 这些聚类下的所有主题聚类评分
        Set<ItemClusterScore> itemClusterScoreSet = themeClusterService.getItemByCluster(clusterSet);
        // 获取推荐四次未下载或者推荐两天未下载的商品集合
        List<ThemeUserItemFilter> themeFilterList = themeUserItemFilterMapper.findAllUserFilterTheme(imeiMd5);
        // 未下载主题集合
        Set<String> themeFilterSet = Sets.newHashSet();
        for (ThemeUserItemFilter themeUserItemFilter : themeFilterList) {
            themeFilterSet.add(themeUserItemFilter.getItem());
        }
        // 已存在的系列集合
        Set<String> existSeriesSet = Sets.newHashSet();
        // 过滤用户已评分的物品 并 根据机型列表过滤已下架商品
        // 过滤推荐四次未下载或者推荐两天未下载的商品    2017-10-23 15:27:20
        List<ItemClusterScore> filteredItemClusterScoreList = Lists.newArrayList();
        // 所有物品集合，分系列保存
        Map<String, List<ItemClusterScore>> clusterMap = Maps.newHashMap();
        for (ItemClusterScore itemClusterScore : itemClusterScoreSet) {
            ItemClusterScore newItemClusterScore = itemClusterScore.copy();
            String item = newItemClusterScore.getItem();
            // 如果已下载过该主题
//            if (downloadedItemSet.contains(item)) {
//                continue;
//            }
            // 如果该机型不存在该主题
            if (!themeSet.contains(item)) {
                continue;
            }
            // 如果超过日推荐4次，或者连续推荐两天用户未下载
            if (themeFilterSet.contains(item)) {
                continue;
            }
            // 将同一类型保存到同一集合中
            String tagValue = newItemClusterScore.getItemTagForTest().getTagValue();
            List<ItemClusterScore> clusterScoreList = clusterMap.get(tagValue);
            if (clusterScoreList == null) {
                clusterScoreList = Lists.newArrayList();
            }
            clusterScoreList.add(newItemClusterScore);
            clusterMap.put(tagValue, clusterScoreList);
            existSeriesSet.add(tagValue);
            // 增加用户对该主题所属聚类的评分
            Integer cluster = newItemClusterScore.getCluster();
            Double userClusterScore = userClusterScoreMap.get(cluster);
            Double score = newItemClusterScore.getScore();

            newItemClusterScore.setScore(userClusterScore + score);
            // 添加到已过滤列表
            filteredItemClusterScoreList.add(newItemClusterScore);
        }
        Collections.sort(filteredItemClusterScoreList);
        // 未过滤相同系列的结果集
        List<ItemClusterScore> noFilterResultList = filteredItemClusterScoreList.subList(0, resultSize);
        // 第一步取剩下的结果集
        List<ItemClusterScore> noUsedResultList = filteredItemClusterScoreList.subList(resultSize, filteredItemClusterScoreList.size());
        Set<String> filterResultSet = Sets.newHashSet();
        Map<String, List<ItemClusterScore>> filterMap = Maps.newHashMap();
        // 给未过滤的结果集进行按照系列分类
        for (ItemClusterScore itemClusterScore : noFilterResultList) {
            String tagValue = itemClusterScore.getItemTagForTest().getTagValue();
            filterResultSet.add(tagValue);
            List<ItemClusterScore> filterList = filterMap.get(tagValue);
            if (filterList == null) {
                filterList = Lists.newArrayList();
            }
            filterList.add(itemClusterScore);
            filterMap.put(tagValue, filterList);
        }
        // 已过滤相同系列的集合
        List<ItemClusterScore> filterResultList = Lists.newArrayList();
        for (String tagValue : filterResultSet) {
            List<ItemClusterScore> seriesList = filterMap.get(tagValue);
            // 无系列或者该系列只有一个值，则不需要过滤
            if ("0".equals(tagValue) || seriesList.size() == 1) {
                filterResultList.addAll(seriesList);
            } else {
                Random random = new Random();
                // 随机一个数，用于获取当前系列的其中一个值
                int randomIndex = random.nextInt(seriesList.size());
                filterResultList.add(seriesList.get(randomIndex));
            }
        }
        Collections.sort(filterResultList);
        int i = 0;
        for (ItemClusterScore itemClusterScore : filterResultList) {
            // 当 i 等于 resultSize，跳出循环
            if (i == resultSize) {
                break;
            }
            resultList.add(new Result(itemClusterScore.getItem(), itemClusterScore.getScore(), ABID.REC_THEME_K.toString(), null));
            i++;
        }
        // 已获取到的结果个数
        int gotResultSize = resultSize - i;
        if (gotResultSize > 0) {
            for (ItemClusterScore itemClusterScore : noUsedResultList) {
                // 只补无系列的数据
                if (!"0".equals(itemClusterScore.getItemTagForTest().getTagValue())) {
                    continue;
                }
                // 当 i 等于 resultSize，跳出循环
                if (i == resultSize) {
                    break;
                }
                resultList.add(new Result(itemClusterScore.getItem(), itemClusterScore.getScore(), ABID.REC_THEME_K.toString(), null));
                i++;
            }
        }


//        int i = 0;
//        for (ItemClusterScore itemClusterScore : filteredItemClusterScoreList) {
//            // 当 i 等于 resultSize，跳出循环
//            if (i == resultSize) {
//                break;
//            }
//            resultList.add(new Result(itemClusterScore.getItem(), itemClusterScore.getScore(), ABID.REC_THEME_K.toString(), null));
//            i++;
//        }

        return resultList;
    }

}
