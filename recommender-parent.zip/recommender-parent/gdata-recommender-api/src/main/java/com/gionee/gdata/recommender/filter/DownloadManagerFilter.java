package com.gionee.gdata.recommender.filter;

import com.gionee.gdata.common.utils.HashUtil;
import com.gionee.gdata.common.utils.StringUtil;
import com.gionee.gdata.recommender.common.ParamConstants;
import com.gionee.gdata.recommender.common.ResultCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.NoSuchAlgorithmException;

/**
 * <code>DownloadManagerFilter</code>.
 * 下载管理过滤器
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:34
 */
@WebFilter(filterName = "downloadManagerFilter", urlPatterns = "/downloadmanager/*")
public class DownloadManagerFilter implements Filter {

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DownloadManagerFilter.class);

    private static final Charset charset = Charset.forName("UTF-8");

    /**
     * 接入id
     */
    @Value(value = "${recommender.api.downloadmanager.appId}")
    private String appId;
    /**
     * 接入key
     */
    @Value(value = "${recommender.api.downloadmanager.appKey}")
    private String appKey;

    /**
     * @param filterConfig 略
     * @throws ServletException 略
     */
    @Override
    public void init(final FilterConfig filterConfig) throws ServletException {
        LOGGER.info("init downloadmanager filter");
        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, filterConfig.getServletContext());
    }

    /**
     * 过滤请求，检查签名
     *
     * @param servletRequest
     * @param servletResponse
     * @param filterChain
     * @throws IOException
     * @throws ServletException
     */
    @Override
    public void doFilter(final ServletRequest servletRequest, final ServletResponse servletResponse, final FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        String inputAppId = StringUtil.isBlank(httpServletRequest.getHeader(ParamConstants.APPID))
                ? "" : httpServletRequest.getHeader(ParamConstants.APPID).trim();
        if (!appId.equals(inputAppId)) {
            LOGGER.info("appId不匹配, 系统appId = {}, 输入参数appId = {}", appId, inputAppId);
            servletResponse.getOutputStream().write(ResultCode.ERROR_APPID.toString().getBytes(charset));
            return;
        }
        String signature = StringUtil.isBlank(httpServletRequest.getHeader(ParamConstants.SIGNATURE))
                ? "" : httpServletRequest.getHeader(ParamConstants.SIGNATURE).trim();
        String imei = StringUtil.isBlank(httpServletRequest.getParameter(ParamConstants.DOWNLOAD_MANAGER_IMEI))
                ? "" : httpServletRequest.getParameter(ParamConstants.DOWNLOAD_MANAGER_IMEI).trim();
        String apps = StringUtil.isBlank(httpServletRequest.getParameter(ParamConstants.DOWNLOAD_MANAGER_APPS))
                ? "" : httpServletRequest.getParameter(ParamConstants.DOWNLOAD_MANAGER_APPS).trim();
        String limit = StringUtil.isBlank(httpServletRequest.getParameter(ParamConstants.DOWNLOAD_MANAGER_LIMIT))
                ? "" : httpServletRequest.getParameter(ParamConstants.DOWNLOAD_MANAGER_LIMIT).trim();
        try {
            if (StringUtil.isBlank(signature) || !signature.equals(HashUtil.md5Encode(appKey + StringUtil.getSortedString(imei, apps, limit)))) {
                LOGGER.info("signature error，appId: {}, signature: {}。", inputAppId, signature);
                servletResponse.getOutputStream().write(ResultCode.ERROR_SIGNATURE.toString().getBytes(charset));
                return;
            }
        } catch (NoSuchAlgorithmException e) {
            LOGGER.error("计算md5失败，appId = {}, appKey = {}, signature = {}, imei = {}, apps = {}, limit = {}. ",
                    inputAppId, appKey, signature, imei, apps, limit, e);
            servletResponse.getOutputStream().write(ResultCode.ERROR_SYSTEM.toString().getBytes(charset));
        }
        filterChain.doFilter(servletRequest, servletResponse);
    }

    @Override
    public void destroy() {
        LOGGER.info("destroy downloadmanager filter");
    }
}
