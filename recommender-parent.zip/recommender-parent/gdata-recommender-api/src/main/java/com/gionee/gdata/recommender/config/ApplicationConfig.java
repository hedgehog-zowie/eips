package com.gionee.gdata.recommender.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;

/**
 * <code>ApplicationConfig</code>.
 * 应用配置
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:29
 */
@Configuration
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
@ComponentScan(basePackages = {"com.gionee.gdata.recommender.api", "com.gionee.gdata.recommender.service", "com.gionee.gdata.recommender.service.*"})
@ServletComponentScan
//@ImportResource(locations = {
//        "classpath:config/hive/spring-gdata-data-hive.xml",
//        "classpath:config/hbase/spring-gdata-data-hbase.xml",
//        "classpath:config/redis/spring-gdata-data-redis.xml",
//        "classpath:config/mybatis/spring-gdata-data-mybatis.xml"
//})
@ImportResource(locations = {
        "classpath:config/redis/spring-gdata-data-redis.xml",
        "classpath:config/mybatis/spring-gdata-data-mybatis.xml",
        "classpath:config/ehcache/spring-gdata-rec-api-ehcache.xml",
})
@PropertySource(value = {"classpath:config/api.properties"})
@EnableCaching
public class ApplicationConfig {

    /**
     * 环境变量
     */
    @Autowired
    private Environment env;

    /**
     * 读取配置文件
     *
     * @return 略
     */
    @Bean
    public static PropertySourcesPlaceholderConfigurer placeHolderConfigurer() {
        PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
        propertySourcesPlaceholderConfigurer.setIgnoreUnresolvablePlaceholders(true);
        return propertySourcesPlaceholderConfigurer;
    }

//    @Bean
//    public SecurityService securityService(){
//        return new SecurityService(env.getProperty("recommender.api.appIds"), env.getProperty("recommender.api.appKeys"));
//    }

}
