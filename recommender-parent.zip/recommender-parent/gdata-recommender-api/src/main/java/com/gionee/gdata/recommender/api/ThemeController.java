package com.gionee.gdata.recommender.api;

import com.gionee.gdata.common.utils.JsonUtil;
import com.gionee.gdata.common.utils.StringUtil;
import com.gionee.gdata.recommender.common.ABID;
import com.gionee.gdata.recommender.common.ResultCode;
import com.gionee.gdata.recommender.common.Operation;
import com.gionee.gdata.recommender.model.RecommendItem;
import com.gionee.gdata.recommender.model.Response;
import com.gionee.gdata.recommender.model.theme.EditorRate;
import com.gionee.gdata.recommender.model.theme.ThemeRecommendResult;
import com.gionee.gdata.recommender.service.theme.*;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * <code>ThemeController</code>.
 * 主题商城 - 主题的推荐接口
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:26
 */
@RestController
@RequestMapping("/theme")
public class ThemeController {

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ThemeController.class);

    /**
     * 主题推荐服务类
     */
    @Autowired
    private ThemeService themeService;
    /**
     * 主题机型服务类
     */
    @Autowired
    private ThemeModelService themeModelService;
    /**
     * 主题干预规则服务类
     */
    @Autowired
    private ThemeRuleService themeRuleService;
    /**
     * 主题聚类服务类
     */
    @Autowired
    private ThemeClusterService themeClusterService;
    /**
     * 运营策略服务
     */
//    @Autowired
//    private ThemeOperationService themeOperationService;

    /**
     * 小编推荐服务类
     */
    @Autowired
    private ThemeEditorService themeEditorService;

    /**
     * @param imeiMd5    md5加密后的imei
//     * @param operations 运营策略，多个运营策略间使用英文逗号分隔
     * @param modelType      机型系列
     * @param limit      限制结果个数
     * @param isABModel      测试机型标志
     * @return 主题推荐结果
     */
    @RequestMapping(value = "/result/{imeiMd5}", method = RequestMethod.GET)
    public ThemeRecommendResult getThemeResult(final @PathVariable String imeiMd5,
//                                               final @RequestParam(value = "operations", required = false) String operations,
                                               final @RequestParam(value = "modelType") String modelType,
                                               final @RequestParam(value = "limit", defaultValue = "27") Integer limit,
                                               final @RequestParam(value = "isABModel") String isABModel) {
        LOGGER.info("start\001{}\001{}\001{}\001{}\001{}", (new Date()).getTime(), imeiMd5, modelType, limit, isABModel);
        if (StringUtil.isBlank(imeiMd5)) {
            ThemeRecommendResult themeResult = new ThemeRecommendResult();
            themeResult.setResultCode(ResultCode.ERROR_PARAM);
            LOGGER.warn("imei不可为空");
            return themeResult;
        }
        if (StringUtil.isBlank(modelType)) {
            ThemeRecommendResult themeResult = new ThemeRecommendResult();
            themeResult.setResultCode(ResultCode.ERROR_PARAM);
            LOGGER.warn("model不可为空");
            return themeResult;
        }
        // 在线计算结果
//        ThemeRecommendResult themeResult = themeService.getRecommendResultOnline(imeiMd5, operations, model, limit);
        ThemeRecommendResult themeResult = themeService.getRecommendResultOnline(imeiMd5, modelType, limit, isABModel);
        // 测试用
//        ThemeRecommendResult themeResult = generateTestResult(imeiMd5);

        LOGGER.info("end\001{}\001{}\001{}\001{}\001{}\001{}", (new Date()).getTime(), imeiMd5, modelType, limit, JsonUtil.toJson(themeResult), isABModel);
        return themeResult;
    }

    @RequestMapping(value = "/theme-editor-rec/{imeiMd5}")
    public ThemeRecommendResult getThemeEditorResult(final @PathVariable String imeiMd5,
                                                     final @RequestParam(value = "modelType") String modelType,
                                                     final @RequestParam(value = "limit", defaultValue = "27") Integer limit,
                                                     final @RequestParam(value = "isABModel") String isABModel){
        LOGGER.info("start\001{}\001{}\001{}\001{}\001{}", (new Date()).getTime(), imeiMd5, modelType, limit, isABModel);
        if (StringUtil.isBlank(imeiMd5)) {
            ThemeRecommendResult themeResult = new ThemeRecommendResult();
            themeResult.setResultCode(ResultCode.ERROR_PARAM);
            LOGGER.warn("imei不可为空");
            return themeResult;
        }
        if (StringUtil.isBlank(modelType)) {
            ThemeRecommendResult themeResult = new ThemeRecommendResult();
            themeResult.setResultCode(ResultCode.ERROR_PARAM);
            LOGGER.warn("model不可为空");
            return themeResult;
        }
        ThemeRecommendResult themeResult = themeService.getEditorRecommendResult(imeiMd5, modelType, limit, isABModel);
        LOGGER.info("end\001{}\001{}\001{}\001{}\001{}\001{}", (new Date()).getTime(), imeiMd5, modelType, limit, JsonUtil.toJson(themeResult), isABModel);
        return themeResult;
    }

    /**
     * 生成测试结果，测试用
     *
     * @param imeiMd5
     * @return
     */
    private ThemeRecommendResult generateTestResult(final String imeiMd5) {
        List<RecommendItem> resultList = Lists.newArrayList();
        resultList.add(new RecommendItem("itemId_of_test_theme_hot", Operation.theme_hot, null));
        resultList.add(new RecommendItem("itemId_of_test_theme_new_force", Operation.theme_new_force, null));
        resultList.add(new RecommendItem("itemId_of_test_theme_new_random", Operation.theme_new_random, null));
        resultList.add(new RecommendItem("itemId_of_test_theme_new_urgent", Operation.theme_new_urgent, null));
        resultList.add(new RecommendItem("itemId_of_test_no_ope", null, ABID.REC_THEME_K.toString()));
        ThemeRecommendResult themeResult = new ThemeRecommendResult(imeiMd5, resultList);
        themeResult.ok();
        return themeResult;
    }

    /**
     * 更新缓存
     */
    @RequestMapping(value = "/update_cache", method = RequestMethod.GET)
    public Response updateCache() {
        themeModelService.cacheModel();
        themeRuleService.cacheRuleTag();
        themeClusterService.cacheItemClusterScore();
        themeEditorService.updateRate();
        return new Response().ok("更新缓存成功");
    }

    @RequestMapping(value = "/update_editor_prop", method = RequestMethod.GET)
    public Response updateEditorProp( final @RequestParam(value = "rate") String rate){
        // 数字根据 ； 分隔
        String[] prop = rate.split(";");
        if (prop.length > 2) {
            return new Response().failure(HttpStatus.BAD_REQUEST,"最多只支持2对配置");
        }
        int i = 1;
        for (String pp : prop) {
            // 每对数字根据 ， 分隔
            String[] singleRates = pp.split(",");
            if (singleRates.length != 2) {
                return new Response().failure(HttpStatus.BAD_REQUEST,"每对只能配置2个");
            }
            try {
                Double num1 = Double.parseDouble(singleRates[0]);
                Double num2 = Double.parseDouble(singleRates[1]);
//                if ((num1 + num2) != 1) {
//                    return new Response().failure(HttpStatus.BAD_REQUEST,"一对相加之和要等于1");
//                }
                // 更新内存中的值
                if (i == 1) {
                    EditorRate.similarRate1Temp = num1;
                    EditorRate.similarRate2Temp = num2;
                } else if (i == 2) {
                    EditorRate.similarRate3Temp = num1;
                    EditorRate.similarRate4Temp = num2;
                }
                i++;
            } catch (Exception e) {
                return new Response().failure(HttpStatus.BAD_REQUEST,"只能是数字");
            }
        }
        return new Response().ok("更新成功");
    }

    /**
     * 更新运营策略类主题
     *
     * @param operationThemeList
     * @return
     */
//    @RequestMapping(value = "/update_ope_theme", method = RequestMethod.POST)
//    public Response updateUrgent(final @RequestBody @Valid List<OperationTheme> operationThemeList) {
//        Response response = new Response();
//        try {
//            for (OperationTheme operationTheme : operationThemeList) {
//                themeOperationService.addThemeOperationItems(operationTheme);
//            }
//        } catch (Exception e) {
//            LOGGER.error("update operation theme error. {}", e.getLocalizedMessage());
//            return response.ok(e.getLocalizedMessage());
//        }
//        return response.ok("更新运营策略类主题成功");
//    }

}
