package com.gionee.gdata.recommender.model;

import com.gionee.gdata.recommender.common.ResultCode;

import java.util.UUID;

/**
 * <code>BasicResult</code>.
 * 推荐结果
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/13 14:55
 */
public abstract class RecommendResult extends Response {

    /**
     * 略
     */
    private ResultCode resultCode;
    /**
     * 跟踪ID，由推荐系统产生并返回，用于跟踪推荐效果
     */
    private String traceId;

    /**
     * 成功返回
     *
     * @return
     */
    @Override
    public RecommendResult ok() {
        super.ok();
        setResultCode(ResultCode.SUCCESS);
        setTraceId(UUID.randomUUID().toString());
        return this;
    }

    public ResultCode getResultCode() {
        return resultCode;
    }

    public void setResultCode(final ResultCode resultCode) {
        this.resultCode = resultCode;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(final String traceId) {
        this.traceId = traceId;
    }

}
