package com.gionee.gdata.recommender.common;

/**
 * <code>FeatureCode</code>.
 * 特征编码、名称定义
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/11/22 15:44
 */
public enum FeatureCode {
    /**
     * 网络
     */
    NET("net", "网络"),
    /**
     * 第几时
     */
    HOUR_OF_DAY("hour_of_day", "小时"),
    /**
     * 星期
     */
    DAY_OF_WEEK("day_of_week", "星期"),
    ;

    private String code;
    private String name;

    FeatureCode(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
