/**
 * <code>package-info</code>.
 * 下载管理推荐服务
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/13 14:25
 */
package com.gionee.gdata.recommender.service.downloadmanager;
