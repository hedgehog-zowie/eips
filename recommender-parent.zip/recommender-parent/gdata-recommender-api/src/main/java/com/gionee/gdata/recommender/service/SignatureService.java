package com.gionee.gdata.recommender.service;

import com.gionee.gdata.common.utils.HashUtil;
import com.gionee.gdata.common.utils.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

/**
 * <code>SignatureService</code>.
 * 鉴权服务，不再使用
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/7 10:11
 */
@Service
public class SignatureService {

    /**
     * 日志记录器.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(SignatureService.class);

    /**
     * 广告接入id
     */
    @Value(value = "${advertisement.appId}")
    private String appId;
    /**
     * 广告接入key
     */
    @Value(value = "${advertisement.appKey}")
    private String appKey;

    /**
     * 检查输入参数appId
     *
     * @param inputAppId 输入的appId
     * @return 返回输入的appId与配置文件中的是否一致
     */
    public boolean checkAppId(final String inputAppId) {
        return appId.equals(inputAppId);
    }

    /**
     * 检查签名
     *
     * @param signature         签名
     * @param sortedParamString 排序好的字符串
     * @return 返回签名是否正确
     */
    public boolean checkSignature(final String signature, final String sortedParamString) {
        if (StringUtil.isBlank(signature)) {
            return false;
        }
        try {
            return signature.equals(HashUtil.md5Encode(appKey + sortedParamString));
        } catch (UnsupportedEncodingException e) {
            LOGGER.error("compute md5 error, appKey = {}, sortedParamString = {}. ", appKey, sortedParamString, e);
        } catch (NoSuchAlgorithmException e) {
            LOGGER.error("compute md5 error, appKey = {}, sortedParamString = {}. ", appKey, sortedParamString, e);
        }
        return false;
    }

}
