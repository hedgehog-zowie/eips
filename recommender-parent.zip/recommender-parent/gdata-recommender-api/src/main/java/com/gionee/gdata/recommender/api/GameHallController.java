package com.gionee.gdata.recommender.api;

import com.gionee.gdata.common.utils.JsonUtil;
import com.gionee.gdata.common.utils.StringUtil;
import com.gionee.gdata.recommender.common.ABID;
import com.gionee.gdata.recommender.common.ResultCode;
import com.gionee.gdata.recommender.model.gamehall.GameDailyRecommendResult;
import com.gionee.gdata.recommender.model.gamehall.GameDesktopRecommendItem;
import com.gionee.gdata.recommender.model.gamehall.GameDesktopRecommendResult;
import com.gionee.gdata.recommender.service.gamehall.GameHallService;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * 游戏大厅游戏桌面推荐接口
 *
 * @author yuwei
 * @version: 1.0-SNAPSHOT
 * date: 2017-10-12 11:17:45
 */
@RestController
@RequestMapping("/gameHall")
public class GameHallController {
    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(GameHallController.class);

    /**
     *
     */
    @Autowired
    private GameHallService gameHallService;

    /**
     * @param imeiMd5   imei
     * @param limit     推荐结果个数
     * @return 游戏桌面推荐结果
     */
    @RequestMapping(value = "/gameDesktopResult/{imeiMd5}", method = RequestMethod.GET)
    public GameDesktopRecommendResult getGameDesktopResult(final @PathVariable String imeiMd5,
                                                           final @RequestParam(value = "limit") Integer limit,
                                                           final @RequestParam(value = "firstTag", required = false) String firstTag){
        LOGGER.info("start\001{}\001{}\001{}\001{}", (new Date()).getTime(), imeiMd5, limit, firstTag);
        if (StringUtil.isBlank(imeiMd5)) {
            GameDesktopRecommendResult desktopResult = new GameDesktopRecommendResult();
            desktopResult.setResultCode(ResultCode.ERROR_PARAM);
            LOGGER.warn("imei不可为空");
            return desktopResult;
        }

        if (limit == null) {
            GameDesktopRecommendResult desktopResult = new GameDesktopRecommendResult();
            desktopResult.setResultCode(ResultCode.ERROR_PARAM);
            LOGGER.warn("limit不可为空");
            return desktopResult;
        }

        GameDesktopRecommendResult desktopResult = gameHallService.getGameDesktopRecommendResult(imeiMd5, limit, firstTag);

        // 测试用
        //GameDesktopRecommendResult desktopResult = generateTestResult(imeiMd5, limit);
        LOGGER.info("end\001{}\001{}\001{}\001{}\001{}", (new Date()).getTime(), imeiMd5, limit, firstTag, JsonUtil.toJson(desktopResult));
        return desktopResult;
    }

    /**
     * 生成测试结果，测试用
     *
     * @param imeiMd5
     * @param limit
     * @return
     */
    private GameDesktopRecommendResult generateTestResult(final String imeiMd5, final Integer limit) {
        String[] gameid = new String[]{
                "21","34","56","76","90","109","115","120","129","141","150","155","166","173","194","200",
                "205","209","216","246","281","287","293","296","310","318","324","330","345","351","374",
                "388","401","417","429","449","455","470","476","481","487","492","499","515","521","530",
                "538","551","565","581","595","603","617","632","639","647","657","661","668","685","696",
                "706","711","720","731","738","768","781","795","798","814","819","824","828","840","853",
                "863","874","883","892","898","903","911","938","953","959","967","981","986","996","1015",
                "1025","1030","1033","1037","1044","1047","1072","1079","1090","1093","1102","1107","1110",
                "1128","1132","1145","1149","1153","1187","1209","1226","1236","1238","1241","1247","1250",
                "1255","1259","1263","1273","1283","1294","1307","1324","1356","1366","1370","1385","1415",
                "1423","1428","1440","1445"
        };
        Set<String> set = Sets.newHashSet();
        while (true){
            Random r = new Random();
            set.add(gameid[r.nextInt(100)]);
            if(set.size() == limit){
                break;
            }
        }
        List<GameDesktopRecommendItem> resultList = Lists.newArrayList();
        GameDesktopRecommendResult desktopResult = new GameDesktopRecommendResult();
        String trace_id = desktopResult.getTraceId();
        for (String result : set) {
            String result_id = "_" + trace_id + "_" + ABID.recGameDownloadRatio;
            GameDesktopRecommendItem item = new GameDesktopRecommendItem(result, null, ABID.recGameDownloadRatio, result_id);
            resultList.add(item);
        }
        desktopResult.setImei(imeiMd5);
        desktopResult.setResultList(resultList);
        return desktopResult;
    }

    /**
     * 获取游戏每日一荐结果
     * @param imeiMd5
     * @param net
     * @return
     */
    @RequestMapping(value = "/dailyRecommendResult/{imeiMd5}", method = RequestMethod.GET)
    public GameDailyRecommendResult getDailyRecommendResult(final @PathVariable String imeiMd5,
                                                            final @RequestParam(value = "net", required = false) String net){
        LOGGER.info("start\001{}\001{}\001{}", (new Date()).getTime(), imeiMd5, net);
        if (StringUtil.isBlank(imeiMd5)) {
            GameDailyRecommendResult gameDailyRecommendResult = new GameDailyRecommendResult();
            gameDailyRecommendResult.setResultCode(ResultCode.ERROR_PARAM);
            LOGGER.warn("imei不可为空");
            return gameDailyRecommendResult;
        }
        GameDailyRecommendResult gameDailyRecommendResult = gameHallService.getDailyRecommendResult(imeiMd5, net);
        LOGGER.info("end\001{}\001{}\001{}", (new Date()).getTime(), imeiMd5, JsonUtil.toJson(gameDailyRecommendResult));
        return gameDailyRecommendResult;
    }

}
