package com.gionee.gdata.recommender.model;

import org.springframework.http.HttpStatus;

/**
 * <code>Response</code>.
 * 响应定义
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/7 10:11
 */
public class Response {

    /**
     * 状态码
     */
    private int statusCode;
    /**
     * 消息
     */
    private String msg;

    /**
     * 构造函数
     */
    public Response() {

    }

    /**
     * 正确返回
     *
     * @return Response对象
     */
    public Response ok() {
        return ok(HttpStatus.OK.getReasonPhrase());
    }

    /**
     * 正确返回
     *
     * @param msg 消息
     * @return Response对象
     */
    public Response ok(final String msg) {
        this.statusCode = HttpStatus.OK.value();
        this.msg = msg;
        return this;
    }

    /**
     * 错误返回
     *
     * @param httpStatus http状态
     * @return Response对象
     */
    public Response failure(final HttpStatus httpStatus) {
        return failure(httpStatus, httpStatus.getReasonPhrase());
    }

    /**
     * 错误返回
     *
     * @param httpStatus http状态
     * @param msg        消息
     * @return Response对象
     */
    public Response failure(final HttpStatus httpStatus, final String msg) {
        this.statusCode = httpStatus.value();
        this.msg = msg;
        return this;
    }

    /**
     * 获取状态码
     *
     * @return Response对象
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * 设置状态码
     *
     * @param statusCode 状态码
     */
    public void setStatusCode(final int statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * 获取消息
     *
     * @return Response对象
     */
    public String getMsg() {
        return msg;
    }

    /**
     * 设置消息
     *
     * @param msg 消息
     */
    public void setMsg(final String msg) {
        this.msg = msg;
    }

}
