/**
 * <code>package-info</code>.
 * 公共包
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/13 14:27
 */
package com.gionee.gdata.recommender.common;
