package com.gionee.gdata.recommender.model.browser;

import com.gionee.gdata.recommender.model.RecommendItem;
import com.gionee.gdata.recommender.model.RecommendResult;
import com.google.common.collect.Lists;

import java.util.List;
import java.util.Set;

/**
 * <code>BrowserRecommendResult</code>.
 * ${DESCRIPTION}
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2018/3/9 10:44
 */
public class BrowserRecommendResult extends RecommendResult {

    /**
     * 略
     */
    private String imei;
    /**
     * 推荐结果
     */
    private List<BrowserRecommendItem> resultList;

    /**
     * 略
     */
    public BrowserRecommendResult() {
        super.ok();
    }

    /**
     * 略
     *
     * @param imei      略
     * @param resultSet 略
     */
    public BrowserRecommendResult(final String imei, final Set<BrowserRecommendItem> resultSet) {
        this.imei = imei;
        this.resultList = Lists.newArrayList(resultSet);
        super.ok();
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public List<BrowserRecommendItem> getResultList() {
        return resultList;
    }

    public void setResultList(List<BrowserRecommendItem> resultList) {
        this.resultList = resultList;
    }

}
