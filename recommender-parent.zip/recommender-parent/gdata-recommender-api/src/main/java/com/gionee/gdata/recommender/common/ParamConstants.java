package com.gionee.gdata.recommender.common;

/**
 * <code>ParamConstants</code>.
 * 参数定义常量
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:31
 */
public final class ParamConstants {

    /**
     * 隐藏构造函数
     */
    private ParamConstants() {
    }

    // 公共参数名
    /**
     * 应用接入id
     */
    public static final String APPID = "appId";
    /**
     * 签名
     */
    public static final String SIGNATURE = "signature";

    // 下载管理传入参数名
    /**
     * MD5加密后的imei
     */
    public static final String DOWNLOAD_MANAGER_IMEI = "imei";
    /**
     * 包名列表
     */
    public static final String DOWNLOAD_MANAGER_APPS = "apps";
    /**
     * 限制结果个数
     */
    public static final String DOWNLOAD_MANAGER_LIMIT = "limit";

    // 广告系统传入参数名
    /**
     * MD5加密后的imei
     */
    @Deprecated // 广告CTR接口已由单独的项目实现
    public static final String ADVERTISEMENT_IMEI = "imei";
    /**
     * 限制结果个数
     */
    @Deprecated // 广告CTR接口已由单独的项目实现
    public static final String ADVERTISEMENT_APPS = "apps";

    // 主题壁纸传入参数名
    /**
     * MD5加密后的imei
     */
    public static final String THEME_IMEI = "imei";
    /**
     * 限制结果个数
     */
    public static final String THEME_LIMIT = "limit";

}
