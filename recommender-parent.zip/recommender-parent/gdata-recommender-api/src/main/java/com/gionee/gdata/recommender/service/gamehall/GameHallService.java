package com.gionee.gdata.recommender.service.gamehall;

import com.gionee.gdata.common.utils.DateUtil;
import com.gionee.gdata.data.mybatis.entity.recommender.gamehall.GameSecondTagCorrelDegree;
import com.gionee.gdata.recommender.common.ABID;
import com.gionee.gdata.recommender.model.gamehall.*;
import com.gionee.gdata.recommender.service.LRModelService;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.mllib.linalg.Vector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 游戏大厅推荐服务
 *
 * @author yuwei
 * @version: 1.0-SNAPSHOT
 * date: 2017-10-12 11:46:41
 */
@Service
public class GameHallService {
    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(GameHallService.class);

    /**
     *
     */
    @Autowired
    private GameHallSecondTagService gameHallSecondTagService;

    /**
     *
     */
    @Autowired
    private GameHallSecondTagCorrelService gameHallSecondTagCorrelService;

    /**
     *
     */
    @Autowired
    private GameHallFirstTagCorrelService gameHallFirstTagCorrelService;

    @Autowired
    private GameFeatureService featureService;

    @Autowired
    private LRModelService lrModelService;

    /**
     * 二级标签推荐比例
     */
    @Value(value = "${recommender.api.gamehall.limitPercentage}")
    private Double limitPercentage;

    /**
     * 生成推荐结果
     *
     * @param imeiMd5
     * @param limit    结果个数
     * @param firstTag 一级标签
     * @return 推荐结果
     */
    public GameDesktopRecommendResult getGameDesktopRecommendResult(final String imeiMd5, final Integer limit, final String firstTag) {
        double first = Math.ceil(limit * limitPercentage); // 向上取整
        Integer secondLimit = limit;
        Integer firstLimit = 0;
        List<String> firstTagRecommodResult = null;
        // 如果存在一级标签，则按照百分比来取一级二级标签的推荐结果
        if (StringUtils.isNotBlank(firstTag)) {
            firstLimit = (int) first;
            // 获取一级标签推荐结果集
            firstTagRecommodResult = gameHallFirstTagCorrelService.getFirstTagRecommondResult(firstTag, firstLimit);
            // 当一级标签存在,则取一级标签和二级标签混合推荐，否则只取二级标签进行推荐
            if (firstTagRecommodResult != null) {
                LOGGER.info("一级标签推荐结果为：" + firstTagRecommodResult);
                secondLimit = limit - firstLimit;
            }
            // LOGGER.info("一级标签中取出的推荐结果：\001{}", firstTagRecommodResult.toString());
        }
        // 1.	用户传入imei的md5值获取推荐结果
        Map<String, Object> secondTagMap = gameHallSecondTagService.getSecondTagScore(imeiMd5);
        // LOGGER.info("不存在imeiMd5对应的二级标签数据");
        if (secondTagMap == null) { // 当不存在imeiMd5对应的数据，直接返回空集合
            return new GameDesktopRecommendResult(imeiMd5, Lists.newArrayList(new GameDesktopRecommendItem[0]));
        }
        // 1.1	根据md5查找用户二级标签偏好表，获取用户所有的二级标签偏好度；
        //	对所有二级标签的偏好度求和，计为sum；
        Double secondTagScoreSum = (Double) secondTagMap.get("secondTagSum");
        LOGGER.info("二级标签相关度总和: \001{}", secondTagScoreSum);
        if (secondTagScoreSum == 0.0) { // 分数总和为0，也直接返回空列表
            return new GameDesktopRecommendResult(imeiMd5, Lists.newArrayList(new GameDesktopRecommendItem[0]));
        }
        // 二级偏好度结果集
        List<GameUserSecondTagScoreResult> secondTagScoreResults = (List<GameUserSecondTagScoreResult>) secondTagMap.get("scoreResultsList");
        // 获取真实imei
        String imei = (String) secondTagMap.get("imei");
        // 获取需要推荐的二级标签游戏结果
        List<GameSecondTagCorrelDegree> secondTagCorrelDegreeList = getSecondTagScoreProportion(secondTagScoreResults, secondTagScoreSum, secondLimit);
        // 根据查询结果生成推荐返回结果
        GameDesktopRecommendResult gameDesktopRecommendResult = getRecommendResult(imeiMd5, secondTagCorrelDegreeList, firstTagRecommodResult, limit);
        return gameDesktopRecommendResult;
    }

    /**
     * 获取二级标签推荐集合
     *
     * @param secondTagScoreResults
     * @param sum
     * @param limit
     * @return
     */
    public List<GameSecondTagCorrelDegree> getSecondTagScoreProportion(List<GameUserSecondTagScoreResult> secondTagScoreResults, Double sum, Integer limit) {
        List<GameSecondTagCorrelDegree> secondTagCorrelDegreeList = Lists.newArrayList();
        Set<String> secondTagIdSet = Sets.newHashSet();
        // 二级标签推荐结果已获取数量
        int secondTagCount = 0;
        for (GameUserSecondTagScoreResult secondTagScoreResult : secondTagScoreResults) {
            // 获取二级标签占比
            Double proportionOfSum = secondTagScoreResult.getProportionOfSum(sum);
            // 计算每个二级标签需要获取的游戏个数
            Integer gameNum = (int) Math.ceil(limit * proportionOfSum); // 向上取整
            String secondTagId = secondTagScoreResult.getSecondTagId();
            // 获取当前二级标签下的游戏集合
            List<GameSecondTagCorrelDegree> secondTagCorrelDegrees = gameHallSecondTagCorrelService.getRecommendResult(secondTagId);
            // 当前二级标签推荐数量
            int currentSecondTag = 0;
            for (GameSecondTagCorrelDegree gameSecondTagCorrelDegree : secondTagCorrelDegrees) {
                // 获取保存推荐结果前已推荐数量
                secondTagCount = secondTagIdSet.size();
                secondTagIdSet.add(gameSecondTagCorrelDegree.getItem());
                // 确定已经加1，没有重复
                if (secondTagIdSet.size() - secondTagCount == 1) {
                    secondTagCorrelDegreeList.add(gameSecondTagCorrelDegree);
                    currentSecondTag++;
                }
                // 当前二级标签需要推荐的结果数已达到，或者推荐总数已达到要求则退出循环
                if (currentSecondTag == gameNum || secondTagCorrelDegreeList.size() == limit) {
                    break;
                }
            }
            // 推荐总数已达要求，直接退出循环
            if (secondTagCorrelDegreeList.size() == limit) {
                break;
            }
        }
        return secondTagCorrelDegreeList;
    }

    /**
     * 根据查询结果生成推荐结果
     *
     * @param imeiMd5
     * @param secondTagCorrelDegreeList
     * @param firstTagRecommodResult
     * @param limit
     * @return
     */
    public GameDesktopRecommendResult getRecommendResult(String imeiMd5, List<GameSecondTagCorrelDegree> secondTagCorrelDegreeList, List<String> firstTagRecommodResult, Integer limit) {
        GameDesktopRecommendResult gameDesktopRecommendResult = new GameDesktopRecommendResult();
        String traceId = gameDesktopRecommendResult.getTraceId();
        ABID abid = ABID.recGameDownloadRatio;
        String resultId = "_" + traceId + "_" + abid;
        List<GameDesktopRecommendItem> resultList = Lists.newArrayList();
        if (firstTagRecommodResult != null && firstTagRecommodResult.size() > 0) {
            for (String firstTag : firstTagRecommodResult) {
                GameDesktopRecommendItem item = new GameDesktopRecommendItem(firstTag, null, abid, resultId);
                resultList.add(item);   // 将一级标签获取的推荐结果放在前面
            }
        }
        for (GameSecondTagCorrelDegree gameSecondTagCorrelDegree : secondTagCorrelDegreeList) {
            GameDesktopRecommendItem item = new GameDesktopRecommendItem(gameSecondTagCorrelDegree.getItem(), null, abid, resultId);
            resultList.add(item);   // 将二级标签获取的推荐结果放入集合
        }
        if (resultList.size() > limit) {    // 截取结果集，只需要limit个
            resultList = resultList.subList(0, limit);
        }
        gameDesktopRecommendResult.setImei(imeiMd5);
        gameDesktopRecommendResult.setResultList(resultList);
        return gameDesktopRecommendResult;
    }

    /**
     * 计算每日一荐结果
     *
     * @param imeiMd5
     * @param net
     * @return
     */
    public GameDailyRecommendResult getDailyRecommendResult(String imeiMd5, String net) {
//        Map<String, Vector> vectors = featureService.generateVector(imeiMd5, net, String.valueOf(DateUtil.getDayOfWeek()), String.valueOf(DateUtil.getHourOfDay()));
        Map<String, Vector> vectors = featureService.generateVectorOfDaily(imeiMd5, net, String.valueOf(DateUtil.getDayOfWeek()), String.valueOf(DateUtil.getHourOfDay()));
        List<GameDailyRecommendItem> gameDailyRecommendItems = lrModelService.predict(vectors);
        Collections.sort(gameDailyRecommendItems);
        GameDailyRecommendResult gameDailyRecommendResult = new GameDailyRecommendResult(imeiMd5, gameDailyRecommendItems);
        return gameDailyRecommendResult;
    }

}
