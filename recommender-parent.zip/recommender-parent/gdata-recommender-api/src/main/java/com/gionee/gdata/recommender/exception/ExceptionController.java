package com.gionee.gdata.recommender.exception;

import com.gionee.gdata.recommender.model.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * <code>ExceptionController</code>.
 * 异常处理
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/7 10:11
 */
@ControllerAdvice
@ResponseBody
public class ExceptionController {

    /**
     * 日志记录器.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionController.class);

    /**
     * 400 - Bad Request
     *
     * @param e 异常
     * @return 返回Response对象
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public Response handleHttpMessageNotReadableException(final HttpMessageNotReadableException e) {
        LOGGER.error("参数解析失败", e);
        return new Response().failure(HttpStatus.BAD_REQUEST);
    }

    /**
     * 400 - Bad Request
     *
     * @param e 异常
     * @return 返回Response对象
     */
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Response handleHttpMethodArgumentNotValidException(final MethodArgumentNotValidException e) {
        LOGGER.error("参数验证失败", e);
        return new Response().failure(HttpStatus.BAD_REQUEST, e.getBindingResult().getFieldError().getDefaultMessage());
    }

    /**
     * 405 - Method Not Allowed
     *
     * @param e 异常
     * @return 返回Response对象
     */
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public Response handleHttpRequestMethodNotSupportedException(final HttpRequestMethodNotSupportedException e) {
        LOGGER.error("不支持当前请求方法", e);
        return new Response().failure(HttpStatus.METHOD_NOT_ALLOWED);
    }

    /**
     * 415 - Unsupported Media Type
     *
     * @param e 异常
     * @return 返回Response对象
     */
    @ResponseStatus(HttpStatus.UNSUPPORTED_MEDIA_TYPE)
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public Response handleHttpMediaTypeNotSupportedException(final Exception e) {
        LOGGER.error("不支持当前媒体类型", e);
        return new Response().failure(HttpStatus.UNSUPPORTED_MEDIA_TYPE);
    }

    /**
     * 500 - Internal Server Error
     *
     * @param e 异常
     * @return 返回Response对象
     */
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(Exception.class)
    public Response handleException(final Exception e) {
        LOGGER.error("服务运行异常", e);
        return new Response().failure(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
    }

}
