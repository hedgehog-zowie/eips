package com.gionee.gdata.recommender.service.theme;

import com.gionee.gdata.data.mybatis.entity.recommender.theme.ItemTag;
import com.gionee.gdata.data.mybatis.entity.recommender.theme.ThemeOpeItemMeta;
import com.gionee.gdata.data.mybatis.mapper.recommender.theme.ItemTagMapper;
import com.gionee.gdata.data.mybatis.mapper.recommender.theme.ThemeOpeItemMetaMapper;
import com.gionee.gdata.data.mybatis.model.recommender.theme.ThemeOpeItemMetaQuery;
import com.gionee.gdata.data.mybatis.model.recommender.theme.ThemeTagQuery;
import com.gionee.gdata.recommender.common.Operation;
import com.gionee.gdata.recommender.common.ThemeOperationRuleKey;
import com.gionee.gdata.recommender.common.ThemeScene;
import com.gionee.gdata.recommender.model.RecommendItem;
import com.gionee.gdata.recommender.model.theme.OperationTheme;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <code>ThemeOpeService</code>.
 * 运营策略服务类
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/8/28 10:38
 */
@Service
public class ThemeOperationService {

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ThemeOperationService.class);

    /**
     * 结果处理服务
     */
    @Autowired
    private ThemeResultService themeResultService;

    /**
     * 运营规则类物品Mapper
     */
    @Autowired
    private ThemeOpeItemMetaMapper themeOpeItemMetaMapper;

    /**
     * 主题标签Mapper
     */
    @Autowired
    private ItemTagMapper itemTagMapper;

    /**
     * 使用运营策略计算结果
     *
     * @param model 机型
     * @return
     */
    public List<RecommendItem> computeResultListUseOperation(final Operation operation, final String model) {
        List<RecommendItem> resultList = Lists.newArrayList();
        // 封装查询条件
        ThemeOpeItemMetaQuery themeOpeItemMetaQuery = new ThemeOpeItemMetaQuery(
                ThemeScene.theme_new.toString(),
                operation.toString(),
                ThemeOperationRuleKey.modeltype.toString(),
                model,
                1 // 1表示有效
        );
        // 查询数据库中的结果
        List<ThemeOpeItemMeta> themeOpeItemMetaList = Lists.newArrayList();
        try {
            themeOpeItemMetaList = themeOpeItemMetaMapper.findThemeOpeItemMeta(themeOpeItemMetaQuery);
        } catch (Exception e) {
            LOGGER.error("get data from database error. msg: {}", e.getLocalizedMessage());
        }
        for (ThemeOpeItemMeta themeOpeItemMeta : themeOpeItemMetaList) {
            resultList.add(new RecommendItem(themeOpeItemMeta.getItemId(), operation, null));
        }

        return resultList;
    }

    /**
     * 获取小编推荐主题(根据系列来保存，相同系列保存在一个集合里面)
     * @param sncId
     * @param operation
     * @param model
     * @return
     */
    public Map<String, List<RecommendItem>> getResultList(final String sncId, final Operation operation, final String model){
        // 根据系列保存的结果集
        Map<String, List<RecommendItem>> seriesMap = Maps.newHashMap();
        // 编辑查询条件
        ThemeTagQuery themeTagQuery = new ThemeTagQuery("series", sncId, operation.toString(), ThemeOperationRuleKey.modeltype.toString(), model);
        // 查询数据库中的结果
        List<ItemTag> itemtags = Lists.newArrayList();
        try {
            itemtags = itemTagMapper.findAllEditorItemSeriesTag(themeTagQuery);
        } catch (Exception e) {
            LOGGER.error("get data from database error. msg: {}", e.getLocalizedMessage());
        }
        for (ItemTag itemtag : itemtags) {
            // 系列
            String series = itemtag.getTagValue();
            List<RecommendItem> resultList = seriesMap.get(series);
            if (resultList == null) {   // 当系列的结果集不存在的时候，新建集合保存
                resultList = Lists.newArrayList();
            }
            resultList.add(new RecommendItem(itemtag.getItem(), operation, null));
            seriesMap.put(series, resultList);
        }
        return seriesMap;
    }

    /**
     * 使用新品随机策略获取结果
     *
     * @param model 机型
     * @param size  需要的结果大小
     * @return
     */
    public List<RecommendItem> computeResultListUseThemeNewRandom(final String model, final Integer size) {
        List<RecommendItem> allNewResultList = computeResultListUseOperation(Operation.theme_new_random, model);
        // 去重
        Set<RecommendItem> allNewResultSet = Sets.newLinkedHashSet(allNewResultList);
        return themeResultService.getRandomResult(Lists.newArrayList(allNewResultSet), size);
    }

    /**
     * 使用热门策略获取结果
     *
     * @param model            机型
     * @param recommendItemSet 目前推荐物品结果集
     * @param size             需要的结果集大小
     * @return
     */
//    public void computeResultListUseThemeHot(final String model, final Set<RecommendItem> recommendItemSet, final Integer size) {
//        List<RecommendItem> allHotResultList = computeResultListUseOperation(Operation.theme_hot, model);
//        int i = 0;
//        // 结果个数不足时，添加热门主题
//        while (recommendItemSet.size() < size) {
//            recommendItemSet.add(allHotResultList.get(i));
//            i++;
//        }
//    }

    /**
     * 添加运营策略类物品
     *
     * @param operationTheme 运营策略类主题
     */
    public void addThemeOperationItems(OperationTheme operationTheme) {
        ThemeOpeItemMeta themeOpeItemMeta = new ThemeOpeItemMeta();
        themeOpeItemMeta.setItemId(operationTheme.getItemId());
        themeOpeItemMeta.setItemInfo(operationTheme.getItemInfo());
        themeOpeItemMeta.setSncId(operationTheme.getScnId().toString());
        themeOpeItemMeta.setOpeId(operationTheme.getOpeId().toString());
        themeOpeItemMeta.setRuleKey(operationTheme.getRuleKey());
        themeOpeItemMeta.setRuleValue(operationTheme.getRuleValue());
        themeOpeItemMeta.setEffectiveTime(new Date(operationTheme.getEffectiveTime()));
        themeOpeItemMeta.setEffectiveFlag(true);
        themeOpeItemMetaMapper.addThemeOpeItemMeta(themeOpeItemMeta);
    }

}
