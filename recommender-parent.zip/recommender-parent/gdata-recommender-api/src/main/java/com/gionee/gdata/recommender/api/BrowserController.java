package com.gionee.gdata.recommender.api;

import com.gionee.gdata.common.utils.JsonUtil;
import com.gionee.gdata.common.utils.StringUtil;
import com.gionee.gdata.recommender.common.ABID;
import com.gionee.gdata.recommender.common.ResultCode;
import com.gionee.gdata.recommender.model.RecommendItem;
import com.gionee.gdata.recommender.model.browser.BrowserRecommendItem;
import com.gionee.gdata.recommender.model.browser.BrowserRecommendResult;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * <code>BrowserController</code>.
 * ${DESCRIPTION}
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2018/1/19 16:25
 */
@RestController
@RequestMapping("/browser")
public class BrowserController {

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(BrowserController.class);

    /**
     * @param imeiMd5
     * @param sites
     * @param net
     * @param time
     * @return 浏览器二级站点推荐结果
     */
    @RequestMapping(value = "/second/{imeiMd5}", method = RequestMethod.GET)
    public BrowserRecommendResult getRecommendResult(final @PathVariable String imeiMd5,
                                                     final @RequestParam(value = "sites") String sites,
                                                     final @RequestParam(value = "net", required = false) String net,
                                                     final @RequestParam(value = "time", required = false) Long time) {
        LOGGER.info("start\001{}\001{}\001{}\001{}\001{}", (new Date()).getTime(), imeiMd5, sites, net, time);
        if (StringUtil.isBlank(imeiMd5)) {
            BrowserRecommendResult browserRecommendResult = new BrowserRecommendResult();
            browserRecommendResult.setResultCode(ResultCode.ERROR_PARAM);
            LOGGER.error("imei不可为空");
            return browserRecommendResult;
        }
        if (StringUtil.isBlank(sites)) {
            BrowserRecommendResult browserRecommendResult = new BrowserRecommendResult();
            browserRecommendResult.setResultCode(ResultCode.ERROR_PARAM);
            LOGGER.error("站点列表不可为空");
            return browserRecommendResult;
        }
        BrowserRecommendResult browserRecommendResult = generateTestResult(imeiMd5, sites, net, time);
        LOGGER.info("end\001{}\001{}\001{}\001{}\001{}", (new Date()).getTime(), imeiMd5, sites, net, time, JsonUtil.toJson(browserRecommendResult));
        return browserRecommendResult;
    }

    /**
     * 生成测试结果，测试用
     *
     * @param imeiMd5
     * @param sites
     * @param net
     * @param time
     * @return
     */
    private BrowserRecommendResult generateTestResult(final String imeiMd5, final String sites, final String net, final Long time) {
        String[] siteIds = sites.split(",");
        int length = siteIds.length;
        Set<String> set = Sets.newHashSet();
        Random random = new Random();
        while (true) {
            set.add(siteIds[random.nextInt(length)]);
            if (set.size() == length) {
                break;
            }
        }
        BrowserRecommendResult browserRecommendResult = new BrowserRecommendResult();
        browserRecommendResult.setImei(imeiMd5);
        List<BrowserRecommendItem> resultList = Lists.newArrayList();
        for (String result : set) {
            BrowserRecommendItem item = new BrowserRecommendItem(result, null, ABID.REC_BROWSER_SIMILAR_ITEM, random.nextDouble());
            resultList.add(item);
        }
        Collections.sort(resultList);
        browserRecommendResult.setResultList(resultList);
        return browserRecommendResult;
    }

}
