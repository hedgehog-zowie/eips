package com.gionee.gdata.recommender.model.gamehall;

/**
 * 二级标签偏好
 *
 * @author yuwei
 * @version: 1.0-SNAPSHOT
 * date: 2017-10-12 11:17:45
 */
public class GameUserSecondTagScoreResult {
    /**
     * imei的MD5，主键
     */
    private String userMd5;

    /**
     * 二级标签ID
     */
    private String secondTagId;

    /**
     * 用户对二级标签的偏好评分
     */
    private Double score;

    /**
     * 无参构造函数
     */
    public GameUserSecondTagScoreResult() {
    }

    /**
     * 带所有参数的构造函数
     * @param userMd5
     * @param secondTagId
     * @param score
     */
    public GameUserSecondTagScoreResult(String userMd5, String secondTagId, Double score) {
        this.userMd5 = userMd5;
        this.secondTagId = secondTagId;
        this.score = score;
    }

    /**
     * 二级标签的偏好度占比
     * @param sum 偏好度总和
     * @return 当前偏好度占比
     */
    public double getProportionOfSum(final double sum){
        if (sum == 0.0) {
            return 0.0;
        }
        return this.score / sum;
    }

    public String getUserMd5() {
        return userMd5;
    }

    public void setUserMd5(String userMd5) {
        this.userMd5 = userMd5;
    }

    public String getSecondTagId() {
        return secondTagId;
    }

    public void setSecondTagId(String secondTagId) {
        this.secondTagId = secondTagId;
    }

    public double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }
}
