package com.gionee.gdata.recommender.common;

/**
 * <code>ScnId</code>.
 * 主题场景定义
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/8/22 11:43
 */
public enum ThemeScene {

    /**
     * 主题推荐——新品推荐场景
     */
    theme_new,

    /**
     * 主题推荐--小编推荐
     */
    theme_editor,

}
