package com.gionee.gdata.recommender.service.gamehall;

import com.gionee.gdata.data.mybatis.mapper.recommender.gamehall.GameUserSecondTagScoreMapper;
import com.gionee.gdata.data.mybatis.entity.recommender.gamehall.GameUserSecondTagScore;
import com.gionee.gdata.recommender.model.gamehall.GameUserSecondTagScoreResult;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class GameHallSecondTagService {
    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(GameHallSecondTagService.class);

    /**
     *
     */
    @Autowired
    private GameUserSecondTagScoreMapper gameUserSecondTagScoreMapper;

    /**
     * 根据imeiMd5获取用户的所有二级偏好度
     * @param imeiMd5
     * @return
     */
    public Map<String, Object> getSecondTagScore(String imeiMd5){
        LOGGER.info("获取 {} 所有的二级偏好", imeiMd5);
        // 获取用户所有的二级偏好
        List<GameUserSecondTagScore> secondTagScore = gameUserSecondTagScoreMapper.findUserAllSecondTagScore(imeiMd5);
        if (secondTagScore == null || secondTagScore.size() == 0) { // 当不存在imeiMd5对应的数据，直接返回null
            return null;
        }
        Map<String, Object> map = Maps.newHashMap();
        // 整理后的二级偏好度
        List<GameUserSecondTagScoreResult> scoreResultsList = Lists.newArrayList();
        map.put("imeiMd5", imeiMd5);    // 用户标志
        Double sum = 0.0;   // 该用户所有二级偏好度的总和
        // imei
        String imei = null;
        for (GameUserSecondTagScore score : secondTagScore){
            sum += score.getScore();
            // 将数据库查出来的二级偏好重新整理放入结果类中
            GameUserSecondTagScoreResult scoreResult = new GameUserSecondTagScoreResult(imeiMd5, score.getSecondTagId(), score.getScore());
            scoreResultsList.add(scoreResult);
            imei = score.getUser();
        }
        map.put("scoreResultsList", scoreResultsList);
        map.put("secondTagSum", sum);
        map.put("imei", imei);
        return map;
    }
}
