package com.gionee.gdata.recommender.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <code>WallPaperController</code>.
 * 主题商城 - 壁纸的推荐接口
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:28
 */
@RestController
@RequestMapping("/wallpaper")
public class WallPaperController {

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(WallPaperController.class);

}
