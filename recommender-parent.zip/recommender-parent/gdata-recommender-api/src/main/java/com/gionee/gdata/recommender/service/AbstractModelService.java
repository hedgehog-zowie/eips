package com.gionee.gdata.recommender.service;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;

/**
 * <code>AbstractModelService</code>.
 * 模型服务抽象类
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/11/22 14:06
 */
public abstract class AbstractModelService {

    /**
     * spark配置
     */
    protected static final SparkConf SPARK_CONF = new SparkConf().
            setAppName("ad-ctr-api").
            setMaster("local[*]");
    /**
     * spark上下文
     */
    protected static final SparkContext SPARK_CONTEXT = new SparkContext(SPARK_CONF);

}
