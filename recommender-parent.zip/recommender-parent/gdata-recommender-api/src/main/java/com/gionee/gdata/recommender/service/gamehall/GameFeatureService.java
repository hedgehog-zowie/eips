package com.gionee.gdata.recommender.service.gamehall;

import com.gionee.gdata.common.utils.StringUtil;
import com.gionee.gdata.data.mybatis.entity.recommender.gamehall.GameItem;
import com.gionee.gdata.data.mybatis.entity.recommender.gamehall.GameItemDefaultFeatureVector;
import com.gionee.gdata.data.mybatis.entity.recommender.gamehall.GameItemFeatureVector;
import com.gionee.gdata.data.mybatis.entity.recommender.gamehall.GameUserItemFeatureVector;
import com.gionee.gdata.data.mybatis.entity.recommender.gamehall.GameVariableFeatureVector;
import com.gionee.gdata.data.mybatis.mapper.recommender.gamehall.GameItemFeatureVectorMapper;
import com.gionee.gdata.data.mybatis.mapper.recommender.gamehall.GameItemMapper;
import com.gionee.gdata.data.mybatis.mapper.recommender.gamehall.GameUserFeatureVectorMapper;
import com.gionee.gdata.data.mybatis.mapper.recommender.gamehall.GameUserItemFeatureVectorMapper;
import com.gionee.gdata.data.mybatis.mapper.recommender.gamehall.GameVariableFeatureVectorMapper;
import com.gionee.gdata.data.redis.repository.recommender.game.GameUserFeatureVectorRepository;
import com.gionee.gdata.data.redis.repository.recommender.game.GameUserItemFeatureVectorRepository;
import com.gionee.gdata.data.redis.repository.recommender.game.GameVariableFeatureVectorRepository;
import com.gionee.gdata.recommender.common.FeatureCode;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.Vectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * <code>FeatureService</code>.
 * 特征处理服务
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/11/22 14:05
 */
@Service
public class GameFeatureService {

    /**
     * 日志记录器.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(GameFeatureService.class);

    /**
     * 向量分隔符
     */
    private static final String VECTOR_SPLITTER = ",";

    /**
     * 用于获取用户特征的默认用户
     */
    private static final String USER_DEFAULT = "DEFAULT_USER";
    /**
     * 用于获取物品特征的默认物品
     */
    private static final String ITEM_DEFAULT = "DEFAULT_ITEM";
    /**
     * 变量特征的默认变量值
     */
    private static final String VARIABLE_VALUE_DEFAULT = "DEFAULT_VALUE";

    /**
     * 用户向量操作
     */
    @Autowired
    private GameUserFeatureVectorMapper gameUserFeatureVectorMapper;
    /**
     * 物品向量操作
     */
    @Autowired
    private GameItemFeatureVectorMapper gameItemFeatureVectorMapper;
    /**
     * 用户对物品偏好向量操作
     */
    @Autowired
    private GameUserItemFeatureVectorMapper gameUserItemFeatureVectorMapper;
    /**
     * 变量参数向量操作
     */
    @Autowired
    private GameVariableFeatureVectorMapper gameVariableFeatureVectorMapper;
    /**
     * 物品操作
     */
    @Autowired
    private GameItemMapper gameItemMapper;

    /**
     * 用户特征缓存
     */
    @Autowired
    private GameUserFeatureVectorRepository gameUserFeatureVectorRepository;
    /**
     * 用户对物品偏好的特征缓存
     */
    @Autowired
    private GameUserItemFeatureVectorRepository gameUserItemFeatureVectorRepository;
    /**
     * 变量特征向量缓存
     */
    @Autowired
    private GameVariableFeatureVectorRepository gameVariableFeatureVectorRepository;

    /**
     * 物品特征向量缓存
     */
    private Map<String, Vector> itemFeatureCache = Maps.newHashMap();
    /**
     * 物品集
     */
    private List<String> itemCache = Lists.newArrayList();
    /**
     * 物品默认特征
     */
    private Map<String, GameItemDefaultFeatureVector> defaultItemFeatureCache = Maps.newHashMap();
    /**
     * 变量特征向量缓存
     */
    private Map<String, Vector> variableFeatureCache = Maps.newHashMap();
    /**
     * 新变量特征向量缓存
     */
    private Map<String, Vector> variableFeatureCacheOfDaily = Maps.newHashMap();
    /**
     * 锁
     */
    private ReentrantReadWriteLock cacheLock = new ReentrantReadWriteLock();

    /**
     * 缓存待推荐物品、物品特征和变量特征
     */
    public void cacheFeatureVector() {
        List<GameItem> gameItemList = gameItemMapper.findAllGameItem();
        List<String> itemCache = Lists.newArrayList();
        for (GameItem gameItem : gameItemList) {
            itemCache.add(gameItem.getItemId());
        }
        List<GameItemDefaultFeatureVector> gameItemDefaultFeatureVectorList = gameItemFeatureVectorMapper.findAllGameItemDefaultFeature();
        Map<String, GameItemDefaultFeatureVector> gameItemDefaultFeatureVectorMap = Maps.newHashMap();
        for (GameItemDefaultFeatureVector gameItemDefaultFeatureVector : gameItemDefaultFeatureVectorList) {
            gameItemDefaultFeatureVectorMap.put(gameItemDefaultFeatureVector.getItemId(), gameItemDefaultFeatureVector);
        }
        List<GameItemFeatureVector> gameItemFeatureVectorList = gameItemFeatureVectorMapper.findAllGameItemFeatureVector();
        Map<String, Vector> itemFeatureCache = Maps.newHashMap();
        for (GameItemFeatureVector gameItemFeatureVector : gameItemFeatureVectorList) {
            itemFeatureCache.put(gameItemFeatureVector.getItemId(), generateVector(gameItemFeatureVector.getVector()));
        }
        List<GameVariableFeatureVector> gameVariableFeatureVectorList = gameVariableFeatureVectorMapper.findAllGameVariableFeatureVector();
        Map<String, Vector> variableFeatureCache = Maps.newHashMap();
        for (GameVariableFeatureVector gameVariableFeatureVector : gameVariableFeatureVectorList) {
            variableFeatureCache.put(gameVariableFeatureVector.getFeatureCode() +
                            gameVariableFeatureVector.getFeatureValue(),
                    generateVector(gameVariableFeatureVector.getVector()));
        }
        List<GameVariableFeatureVector> gameVariableFeatureVectorListOfDaily = gameVariableFeatureVectorMapper.findAllGameVariableFeatureVectorOfDaily();
        Map<String, Vector> variableFeatureCacheOfDaily = Maps.newHashMap();
        for (GameVariableFeatureVector gameVariableFeatureVectorOfDaily : gameVariableFeatureVectorListOfDaily) {
            variableFeatureCacheOfDaily.put(gameVariableFeatureVectorOfDaily.getFeatureCode() +
                            gameVariableFeatureVectorOfDaily.getFeatureValue(),
                    generateVector(gameVariableFeatureVectorOfDaily.getVector()));
        }
        cacheLock.writeLock().lock();
        try {
            this.itemCache = itemCache;
            this.defaultItemFeatureCache = gameItemDefaultFeatureVectorMap;
            this.itemFeatureCache = itemFeatureCache;
            this.variableFeatureCache = variableFeatureCache;
            this.variableFeatureCacheOfDaily = variableFeatureCacheOfDaily;
        } finally {
            cacheLock.writeLock().unlock();
        }
    }

    /**
     * 生成用户特征向量
     *
     * @param userMd5
     * @return
     */
    public Vector generateUserVector(String userMd5) {
        LOGGER.debug("invoked generateUserVector. userMd5 = {}", userMd5);
        String userVectorString = gameUserFeatureVectorRepository.getVector(userMd5);
        if (StringUtil.isBlank(userVectorString)) {
            userVectorString = gameUserFeatureVectorMapper.findFeatureVectorByUser(userMd5);
            if (StringUtil.isBlank(userVectorString)) {
                userVectorString = gameUserFeatureVectorMapper.findFeatureVectorByUser(USER_DEFAULT);
            } else {
                // 添加到缓存
                gameUserFeatureVectorRepository.setVector(userMd5, userVectorString);
            }
        }
        if (StringUtil.isBlank(userVectorString)) {
            LOGGER.error("get user feature error, userMd5 = {}", userMd5);
        }
        return generateVector(userVectorString);
    }

    /**
     * 生成用户对物品偏好的特征向量
     *
     * @param userMd5 用户
     * @return
     */
    public Map<String, Vector> generateUserItemVector(String userMd5) {
        LOGGER.debug("invoked generateUserItemVector. userMd5 = {}", userMd5);
        Map<String, String> userItemVectorStringMap = gameUserItemFeatureVectorRepository.getVectorMap(userMd5);
        if (userItemVectorStringMap == null) {
            List<GameUserItemFeatureVector> gameUserItemFeatureVectorList = gameUserItemFeatureVectorMapper.findFeatureVectorByUserAndItems(userMd5, itemCache);
            userItemVectorStringMap = Maps.newHashMap();
            if (gameUserItemFeatureVectorList.size() == 0) {
//                gameUserItemFeatureVectorList = gameUserItemFeatureVectorMapper.findFeatureVectorByUserAndItems(USER_DEFAULT, itemCache);
                String defaultUserItemVector = gameUserItemFeatureVectorMapper.findFeatureVectorByUserAndItem(USER_DEFAULT, ITEM_DEFAULT);
                for (String item : itemCache) {
                    userItemVectorStringMap.put(item, defaultUserItemVector);
                }
            } else {
                for (GameUserItemFeatureVector gameUserItemFeatureVector : gameUserItemFeatureVectorList) {
                    String item = gameUserItemFeatureVector.getItemId();
                    String vectorString = gameUserItemFeatureVector.getVector();
                    userItemVectorStringMap.put(item, vectorString);
                }
            }
            if (userItemVectorStringMap.size() > 0) {
                // 添加到缓存
                gameUserItemFeatureVectorRepository.setVectorMap(userMd5, userItemVectorStringMap);
            }
        }
        Map<String, Vector> userItemVectorMap = Maps.newHashMap();
        for (Map.Entry<String, String> entry : userItemVectorStringMap.entrySet()) {
            String item = entry.getKey();
            String vectorString = entry.getValue();
            if (StringUtil.isBlank(vectorString)) {
                LOGGER.info("generate users item vector error, vectorString is empty, user = {}, item= {}", userMd5, item);
            }
            Vector vector = generateVector(vectorString);
            userItemVectorMap.put(item, vector);
        }
        return userItemVectorMap;
    }

    /**
     * 生成参数的向量
     *
     * @param variableName  参数名
     * @param variableValue 参数值
     * @return
     */
    @Deprecated
    public Vector generateVariableVector(String variableName, String variableValue) {
        LOGGER.debug("invoked generateVariableVector. variableName = {}, variableValue = {}", variableName, variableValue);
        String variableFeatureVectorString = gameVariableFeatureVectorRepository.getVector(variableName, variableValue);
        if (StringUtil.isBlank(variableFeatureVectorString)) {
            variableFeatureVectorString = gameVariableFeatureVectorMapper.findFeatureVectorByCodeAndValue(variableName, variableValue);
            if (StringUtil.isBlank(variableFeatureVectorString)) {
                variableFeatureVectorString = gameVariableFeatureVectorMapper.findFeatureVectorByCodeAndValue(variableName, VARIABLE_VALUE_DEFAULT);
            } else {
                // 添加到缓存
                gameVariableFeatureVectorRepository.setVector(variableName, variableValue, variableFeatureVectorString);
            }
        }

        if (StringUtil.isBlank(variableFeatureVectorString)) {
            LOGGER.error("get variable vector error, variableName = {}, variableValue = {}", variableName, variableValue);
        }
        return generateVector(variableFeatureVectorString);
    }

    /**
     * 生成特征向量
     *
     * @param userMd5   用户
     * @param net       网络
     * @param dayOfWeek 星期
     * @param hourOfDay 小时
     * @return
     */
    @Deprecated
    @Cacheable(value = "gameDailyVectorCache", key = "#userMd5 + '_' + #net + '_' + #dayOfWeek + '_' + #hourOfDay")
    public Map<String, Vector> generateVector(String userMd5, String net, String dayOfWeek, String hourOfDay) {
        Map<String, Vector> vectors = Maps.newHashMap();
        Vector userVector = generateUserVector(userMd5);
        if (userVector == null) {
            userVector = Vectors.dense(new double[]{});
        }
        Vector netVector = variableFeatureCache.get(FeatureCode.NET.getCode() + net);
        if (netVector == null) {
            netVector = variableFeatureCache.get(FeatureCode.NET.getCode() + VARIABLE_VALUE_DEFAULT);
        }
        Vector dayOfWeekVector = variableFeatureCache.get(FeatureCode.DAY_OF_WEEK.getCode() + dayOfWeek);
        if (dayOfWeekVector == null) {
            dayOfWeekVector = variableFeatureCache.get(FeatureCode.DAY_OF_WEEK.getCode() + VARIABLE_VALUE_DEFAULT);
        }
        Vector hourOfDayVector = variableFeatureCache.get(FeatureCode.HOUR_OF_DAY.getCode() + hourOfDay);
        if (hourOfDayVector == null) {
            hourOfDayVector = variableFeatureCache.get(FeatureCode.HOUR_OF_DAY.getCode() + VARIABLE_VALUE_DEFAULT);
        }
        Map<String, Vector> userItemVectorMap = generateUserItemVector(userMd5);
        for (Map.Entry<String, Vector> entry : userItemVectorMap.entrySet()) {
            String item = entry.getKey();
            Vector userItemVector = entry.getValue();
            if (userItemVector == null) {
                LOGGER.info("can not get user item feature. user = {}, item = {}", userMd5, item);
                vectors.put(item, Vectors.dense(new double[0]));
                continue;
            }
            Vector itemVector = itemFeatureCache.get(item);
            if (itemVector == null) {
                LOGGER.info("can not get item feature. item = {}", item);
                vectors.put(item, Vectors.dense(new double[0]));
                continue;
            }
            double[] newVectorArray = new double[userVector.size() + itemVector.size() + userItemVector.size() + netVector.size() + dayOfWeekVector.size() + hourOfDayVector.size()];
            System.arraycopy(userVector.toArray(), 0, newVectorArray, 0, userVector.size());
            System.arraycopy(itemVector.toArray(), 0, newVectorArray, userVector.size(), itemVector.size());
            System.arraycopy(userItemVector.toArray(), 0, newVectorArray, userVector.size() + itemVector.size(), userItemVector.size());
            System.arraycopy(netVector.toArray(), 0, newVectorArray, userVector.size() + itemVector.size() + userItemVector.size(), netVector.size());
            System.arraycopy(dayOfWeekVector.toArray(), 0, newVectorArray, userVector.size() + itemVector.size() + userItemVector.size() + netVector.size(), dayOfWeekVector.size());
            System.arraycopy(hourOfDayVector.toArray(), 0, newVectorArray, userVector.size() + itemVector.size() + userItemVector.size() + netVector.size() + dayOfWeekVector.size(), hourOfDayVector.size());
            vectors.put(item, Vectors.dense(newVectorArray));
        }
        return vectors;
    }

    /**
     * 生成特征向量
     *
     * @param userMd5   用户
     * @param net       网络
     * @param dayOfWeek 星期
     * @param hourOfDay 小时
     * @return
     */
    @Cacheable(value = "newGameDailyVectorCache", key = "#userMd5 + '_' + #net + '_' + #dayOfWeek + '_' + #hourOfDay")
    public Map<String, Vector> generateVectorOfDaily(String userMd5, String net, String dayOfWeek, String hourOfDay) {
        // 变量特征
        Vector netVector = variableFeatureCacheOfDaily.get(FeatureCode.NET.getCode() + net);
        if (netVector == null) {
            netVector = variableFeatureCacheOfDaily.get(FeatureCode.NET.getCode() + VARIABLE_VALUE_DEFAULT);
        }
        Vector dayOfWeekVector = variableFeatureCacheOfDaily.get(FeatureCode.DAY_OF_WEEK.getCode() + dayOfWeek);
        if (dayOfWeekVector == null) {
            dayOfWeekVector = variableFeatureCacheOfDaily.get(FeatureCode.DAY_OF_WEEK.getCode() + VARIABLE_VALUE_DEFAULT);
        }
        Vector hourOfDayVector = variableFeatureCacheOfDaily.get(FeatureCode.HOUR_OF_DAY.getCode() + hourOfDay);
        if (hourOfDayVector == null) {
            hourOfDayVector = variableFeatureCacheOfDaily.get(FeatureCode.HOUR_OF_DAY.getCode() + VARIABLE_VALUE_DEFAULT);
        }
        // 用户对机型、物品的特征
        Map<String, String> macItemVectorMap = Maps.newHashMap();
        for (String item : itemCache) {
            GameItemDefaultFeatureVector gameItemDefaultFeatureVector = defaultItemFeatureCache.get(item);
            if (gameItemDefaultFeatureVector != null) {
                macItemVectorMap.put(item, defaultItemFeatureCache.get(item).getMacItemVector());
            }
        }
        List<GameUserItemFeatureVector> macItemVectorList = gameUserItemFeatureVectorMapper.findMacItemFeatureVectorOfDailyByUser(userMd5, itemCache);
        for (GameUserItemFeatureVector gameUserItemFeatureVector : macItemVectorList) {
            String item = gameUserItemFeatureVector.getItemId();
            String vectorString = gameUserItemFeatureVector.getVector();
            macItemVectorMap.put(item, vectorString);
        }
        // 用户对一级标签的特征
        Map<String, String> firstTagVectorMap = Maps.newHashMap();
        for (String item : itemCache) {
            GameItemDefaultFeatureVector gameItemDefaultFeatureVector = defaultItemFeatureCache.get(item);
            if (gameItemDefaultFeatureVector != null) {
                firstTagVectorMap.put(item, defaultItemFeatureCache.get(item).getFirstTagVector());
            }
        }
        List<GameUserItemFeatureVector> firstTagVectorList = gameUserItemFeatureVectorMapper.findFirstTagFeatureVectorOfDailyByUser(userMd5, itemCache);
        for (GameUserItemFeatureVector gameUserItemFeatureVector : firstTagVectorList) {
            String item = gameUserItemFeatureVector.getItemId();
            String vectorString = gameUserItemFeatureVector.getVector();
            firstTagVectorMap.put(item, vectorString);
        }
        // 用户对包等级的特征
        Map<String, String> packageVectorMap = Maps.newHashMap();
        for (String item : itemCache) {
            GameItemDefaultFeatureVector gameItemDefaultFeatureVector = defaultItemFeatureCache.get(item);
            if (gameItemDefaultFeatureVector != null) {
                packageVectorMap.put(item, defaultItemFeatureCache.get(item).getPackageVector());
            }
        }
        List<GameUserItemFeatureVector> packageVectorList = gameUserItemFeatureVectorMapper.findPackageFeatureVectorOfDailyByUser(userMd5, itemCache);
        for (GameUserItemFeatureVector gameUserItemFeatureVector : packageVectorList) {
            String item = gameUserItemFeatureVector.getItemId();
            String vectorString = gameUserItemFeatureVector.getVector();
            packageVectorMap.put(item, vectorString);
        }
        // 用户对物品相似度的特征
        Map<String, String> itemSimilarVectorMap = Maps.newHashMap();
        for (String item : itemCache) {
            GameItemDefaultFeatureVector gameItemDefaultFeatureVector = defaultItemFeatureCache.get(item);
            if (gameItemDefaultFeatureVector != null) {
                itemSimilarVectorMap.put(item, defaultItemFeatureCache.get(item).getSimilarVector());
            }
        }
        List<GameUserItemFeatureVector> itemSimilarVectorList = gameUserItemFeatureVectorMapper.findUserItemFeatureVectorOfDailyByUser(userMd5, itemCache);
        for (GameUserItemFeatureVector gameUserItemFeatureVector : itemSimilarVectorList) {
            String item = gameUserItemFeatureVector.getItemId();
            String vectorString = gameUserItemFeatureVector.getVector();
            itemSimilarVectorMap.put(item, vectorString);
        }

        // 数据库中取出用户对物品的特征
//        Map<String, String> userItemVectorStringMap = gameUserItemFeatureVectorRepository.getVectorMap(userMd5);
//        if (userItemVectorStringMap == null) {
//            List<GameUserItemFeatureVector> gameUserItemFeatureVectorList = gameUserItemFeatureVectorMapper.findFeatureVectorOfDailyByUser(userMd5);
//            userItemVectorStringMap = Maps.newHashMap();
//            for (GameUserItemFeatureVector gameUserItemFeatureVector : gameUserItemFeatureVectorList) {
//                String item = gameUserItemFeatureVector.getItemId();
//                String vectorString = gameUserItemFeatureVector.getVector();
//                userItemVectorStringMap.put(item, vectorString);
//            }
//            if (userItemVectorStringMap.size() > 0) {
//                // 添加到缓存
//                gameUserItemFeatureVectorRepository.setVectorMap(userMd5, userItemVectorStringMap);
//            }
//        }

        // 合并特征
        Map<String, Vector> vectors = Maps.newHashMap();
        for (String item : itemCache) {
            String macItemVectorString = macItemVectorMap.get(item);
            Vector macItemVector = generateVector(macItemVectorString);
            String firstTagVectorString = firstTagVectorMap.get(item);
            Vector firstTagVector = generateVector(firstTagVectorString);
            String packageVectorString = packageVectorMap.get(item);
            Vector packageVector = generateVector(packageVectorString);
            String itemSimilarVectorString = itemSimilarVectorMap.get(item);
            Vector itemSimilarVector = generateVector(itemSimilarVectorString);
            double[] newVectorArray = new double[macItemVector.size() + firstTagVector.size() + packageVector.size() + itemSimilarVector.size() + netVector.size() + dayOfWeekVector.size() + hourOfDayVector.size()];
            System.arraycopy(macItemVector.toArray(), 0, newVectorArray, 0, macItemVector.size());
            System.arraycopy(firstTagVector.toArray(), 0, newVectorArray, macItemVector.size(), firstTagVector.size());
            System.arraycopy(packageVector.toArray(), 0, newVectorArray, macItemVector.size() + firstTagVector.size(), packageVector.size());
            System.arraycopy(itemSimilarVector.toArray(), 0, newVectorArray, macItemVector.size() + firstTagVector.size() + packageVector.size(), itemSimilarVector.size());
            System.arraycopy(netVector.toArray(), 0, newVectorArray, macItemVector.size() + firstTagVector.size() + packageVector.size() + itemSimilarVector.size(), netVector.size());
            System.arraycopy(dayOfWeekVector.toArray(), 0, newVectorArray, macItemVector.size() + firstTagVector.size() + packageVector.size() + itemSimilarVector.size() + netVector.size(), dayOfWeekVector.size());
            System.arraycopy(hourOfDayVector.toArray(), 0, newVectorArray, macItemVector.size() + firstTagVector.size() + packageVector.size() + itemSimilarVector.size() + netVector.size() + dayOfWeekVector.size(), hourOfDayVector.size());
            vectors.put(item, Vectors.dense(newVectorArray));
        }
        return vectors;
    }

    /**
     * 向量字符串转化成向量
     *
     * @param vectorString 向量字符串
     * @return 返回向量
     */
    public Vector generateVector(final String vectorString) {
        if (StringUtil.isBlank(vectorString)) {
            return Vectors.dense(new double[0]);
        }
        String[] values = vectorString.split(VECTOR_SPLITTER);
        double[] doubleValues = new double[values.length];
        for (int i = 0; i < values.length; i++) {
            doubleValues[i] = Double.parseDouble(values[i]);
        }
        return Vectors.dense(doubleValues);
    }

    public void setGameUserFeatureVectorMapper(GameUserFeatureVectorMapper gameUserFeatureVectorMapper) {
        this.gameUserFeatureVectorMapper = gameUserFeatureVectorMapper;
    }

    public void setGameItemFeatureVectorMapper(GameItemFeatureVectorMapper gameItemFeatureVectorMapper) {
        this.gameItemFeatureVectorMapper = gameItemFeatureVectorMapper;
    }

    public void setGameUserItemFeatureVectorMapper(GameUserItemFeatureVectorMapper gameUserItemFeatureVectorMapper) {
        this.gameUserItemFeatureVectorMapper = gameUserItemFeatureVectorMapper;
    }

    public void setGameVariableFeatureVectorMapper(GameVariableFeatureVectorMapper gameVariableFeatureVectorMapper) {
        this.gameVariableFeatureVectorMapper = gameVariableFeatureVectorMapper;
    }

    public void setGameUserFeatureVectorRepository(GameUserFeatureVectorRepository gameUserFeatureVectorRepository) {
        this.gameUserFeatureVectorRepository = gameUserFeatureVectorRepository;
    }

    public void setGameUserItemFeatureVectorRepository(GameUserItemFeatureVectorRepository gameUserItemFeatureVectorRepository) {
        this.gameUserItemFeatureVectorRepository = gameUserItemFeatureVectorRepository;
    }

    public void setGameVariableFeatureVectorRepository(GameVariableFeatureVectorRepository gameVariableFeatureVectorRepository) {
        this.gameVariableFeatureVectorRepository = gameVariableFeatureVectorRepository;
    }
}
