package com.gionee.gdata.recommender.model.theme;

/**
 * <code>RuleTag</code>.
 * 主题干预规则标签
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/13 13:48
 */
public class RuleTag {

    /**
     * 颜色
     */
    private String color;
    /**
     * 风格
     */
    private String style;

    /**
     * 系列
     */
    private String series;

    /**
     * 略
     */
    public RuleTag() {
    }

    /**
     * 略
     *
     * @param color 略
     * @param style 略
     */
    public RuleTag(final String color, final String style) {
        this.color = color;
        this.style = style;
    }

    /**
     *
     * @param color
     * @param style
     * @param series 系列
     */
    public RuleTag(String color, String style, String series) {
        this.color = color;
        this.style = style;
        this.series = series;
    }

    /**
     * 相似判断
     *
     * @param other 略
     * @return 略
     */
    public boolean similarWith(final RuleTag other) {
        if (null == other) {
            return false;
        }
        return color.equals(other.getColor()) || style.equals(other.getStyle());
    }

    public String getColor() {
        return color;
    }

    public void setColor(final String color) {
        this.color = color;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(final String style) {
        this.style = style;
    }

    public String getSeries() {
        return series;
    }

    public void setSeries(String series) {
        this.series = series;
    }
}
