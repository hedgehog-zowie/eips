package com.gionee.gdata.recommender.service.theme;

import com.gionee.gdata.data.mybatis.entity.recommender.theme.ItemTag;
import com.gionee.gdata.data.mybatis.mapper.recommender.theme.ItemTagMapper;
import com.gionee.gdata.recommender.model.RecommendItem;
import com.gionee.gdata.recommender.model.theme.RuleTag;
import com.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * <code>ThemeRuleService</code>.
 * 主题干预规则服务类
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/13 14:01
 */
@Service
public class ThemeRuleService {

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ThemeRuleService.class);

    /**
     * 主题商城每一行展示的主题个数
     */
    private static final int ROW_SIZE = 3;

    /**
     * 锁
     */
    private ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    /**
     * 主题标签mapper
     */
    @Autowired
    private ItemTagMapper itemTagMapper;
    /**
     * 干预规则标签缓存, item作为key, RuleTag作为value
     */
    private Map<String, RuleTag> ruleTagCache = Maps.newHashMap();

    /**
     * 缓存干预规则标签
     */
    public void cacheRuleTag() {
        LOGGER.info("更新主题干预规则缓存开始");
        // 获取颜色标签
        List<ItemTag> colorTagList = itemTagMapper.findAllItemColorTag();
        if (colorTagList == null || colorTagList.size() == 0) {
            LOGGER.error("get theme color tag from table error.");
            return;
        }
        // 获取风格标签
        List<ItemTag> styleTagList = itemTagMapper.findAllItemStyleTag();
        if (styleTagList == null || styleTagList.size() == 0) {
            LOGGER.error("get theme style tag from table error.");
            return;
        }

        List<ItemTag> seriesTagList = itemTagMapper.findAllItemSeriesTag();
        if (seriesTagList == null || seriesTagList.size() == 0) {
            LOGGER.error("get theme series tag from table error.");
            return;
        }
        // 添加到缓存
        lock.writeLock().lock();
        try {
            ruleTagCache.clear();
            for (ItemTag itemTag : colorTagList) {
                String item = itemTag.getItem();
                RuleTag ruleTag = ruleTagCache.get(item);
                if (ruleTag == null) {
                    ruleTag = new RuleTag();
                }
                ruleTag.setColor(itemTag.getTagValue());
                ruleTagCache.put(item, ruleTag);
            }
            for (ItemTag itemTag : styleTagList) {
                String item = itemTag.getItem();
                RuleTag ruleTag = ruleTagCache.get(item);
                if (ruleTag == null) {
                    ruleTag = new RuleTag();
                }
                ruleTag.setStyle(itemTag.getTagValue());
                ruleTagCache.put(item, ruleTag);
            }
            for (ItemTag itemTag : seriesTagList) {
                String item = itemTag.getItem();
                RuleTag ruleTag = ruleTagCache.get(item);
                if (ruleTag == null) {
                    ruleTag = new RuleTag();
                }
                ruleTag.setSeries(itemTag.getTagValue());
                ruleTagCache.put(item, ruleTag);
            }
        } finally {
            lock.writeLock().unlock();
        }
        LOGGER.info("更新主题干预规则缓存完成");
    }

    /**
     * 干预规则，先填充奇数位，再填充偶数位，检查当前偶数位主题与其相邻的位置的主题是否存在相同属性
     *
     * @param limitedItem 结果列表
     * @return 干预后的结果列表
     */
    public RecommendItem[] rule(final List<RecommendItem> limitedItem) {
        lock.readLock().lock();
        try {
            int resultSize = limitedItem.size();
            // 干预后的结果列表
            RecommendItem[] ruledRecommendItems = new RecommendItem[resultSize];
            // 填充奇数位
            // 使用相同位置填充
//        for (int i = 0; i < needResultSize; ) {
//            ruledResult[i] = limitedItem.get(i);
//            i += 2;
//        }
            // 先填充评分最高的好奇数位
            int li = 0;
            for (int ri = 0; ri < resultSize; ri += 2) {
                ruledRecommendItems[ri] = limitedItem.get(li);
                li += 1;
            }
            // 移除已选
            for (RecommendItem item : ruledRecommendItems) {
                limitedItem.remove(item);
            }
            // 填充偶数位
            for (int i = 1; i < resultSize; i += 2) {
                // 左， i对3取余等于0时，表示当前位置处于最左侧
                RuleTag leftRuleTag = null;
                if (i % ROW_SIZE == 0) {
                    RecommendItem recommendItem = ruledRecommendItems[i - 1];
                    String itemId = recommendItem.getItemId();
                    leftRuleTag = ruleTagCache.get(itemId);
                }
                // 上， 当i - 3大于等于0时，才存在上方的位置
                RuleTag upRuleTag = null;
                if ((i - ROW_SIZE) >= 0) {
                    RecommendItem recommendItem = ruledRecommendItems[i - ROW_SIZE];
                    String itemId = recommendItem.getItemId();
                    upRuleTag = ruleTagCache.get(itemId);
                }
                // 右， i+1对3取余等于0时，表示当前位置处于最右侧
                RuleTag rightRuleTag = null;
                if ((i + 1) < resultSize && (i + 1) % ROW_SIZE != 0) {
                    RecommendItem recommendItem = ruledRecommendItems[i + 1];
                    String itemId = recommendItem.getItemId();
                    rightRuleTag = ruleTagCache.get(itemId);
                }
                // 下， 当i + 3小于resultSize时，才存在下方的位置
                RuleTag downRuleTag = null;
                if ((i + ROW_SIZE) < resultSize) {
                    RecommendItem recommendItem = ruledRecommendItems[i + ROW_SIZE];
                    String itemId = recommendItem.getItemId();
                    downRuleTag = ruleTagCache.get(itemId);
                }
                RecommendItem choose = null;
                for (RecommendItem recommendItem : limitedItem) {
                    String itemId = recommendItem.getItemId();
                    RuleTag current = ruleTagCache.get(itemId);
                    if (current == null || !(current.similarWith(leftRuleTag) || (current.similarWith(upRuleTag)) || current.similarWith(rightRuleTag) || current.similarWith(downRuleTag))) {
                        choose = recommendItem;
                        break;
                    }
                }
                if (choose == null) {
                    choose = limitedItem.get(0);
                }
                ruledRecommendItems[i] = choose;
                limitedItem.remove(choose);
            }
            return ruledRecommendItems;
        } finally {
            lock.readLock().unlock();
        }
    }

}
