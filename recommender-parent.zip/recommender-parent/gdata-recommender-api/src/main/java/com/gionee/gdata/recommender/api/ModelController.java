package com.gionee.gdata.recommender.api;

import com.gionee.gdata.common.utils.StringUtil;
import com.gionee.gdata.recommender.model.Response;
import com.gionee.gdata.recommender.service.LRModelService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * <code>ModelController</code>.
 * 模型更新控制层
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/7 10:11
 */
@RestController
@RequestMapping("/model")
public class ModelController {

    /**
     * 日志记录器.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ModelController.class);

    /**
     * LR模型服务类
     */
    @Autowired
    private LRModelService lrModelService;

    /**
     * 更新游戏大厅-每日一荐LR模型
     *
     * @return
     */
    @RequestMapping(value = "/game/daily/lr")
    public Response updateGameDailyLrModel(final @RequestParam(required = false) String path) {
        Response response = new Response();
        if (StringUtil.isBlank(path)) {
            lrModelService.updateLRModelOfGameDaily();
        } else {
            lrModelService.updateLRModelOfGameDaily(path);
        }
        response.ok();
        return response;
    }

}
