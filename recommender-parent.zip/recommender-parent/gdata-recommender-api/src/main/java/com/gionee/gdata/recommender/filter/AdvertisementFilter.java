package com.gionee.gdata.recommender.filter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

/**
 * <code>AdvertisementFilter</code>.
 * 广告过滤器
 * 2017/05/03 不再使用，广告CTR预估转移至广告项目下
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:34
 */
@WebFilter(filterName = "advertisementFilter", urlPatterns = "/advertisement/*")
@Deprecated
public class AdvertisementFilter implements Filter {
    /**
     * 略
     *
     * @param filterConfig 略
     * @throws ServletException 略
     */
    @Override
    public void init(final FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(final ServletRequest servletRequest, final ServletResponse servletResponse, final FilterChain filterChain) throws IOException, ServletException {

    }

    @Override
    public void destroy() {

    }
//    private static final Logger logger = LoggerFactory.getLogger(AdvertisementFilter.class);
//    @Value(value = "${recommender.api.advertisement.appId}")
//    private String appId;
//    @Value(value = "${recommender.api.advertisement.appKey}")
//    private String appKey;
//
//    @Override
//    public void init(FilterConfig filterConfig) throws ServletException {
//        logger.info("init advertisement filter");
//        SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, filterConfig.getServletContext());
//    }
//
//    @Override
//    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
//        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
//        String inputAppId = StringUtil.isBlank(httpServletRequest.getHeader(ParamConstants.APPID))
//                ? "" : httpServletRequest.getHeader(ParamConstants.APPID).trim();
//        if (!appId.equals(inputAppId)) {
//            logger.info("appId不匹配, 系统appId = {}, 输入参数appId = {}", appId, inputAppId);
//            servletResponse.getOutputStream().write(RecommendResult.RecommendResultCode.ERROR_APPID.toString().getBytes());
//            return;
//        }
//        String signature = StringUtil.isBlank(httpServletRequest.getHeader(ParamConstants.SIGNATURE))
//                ? "" : httpServletRequest.getHeader(ParamConstants.SIGNATURE).trim();
//        String imei = StringUtil.isBlank(httpServletRequest.getParameter(ParamConstants.ADVERTISEMENT_IMEI))
//                ? "" : httpServletRequest.getParameter(ParamConstants.ADVERTISEMENT_IMEI).trim();
//        String apps = StringUtil.isBlank(httpServletRequest.getParameter(ParamConstants.ADVERTISEMENT_APPS))
//                ? "" : httpServletRequest.getParameter(ParamConstants.ADVERTISEMENT_APPS).trim();
//        try {
//            if (StringUtil.isBlank(signature) || !signature.equals(HashUtil.md5Encode(appKey + StringUtil.getSortedString(imei, apps)))) {
//                logger.info("signature error，appId: {}, signature: {}。", inputAppId, signature);
//                servletResponse.getOutputStream().write(RecommendResult.RecommendResultCode.ERROR_SIGNATURE.toString().getBytes());
//                return;
//            }
//        } catch (NoSuchAlgorithmException e) {
//            logger.error("计算md5失败，appId = {}, appKey = {}, signature = {}, imei = {}, apps = {}. ",
//                    inputAppId, appKey, signature, imei, apps, e);
//            servletResponse.getOutputStream().write(RecommendResult.RecommendResultCode.ERROR_SYSTEM.toString().getBytes());
//        }
//        filterChain.doFilter(servletRequest, servletResponse);
//    }
//
//    @Override
//    public void destroy() {
//        logger.info("destroy advertisement filter");
//    }
}
