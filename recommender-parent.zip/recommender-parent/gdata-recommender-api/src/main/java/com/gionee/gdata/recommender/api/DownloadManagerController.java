package com.gionee.gdata.recommender.api;

import com.gionee.gdata.common.utils.JsonUtil;
import com.gionee.gdata.common.utils.StringUtil;
import com.gionee.gdata.recommender.common.ResultCode;
import com.gionee.gdata.recommender.model.downloadmanager.DownloadManagerRecommendResult;
import com.gionee.gdata.recommender.service.downloadmanager.DownloadManagerService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * <code>DownloadManagerController</code>.
 * 下载管理的推荐接口
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2018/1/3 16:10
 */
@RestController
@RequestMapping("/download-manager")
public class DownloadManagerController {
    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DownloadManagerController.class);

    /**
     * 下载管理推荐服务
     */
    @Autowired
    private DownloadManagerService downloadManagerService;

    /**
     * @param imei  imei的MD5编码
     * @param apps  app包名列表
     * @param limit 限制结果个数
     * @return 下载管理推荐结果
     */
    @RequestMapping(value = "/similar", method = RequestMethod.GET)
    public DownloadManagerRecommendResult getRecommendResult(final @RequestParam(value = "imei") String imei,
                                                             final @RequestParam(value = "apps") String apps,
                                                             final @RequestParam(value = "limit", defaultValue = "100") Integer limit) {
        LOGGER.info("start\001{}\001{}\001{}\001{}", (new Date()).getTime(), imei, apps, limit);
        if (StringUtil.isBlank(imei)) {
            DownloadManagerRecommendResult downloadManagerRecommendResult = new DownloadManagerRecommendResult();
            downloadManagerRecommendResult.setResultCode(ResultCode.ERROR_PARAM);
            LOGGER.error("imei不可为空");
            return downloadManagerRecommendResult;
        }
        if (StringUtil.isBlank(apps)) {
            DownloadManagerRecommendResult downloadManagerRecommendResult = new DownloadManagerRecommendResult();
            downloadManagerRecommendResult.setResultCode(ResultCode.ERROR_PARAM);
            LOGGER.error("app列表不可为空");
            return downloadManagerRecommendResult;
        }
        DownloadManagerRecommendResult downloadManagerRecommendResult = downloadManagerService.getRecommendResult(imei, apps, limit);
        LOGGER.info("end\001{}\001{}\001{}\001{}\001{}", (new Date()).getTime(), imei, apps, limit, JsonUtil.toJson(downloadManagerRecommendResult));
        return downloadManagerRecommendResult;
    }

}
