package com.gionee.gdata.recommender.model;

import com.gionee.gdata.recommender.common.Operation;

import java.io.Serializable;

/**
 * <code>RecommendItem</code>.
 * 推荐物品
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/8/23 14:43
 */
public class RecommendItem implements Serializable {

    /**
     * 物品ID
     */
    private String itemId;
    /**
     * 运营策略
     */
    private Operation opeId;
    /**
     * ABTag
     */
    private String abId;

    public RecommendItem() {
    }

    public RecommendItem(String itemId, Operation opeId, String abId) {
        this.itemId = itemId;
        this.opeId = opeId;
        this.abId = abId;
    }

    @Override
    public int hashCode() {
        return this.getItemId().hashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (!(other instanceof RecommendItem)) {
            return false;
        }
        return this.getItemId().equals(((RecommendItem) other).getItemId());
    }

    @Override
    public String toString() {
        return "RecommendItem{" +
                "itemId='" + itemId + '\'' +
                ", opeId=" + opeId +
                ", abId=" + abId +
                '}';
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public Operation getOpeId() {
        return opeId;
    }

    public void setOpeId(Operation opeId) {
        this.opeId = opeId;
    }

    public String getAbId() {
        return abId;
    }

    public void setAbId(String abId) {
        this.abId = abId;
    }
}
