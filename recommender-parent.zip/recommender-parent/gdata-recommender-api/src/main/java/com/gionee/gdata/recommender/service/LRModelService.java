package com.gionee.gdata.recommender.service;

import com.clearspring.analytics.util.Lists;
import com.gionee.gdata.common.utils.StringUtil;
import com.gionee.gdata.recommender.common.ABID;
import com.gionee.gdata.recommender.model.gamehall.GameDailyRecommendItem;
import org.apache.spark.mllib.classification.LogisticRegressionModel;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.Vectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * <code>LRModelService</code>.
 * LR模型服务
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/11/22 14:05
 */
@Service
public class LRModelService extends AbstractModelService {

    /**
     * 日志记录器.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(LRModelService.class);

    /**
     * 游戏大厅-每日一荐LR模型
     */
    private LogisticRegressionModel lrModelOfGameDaily;

    /**
     * 游戏大厅-每日一荐LR模型路径
     */
    @Value(value = "${recommender.api.model.game.daily.lr}")
    private String lrModelPathOfGameDaily;

    /**
     * 游戏大厅-每日一荐LR模型锁
     */
    private ReentrantReadWriteLock lrModelOfGameDailyLock = new ReentrantReadWriteLock();

    /**
     * 更新游戏大厅-每日一荐LR模型
     *
     * @return
     */
    public LogisticRegressionModel updateLRModelOfGameDaily() {
        return updateLRModelOfGameDaily(lrModelPathOfGameDaily);
    }

    /**
     * 更新游戏大厅-每日一荐LR模型
     *
     * @return 返回游戏大厅-每日一荐LR模型
     */
    public LogisticRegressionModel updateLRModelOfGameDaily(String lrModelPath) {
        if (StringUtil.isBlank(lrModelPath)) {
            LOGGER.error("LR model path is blank, please check it.");
            return null;
        }
        LogisticRegressionModel newModel = LogisticRegressionModel.load(SPARK_CONTEXT, lrModelPath);
        lrModelOfGameDailyLock.writeLock().lock();
        try {
            lrModelOfGameDaily = newModel;
        } finally {
            lrModelOfGameDailyLock.writeLock().unlock();
        }
        return lrModelOfGameDaily;
    }

    /**
     * 游戏大厅-每日一荐LR预测
     *
     * @param vector
     * @return
     */
    private Double predict(final Vector vector) {
        Double result;
        if (lrModelOfGameDaily == null) {
            LOGGER.error("lr model of game daily is null, reload it.");
            updateLRModelOfGameDaily();
        }
        try {
            result = lrModelOfGameDaily.predict(vector);
        } catch (RuntimeException re) {
            LOGGER.error("预测出错：{}, vector = {}.", re.getLocalizedMessage(), vector);
            // 检查模型特征个数与传入向量参数特征个数是否一致
            int num = lrModelOfGameDaily.numFeatures();
            double[] newArray = new double[num];
            double[] oldArray = vector.toArray();
            if (vector.size() < num) {
                System.arraycopy(oldArray, 0, newArray, 0, oldArray.length);
            } else {
                System.arraycopy(oldArray, 0, newArray, 0, newArray.length);
            }
            Vector newVector = Vectors.dense(newArray);
            result = lrModelOfGameDaily.predict(newVector);
        }
        return result;
    }

    /**
     * 游戏大厅-每日一荐预测结果
     *
     * @param vectors
     * @return
     */
    public List<GameDailyRecommendItem> predict(Map<String, Vector> vectors) {
        List<GameDailyRecommendItem> results = Lists.newArrayList();
        if (vectors.size() == 0) {
            LOGGER.error("vectors is empty, please check your vector config.");
            return results;
        }
        for (Map.Entry<String, Vector> vectorEntry : vectors.entrySet()) {
            GameDailyRecommendItem result = new GameDailyRecommendItem(vectorEntry.getKey(), ABID.recGameDailyLR, predict(vectorEntry.getValue()));
            results.add(result);
        }
        return results;
    }

}
