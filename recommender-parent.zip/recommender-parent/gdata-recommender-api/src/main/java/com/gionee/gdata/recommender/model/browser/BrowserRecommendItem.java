package com.gionee.gdata.recommender.model.browser;

import com.gionee.gdata.recommender.common.ABID;
import com.gionee.gdata.recommender.common.Operation;
import com.gionee.gdata.recommender.model.RecommendItem;

/**
 * 浏览器推荐项
 *
 * @author yuwei
 * @version: 1.0-SNAPSHOT
 * date: 2017-10-13 08:47:23
 */
public class BrowserRecommendItem extends RecommendItem implements Comparable<BrowserRecommendItem> {

    /**
     * 评分
     */
    private Double score;

    public BrowserRecommendItem(String itemId, Operation opeId, ABID abId, Double score) {
        super(itemId, opeId, abId.toString());
        this.score = score;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    @Override
    public int compareTo(BrowserRecommendItem o) {
        return Double.compare(o.getScore(), this.score);
    }

}
