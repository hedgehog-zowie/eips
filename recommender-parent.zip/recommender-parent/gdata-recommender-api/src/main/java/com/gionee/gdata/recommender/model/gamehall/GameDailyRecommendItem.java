package com.gionee.gdata.recommender.model.gamehall;

import com.gionee.gdata.recommender.common.ABID;
import com.gionee.gdata.recommender.model.RecommendItem;

/**
 * <code>GameDailyRecommendItem</code>.
 * 游戏大厅每日一荐推荐项
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/11/21 9:46
 */
public class GameDailyRecommendItem extends RecommendItem implements Comparable<GameDailyRecommendItem> {

    /**
     * 预测评分(偏好程度)
     */
    private Double score;

    /**
     * 构造函数
     *
     * @param itemId
     * @param abId
     * @param score
     */
    public GameDailyRecommendItem(String itemId, ABID abId, Double score) {
        super(itemId, null, abId.toString());
        this.score = score;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    @Override
    public int compareTo(GameDailyRecommendItem other) {
        return other.getScore().compareTo(this.getScore());
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof GameDailyRecommendItem)) {
            return false;
        }
        return compareTo((GameDailyRecommendItem) object) == 0;
    }

    @Override
    public int hashCode() {
        return this.getScore().hashCode();
    }

}
