package com.gionee.gdata.recommender.model.gamehall;

import com.gionee.gdata.recommender.common.ABID;
import com.gionee.gdata.recommender.common.Operation;
import com.gionee.gdata.recommender.model.RecommendItem;

/**
 * 游戏大厅游戏桌面推荐项
 *
 * @author yuwei
 * @version: 1.0-SNAPSHOT
 * date: 2017-10-13 08:47:23
 */
public class GameDesktopRecommendItem extends RecommendItem {

    /**
     * 结果id
     */
    private String resultId;

    public GameDesktopRecommendItem(String itemId, Operation opeId, ABID abId, String resultId) {
        super(itemId, opeId, abId.toString());
        this.resultId = resultId;
    }

    public String getResultId() {
        return resultId;
    }

    public void setResultId(String resultId) {
        this.resultId = resultId;
    }
}
