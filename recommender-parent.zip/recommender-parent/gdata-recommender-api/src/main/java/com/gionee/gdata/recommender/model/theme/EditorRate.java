package com.gionee.gdata.recommender.model.theme;

/**
 * @author yuwei
 * @version 1.0-SNAPSHOT
 * @description 小编推荐比例
 * @date
 */
public class EditorRate {

    public static Double similarRate1 = 1.0;

    public static Double similarRate2 = 1.0;

    public static Double similarRate3 = 1.0;

    public static Double similarRate4 = 40.0;

    public static Double similarRate1Temp = 1d;

    public static Double similarRate2Temp = 1d;

    public static Double similarRate3Temp = 1d;

    public static Double similarRate4Temp = 40d;
}
