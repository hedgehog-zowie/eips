#!/bin/bash
# 下载管理日志上传HDFS，部署于10.10.10.100服务器/data/dataget/downloadManager目录下
HADOOP_HOME=/home/hadoop/hadoop-2.2.0
HIVE_HOME=/home/hadoop/hive
LOG_DIR=/data/dataget/theme-rec-api/web04
TABLE_NAME=rec_api_theme_log
HDFS_DIR=/user/hive/warehouse/${TABLE_NAME}

cd ${LOG_DIR}
while true
do
ls gdata-theme-api*.log | while read filename
do
  md5=`md5sum ${filename} | awk '{print $1}'`
  oldMd5=""
  if [ -f ${filename}.md5 ]
  then
    oldMd5=`cat ${filename}.md5`
  fi
  if [ "${md5}" != "${oldMd5}" ]
  then
    dayId=${filename:16:4}${filename:21:2}${filename:24:2}
    ${HIVE_HOME}/bin/hive -e "alter table ${TABLE_NAME} add if not exists partition (day_id = ${dayId})"
    dayPath=${HDFS_DIR}/day_id=${dayId}
    echo "md5不一致，上传文件${filename}到${dayPath}"
    ${HADOOP_HOME}/bin/hdfs dfs -mkdir -p ${dayPath}
    ${HADOOP_HOME}/bin/hdfs dfs -put -f ${filename} ${dayPath}
    echo ${md5} > ${filename}.md5
  fi
done
sleep 60
done