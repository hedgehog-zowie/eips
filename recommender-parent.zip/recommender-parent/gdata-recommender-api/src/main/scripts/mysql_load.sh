#!/bin/bash
# ./mysql_load.sh
#set -x
############################################################################
#   creator:   xiaojp@20171124
#   使用须知： 将数据导入阿里云RDS 指定库,导入前需作MD5判断,确保数据一致性
#   mysqlconnetor: mysql -u prodrecdbw -pprd1qaz@WSX -h rm-bp1lbec09qo8h1ib8.mysql.rds.aliyuncs.com
#   sample:    LOAD DATA LOCAL INFILE "/data/recommender/game_hall/daily/feature_vector/p_fact_imei_vector" REPLACE INTO TABLE game_user_feature_vector(user_md5, vector);
#
############################################################################
source ~/.bash_profile
#0、邮件信息
receiver_list='duanwm@gionee.com'
sender='sspadm@gionee.com'
password='A1c9moYh'
server='smtp.gionee.com'
env='game recommand'
#1、阿里云RDS配置信息
mysql_host=rm-bp1lbec09qo8h1ib8.mysql.rds.aliyuncs.com
mysql_port=3306
mysql_user=prodrecdbw
mysql_pass=prd1qaz@WSX
mysql_database=prodrecdb01
mysqlcmd="mysql -h${mysql_host} -p${mysql_port} -u${mysql_user} -p${mysql_pass} -D ${mysql_database}"
#2、文件系统配置信息
datarootdir="/data/recommender/game_hall/daily"
datasubdir=${datarootdir}/feature_vector
databakdir=${datarootdir}/bak
log_path="/data/devdata/logs"


function write_log() {
		log_info=$1
		echo -e "[`date +%Y-%m-%d` `date +%H:%M:%S`]:		${log_info}" >> ${log_path}/gamerec.log
		echo -e $log_info
}

function send_mail(){
		/usr/local/bin/sendEmail -f ${sender} -t ${receiver_list} -s ${server} -u "${env} error" -m "$1" -xu ${sender} -xp ${password}
}
#/usr/local/bin/sendEmail -f 'sspadm@gionee.com' -t 'xiaojp@gionee.com' -s 'smtp.gionee.com' -u "game recommand error" -m "error.........." -xu 'sspadm@gionee.com' -xp 'A1c9moYh'

#开始,判断是否已有程序在运行,命令执行也会产生一个线程,所以要大于2,crontab 调用时 应大于3
if [[ $(ps -ef|grep mysql_load.sh|grep -v "/bin/sh -c"|grep -v grep|wc -l) -gt 2 ]];then
		write_log "the old process is still in,no longer start new process,please quickly check why old process is still there.... "
		send_mail "the old process is still in,no longer start new process,please quickly check why old process is still there.... "
		exit -1
fi

#第一步,判断文件是否传输完,并校验完整性
write_log "start validate ${datarootdir}/md5_file"
wait_file_times=0
while true; do
	if [[ -f ${datarootdir}/md5_file ]]; then
			src_file_md5_value=$(cat ${datarootdir}/md5_file|awk '{print $1}')
			lc_file_md5_value=$(md5sum ${datarootdir}/gamerec.tgz|awk '{print $1}')
			if [[ "$src_file_md5_value" != "$lc_file_md5_value" ]]; then
					write_log "file transfer wrong.....\n src md5: $src_file_md5_value local md5: $lc_file_md5_value"
					write_log "send mail and exit program..."
					send_mail "file transfer wrong,src md5: $src_file_md5_value local md5: lc_file_md5_value,please quickly check...."
					exit -1
			else
					write_log "file transfer right..... "
					write_log "mv ${datarootdir}/md5_file ${databakdir}/md5_file_`date +%Y%m%d`"
					mv ${datarootdir}/md5_file ${databakdir}/md5_file_`date +%Y%m%d`
					break
			fi 
	else
			write_log "file not ready..... "
			let wait_file_times++
			if [[ $wait_file_times -gt 20 ]]; then
					write_log "File has not been pushed over, has been delayed for more than 1 hours,please quickly check....."
					send_mail "File has not been pushed over, has been delayed for more than 1 hours,please quickly check....."
			fi
			sleep 180
	fi
done
write_log "end validate ${datarootdir}/md5_file"

#第二步,删除当前子数据目录、解压及删除一个月前数据
write_log "start uncompress ${datarootdir}/gamerec.tgz"
 		rm -rf /data/recommender/game_hall/daily/feature_vector
 		rm -rf /data/recommender/game_hall/daily/model
 		write_log "tar -zxvf ${datarootdir}/gamerec.tgz -C ${datarootdir}"
  	tar -zxvf ${datarootdir}/gamerec.tgz -C ${datarootdir}
  	mv ${datarootdir}/gamerec.tgz ${databakdir}/gamerec.tgz_`date +%Y%m%d`
  	rm -rf ${databakdir}/gamerec.tgz_`date -d "-30 days" +%Y%m%d`
write_log "end uncompress...."

#第三步,定义文件->表列映射关系,并加载表;bash 版本必须 >= 4.1.2, ${!loadTCMap[@]}代表key  ${loadTCMap[@]}代表value
#declare -A TDiscriptor=(["game_user_feature_vector"]="用户特征向量" ["game_item_feature_vector"]="物品特征向量" ["game_user_item_feature_vector"]="用户对物品偏好度的特征向量 ")
declare -A loadTCMap=(["game_user_feature_vector"]="user_md5,vector" ["game_item_feature_vector"]="item_id,vector")
declare -A TFMap=(["game_user_feature_vector"]="p_fact_imei_vector" ["game_item_feature_vector"]="p_fact_item_vector")

write_log "start load....."

$mysqlcmd -N -e "delete from game_item_feature_vector;" 2>&1 >>${log_path}/gamerec.log

for table in ${!loadTCMap[@]}
do
		is_succeed=0
		retry=1
		write_log "loading $table........"
		write_log "$mysqlcmd -N -e \"LOAD DATA LOCAL INFILE '${datasubdir}/${TFMap[$table]}' replace into table $table(${loadTCMap[$table]})\""
		while [[ is_succeed -ne 1 && $retry -le 3 ]]; do
				$mysqlcmd -N -e "LOAD DATA LOCAL INFILE '${datasubdir}/${TFMap[$table]}' replace into table $table(${loadTCMap[$table]})" 2>&1 >>${log_path}/gamerec.log
				if [[ $? -ne 0 ]]; then
						write_log "the $retry times load $table fail...."
						echo "$table,`date +%Y%m%d%H%M`,fail" >>${log_path}/gamerec.end
						let retry++
						sleep 5
				else
						is_succeed=1
						write_log "$table load success...."
						echo "$table,`date +%Y%m%d%H%M`,ok"   >>${log_path}/gamerec.end
				fi
				if [[ $retry -eq 3 ]]; then
						send_mail "the 3 times loading $table failed,please quickly check..... "
				fi
		done
done

write_log "end load....."
#第四步、模型更新
write_log "update model....."
curl http://10.24.44.182:8081/model/game/daily/lr
if [[ $? -ne 0 ]]; then
	write_log "tuijian server01 update model error."
	send_mail "tuijian server01 update model error."
fi
curl http://10.24.44.186:8081/model/game/daily/lr
if [[ $? -ne 0 ]]; then
	write_log "tuijian server02 update model error."
	send_mail "tuijian server02 update model error."
fi
curl http://10.24.44.182:8081/feature/game/daily/item
if [[ $? -ne 0 ]]; then
	write_log "tuijian server01 update item feature error."
	send_mail "tuijian server01 update item feature error."
fi
curl http://10.24.44.186:8081/feature/game/daily/item
if [[ $? -ne 0 ]]; then
	write_log "tuijian server02 update item feature error."
	send_mail "tuijian server02 update item feature error."
fi
write_log "program end....."

chown -R gamerecdev:gamerecdev /data/recommender/game_hall/daily
chmod -R 777 /data/recommender/game_hall/daily
