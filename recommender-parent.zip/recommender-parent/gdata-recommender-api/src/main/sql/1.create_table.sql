-- 主题推荐-用户、物品、聚类、评分表
drop index idx_theme_kmeans_user_item_cluster_score_user_md5 on theme_kmeans_user_item_cluster_score;
drop table if exists theme_kmeans_user_item_cluster_score;
create table theme_kmeans_user_item_cluster_score
(
   user_md5             varchar(32) not null,
   user                 varchar(32) not null comment '用户',
   item                 varchar(32) not null comment '物品',
   cluster              int not null comment '聚类',
   score                double not null comment '评分'
);
alter table theme_kmeans_user_item_cluster_score comment '用户物品聚类评分表——主题';
create index idx_theme_kmeans_user_item_cluster_score_user_md5 on theme_kmeans_user_item_cluster_score(user_md5);

-- 主题推荐-物品、聚类、评分表
drop index idx_theme_kmeans_item_cluster_score_cluster on theme_kmeans_item_cluster_score;
drop index idx_theme_kmeans_item_cluster_score_item on theme_kmeans_item_cluster_score;
drop table if exists theme_kmeans_item_cluster_score;
create table theme_kmeans_item_cluster_score
(
   item                 varchar(32) not null comment '物品',
   cluster              int not null comment '聚类',
   score                double not null comment '评分'
);
alter table theme_kmeans_item_cluster_score comment '物品聚类评分表——主题';
create index idx_theme_kmeans_item_cluster_score_item on theme_kmeans_item_cluster_score(itemId);
create index idx_theme_kmeans_item_cluster_score_cluster on theme_kmeans_item_cluster_score(cluster);

-- 主题推荐-主题标签（合并机型）表
drop index idx_item_tag_value on theme_item_tag;
drop index idx_item_tag_name on theme_item_tag;
drop index idx_item_tag_item on theme_item_tag;
drop table if exists theme_item_tag;
create table theme_item_tag
(
   item                 varchar(32) not null,
   tag_name             varchar(32) not null,
   tag_value            varchar(32) not null
);
alter table theme_item_tag comment '物品标签表——主题';
create index idx_item_tag_item on theme_item_tag(itemId);
create index idx_item_tag_name on theme_item_tag(tag_name);
create index idx_item_tag_value on theme_item_tag(tag_value);

-- 主题推荐-运营策略表
DROP INDEX idx_theme_ope_item_meta ON theme_ope_item_meta;
DROP TABLE IF EXISTS theme_ope_item_meta;
CREATE TABLE theme_ope_item_meta
(
   item_id              VARCHAR(32) NOT NULL COMMENT '物品唯一标识，不可出现特殊字符',
   item_info            VARCHAR(1024) COMMENT '业务方需要的物品其他信息',
   snc_id               VARCHAR(32) NOT NULL COMMENT '场景ID',
   ope_id               VARCHAR(32) NOT NULL COMMENT '运营策略ID，针对 具体的运营策略，强制推荐这个运营策略ID下的物品',
   rule_key             VARCHAR(32) NOT NULL DEFAULT '' COMMENT '运营策略规则key',
   rule_value           VARCHAR(32) NOT NULL DEFAULT '' COMMENT '运营策略规则value',
   effective_time       TIMESTAMP NULL COMMENT '生效时间，秒级时间戳格式',
   effective_flag       BOOLEAN NOT NULL COMMENT '有效标识',
   create_time          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
   PRIMARY KEY (item_id, snc_id, ope_id, rule_key, rule_value, effective_flag, create_time)
);
ALTER TABLE theme_ope_item_meta COMMENT '运营规则类物品表';
CREATE INDEX idx_theme_ope_item_meta ON theme_ope_item_meta(snc_id, ope_id, effective_flag);

-- 游戏大厅-用户特征向量表
drop table if exists game_user_feature_vector;
create table game_user_feature_vector
(
   user_md5             varchar(32) not null comment '用户MD5',
   vector               text comment '向量，以英文逗号作为分隔',
   create_time          timestamp default CURRENT_TIMESTAMP comment '记录创建时间',
   primary key (user_md5)
);
alter table game_user_feature_vector comment '用户特征向量表';

-- 游戏大厅-物品特征向量表
drop table if exists game_item_feature_vector;
create table game_item_feature_vector
(
   item_id              varchar(32) not null comment '物品ID',
   vector               text comment '向量，以英文逗号作为分隔',
   create_time          timestamp comment '创建时间',
   primary key (item_id)
);
alter table game_item_feature_vector comment '物品特征向量表';

-- 游戏大厅-用户对物品偏好特征向量表
drop table if exists game_user_item_feature_vector;
create table game_user_item_feature_vector
(
   user_md5             varchar(32) not null comment '用户MD5',
   item_id              varchar(32) not null comment '物品ID',
   vector               text comment '向量，以英文逗号作为分隔',
   create_time          timestamp comment '创建时间',
   primary key (user_md5, item_id)
);
alter table game_user_item_feature_vector comment '用户物品偏好度向量表';

-- 游戏大厅-变量特征向量表
drop table if exists game_variable_feature_vector;
create table game_variable_feature_vector
(
   feature_code         varchar(32) not null comment '特征名称编码',
   feature_name         varchar(32) comment '特征名',
   feature_value        varchar(32) not null comment '特征值',
   vector               text comment '向量，以英文逗号作为分隔',
   effective_flag       int comment '有效标识，0表示无效，1表示有效',
   create_time          timestamp comment '创建时间',
   primary key (feature_code, feature_value)
);
alter table game_variable_feature_vector comment '参数向量表';

-- 游戏大厅-用户二级标签表
drop table if exists game_user_second_tag_score;
create table game_user_second_tag_score
(
   user_md5             varchar(32) not null comment '用户唯一标识MD5',
   user                 varchar(32) comment '用户唯一标识',
   second_tag_id        varchar(32) comment '二级标签ID',
   score                double comment '评分',
   create_time          timestamp comment '创建时间',
   primary key (user_md5)
);
alter table game_user_second_tag_score comment '用户二级标签偏好表';

-- 游戏大厅-物品与一级标签相关度表
drop table if exists game_first_tag_correl_degree;
create table game_first_tag_correl_degree
(
   item                 varchar(32) not null comment '物品唯一标识',
   first_tag_id         varchar(32) not null comment '一级标签',
   correl_degree        double comment '相关度',
   create_time          timestamp comment '创建时间',
   primary key (item, first_tag_id)
);
alter table game_first_tag_correl_degree comment '物品与一级标签相关度';

-- 游戏大厅-物品与一级标签相关度表
drop table if exists game_second_tag_correl_degree;
create table game_second_tag_correl_degree
(
   item                 varchar(32) not null comment '物品唯一标识',
   second_tag_id        varchar(32) not null comment '二级标签',
   correl_degree        double comment '相关度',
   create_time          timestamp comment '创建时间',
   primary key (item, second_tag_id)
);
alter table game_second_tag_correl_degree comment '物品与二级标签相关度';

