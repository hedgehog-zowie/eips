-- 创建HIVE表
CREATE TABLE rec_api_theme_log(
  action string,
  time string,
  imei string,
  apps string,
  limit int,
  result string
) partitioned by(day_id int)
