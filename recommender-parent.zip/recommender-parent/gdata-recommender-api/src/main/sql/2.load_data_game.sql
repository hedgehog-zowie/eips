-- 导入用户特征向量
LOAD DATA LOCAL INFILE "/data/recommender/game_hall/daily/feature_vector/p_fact_imei_vector"
REPLACE INTO TABLE game_user_feature_vector(user_md5, vector);

-- 导入物品特征向量
LOAD DATA LOCAL INFILE "/data/recommender/game_hall/daily/feature_vector/p_fact_item_vector"
REPLACE INTO TABLE game_item_feature_vector(item_id, vector);

-- 导入用户对物品偏好度的特征向量
LOAD DATA LOCAL INFILE "/data/recommender/game_hall/daily/feature_vector/p_fact_imei_item_vector"
REPLACE INTO TABLE game_user_item_feature_vector(user_md5, item_id, vector);
