package com.gionee.gdata.recommender.service;

import com.gionee.gdata.recommender.Application;
import com.gionee.gdata.recommender.service.gamehall.GameFeatureService;
import org.apache.spark.mllib.linalg.Vector;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Calendar;
import java.util.Map;

/**
 * <code>GameFeatureServiceCacheTest</code>.
 * ${DESCRIPTION}
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2018/1/11 10:36
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = Application.class)
public class GameFeatureServiceCacheTest {

    @Autowired
    private GameFeatureService gameFeatureService;

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testGenerateUserItemVariableVector() {
        for (int i = 0; i < 3; i++) {
            String userMd5 = "0000a1abf4784e76d9bce237ad1363c3";
            String net = "wf";
            Calendar calendar = Calendar.getInstance();
            String dayOfWeek = String.valueOf(calendar.get(Calendar.DAY_OF_WEEK));
            String hourOfDay = String.valueOf(calendar.get(Calendar.HOUR_OF_DAY));
            Map<String, Vector> vectorMap = gameFeatureService.generateVector(userMd5, net, dayOfWeek, hourOfDay);
            for (Map.Entry<String, Vector> entry : vectorMap.entrySet()) {
                System.out.println(entry.getKey() + ":" + entry.getValue());
            }
        }
    }

}
