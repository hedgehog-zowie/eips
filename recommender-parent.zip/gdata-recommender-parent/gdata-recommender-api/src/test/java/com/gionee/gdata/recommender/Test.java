package com.gionee.gdata.recommender;

import com.gionee.gdata.common.utils.HashUtil;
import com.gionee.gdata.common.utils.RandomUtil;
import com.gionee.gdata.common.utils.StringUtil;
import com.google.common.collect.Lists;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.databene.contiperf.PerfTest;
import org.databene.contiperf.Required;
import org.databene.contiperf.junit.ContiPerfRule;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Random;
import java.util.Set;

import static org.junit.Assert.assertEquals;

/**
 * Created by Zweig on 2017/1/4.
 * Email: hedgehog.zowie@gmail.com
 */
public class Test {

    private static final String testUrl = "https://vipc.cn/article/5934bcdaa57216001a43dc02?fr=p0046";
    private static final String downloadManagerUrl = "http://yjapi.gionee.com/recommender-api/downloadmanager/result?imei=d960592019cc238edb73093193ece241&apps=com.ssp_sdk.dem,com.gsp.gionee,com.gsp.pay";
    private static final String themeUrl = "http://16.6.10.132:9999/recommender-api/theme/result?imei=00000221a214e923cdbbc087a054fefb";
    private static final Logger logger = LoggerFactory.getLogger(Test.class);

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Rule
    public ContiPerfRule i = new ContiPerfRule();

    @org.junit.Test
    public void checkSetInteger() {
        for (int i = 0; i < 10000; i++) {
            Set<Integer> sets = RandomUtil.getSortedLimitRandom(0, 100, 100);
            int x = 0;
            for (Integer integer : sets) {
                assertEquals(integer.intValue(), x++);
            }
        }
    }

    @org.junit.Test
    @PerfTest(invocations = 100000, threads = 10, duration = 10000)
//    @Required(throughput = 3000)
    public void checkContiperf() {
        System.out.println("checkContiperf");
    }

    @org.junit.Test
    public void checkSignature() throws UnsupportedEncodingException, NoSuchAlgorithmException {
//        String imei = HashUtil.md5Encode("008600210138037");
//        System.out.println("md5(imei)=" + imei);
//
        String downloadmanagerAppKey = "729f3656f6d876438f3f35bcdebb1e43";
        System.out.println("downloadmanager_signature=" + HashUtil.md5Encode(downloadmanagerAppKey + StringUtil.getSortedString("7751a8c522946d33d69154e7d5d3175a", "10")));
//
//        String apps = "com.hexin.plat.android,com.android.music";
//        System.out.println("downloadmanager_md5_2=" + HashUtil.md5Encode(downloadmanagerAppKey + StringUtil.getSortedString(imei, apps)));
//
//        String limit = "10";
//        System.out.println("downloadmanager_md5_3=" + HashUtil.md5Encode(downloadmanagerAppKey + StringUtil.getSortedString(imei, apps, limit)));

        String advertisementAppKey = "advertisementAppKey";
        String apps = "com.ssp_sdk.dem,com.gsp.gionee,com.gsp.pay";
        System.out.println("advertisement_signature=" + HashUtil.md5Encode(advertisementAppKey + StringUtil.getSortedString("3aa4860b46cd801b7c844c246c713f2c", apps)));

//        String advertisementAppKey = "4ef725e682632670d9bf842b87d0b624";
//        String apps = "a,b,c,d,e";
//        System.out.println("advertisement_signature=" + HashUtil.md5Encode(advertisementAppKey + StringUtil.getSortedString("3aa4860b46cd801b7c844c246c713f2c", apps)));

//        String themeAppKey = "themeAppKey";
//        System.out.println("theme_signature=" + HashUtil.md5Encode(themeAppKey + StringUtil.getSortedString("00000221a214e923cdbbc087a054fefb")));
    }

    @org.junit.Test
    public void generateDownloadMangerSignature() throws UnsupportedEncodingException, NoSuchAlgorithmException {
        String imei = HashUtil.md5Encode("008600211321988");
        String downloadmanagerAppKey = "729f3656f6d876438f3f35bcdebb1e43";
        String apps = "asdf1234,asdf111,asdf222,asdf333";

        System.out.println("md5(imei)=" + imei);
        System.out.println("signature=" + HashUtil.md5Encode(downloadmanagerAppKey + StringUtil.getSortedString("1e4a1b03d1b6cd8a174a826f76e009f4", "com.lingan.seeyou,com.pokercity.lobby,com.boyaa.chinesechess.platform91,com.lingan.seeyou,com.UCMobile", "3")));
        System.out.println("signature=" + HashUtil.md5Encode(downloadmanagerAppKey + StringUtil.getSortedString("d960592019cc238edb73093193ece241", "com.ssp_sdk.dem,com.gsp.gionee,com.gsp.pay", "")));
    }

    @org.junit.Test
    public void generateDownloadManagerSignatureBatch() throws UnsupportedEncodingException, NoSuchAlgorithmException {
        String downloadmanagerAppKey = "729f3656f6d876438f3f35bcdebb1e43";
        String[] imeiArray = {
                "0000000000000000",
                "000860021022097",
                "000860021090019",
                "000860021090111",
                "000860021644626",
                "008600206611195",
                "008600210000856",
                "008600210000866",
                "008600210002126",
                "008600210002159",
        };
        String[] appArray = {
                "com.lingan.seeyou", // 94
                "com.boyaa.chinesechess.platform91", // 1
                "com.immomo.momo", // 98
                "com.mojang.minecraftype.gl.am", // 37
                "com.smile.gifmaker", // 11
                "com.cootek.smartdialer", // 91
                "com.UCMobile", // 28
                "com.hexin.plat.android", // 81
                "com.pokercity.lobby", // 34
                "com.bet007.mobile.score", // 82
        };
        String[] limitArray = {
                "3",
                "6",
                "9",
                "12",
                "15",
                "18",
                "21",
                "24",
                "27",
                "30",
        };
        Random random = new Random();
        System.out.println("imei|apps|limit|md5(imei)|signature");
        for (String imei : imeiArray) {
            for (int i = 0; i < 10; i++) {
                int appNum = random.nextInt(10) + 1;
                StringBuilder appsBuilder = new StringBuilder();
                // 拼apps
                for (int j = 0; j < appNum; j++) {
                    int index = random.nextInt(10);
                    appsBuilder.append(appArray[index]);
                    if (j != (appNum - 1))
                        appsBuilder.append(",");
                }
                String apps = appsBuilder.toString();
                for (String limit : limitArray) {
                    String imeiMd5 = HashUtil.md5Encode(imei);
                    String signature = HashUtil.md5Encode(downloadmanagerAppKey + StringUtil.getSortedString(imeiMd5, apps, limit));
                    System.out.println(imei + "|" + apps + "|" + limit + "|" + imeiMd5 + "|" + signature);
                }
            }
        }
    }

    @org.junit.Test
    @PerfTest(invocations = 100000, threads = 10, duration = 60000)
//    @Required(throughput = 3000)
    public void testDownloadManagerApiPerformance() {
        try {
            HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
            HttpClient httpClient = httpClientBuilder.build();
            //发送get请求
            HttpGet request = new HttpGet(downloadManagerUrl);
            request.setHeader("appId", "downloadmanagerAppId");
            request.setHeader("signature", "b9dfe26d7d8233cefb8f4b50317e08cc");
            HttpResponse response = httpClient.execute(request);

            /**请求发送成功，并得到响应**/
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                /**读取服务器返回过来的json字符串数据**/
                String strResult = EntityUtils.toString(response.getEntity());
//                System.out.println(strResult);
            } else {
                logger.error("get请求提交失败:" + downloadManagerUrl);
            }
        } catch (IOException e) {
            logger.error("get请求提交失败:" + downloadManagerUrl, e);
        }
    }

    @org.junit.Test
    public void testThemeApi() {
        try {
            HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
            HttpClient httpClient = httpClientBuilder.build();
            //发送get请求
            HttpGet request = new HttpGet(testUrl);
//            request.setHeader("appId", "themeAppId");
//            request.setHeader("signature", "4e239eaf41414eab2ce7f3a4d0b63b43");
            HttpResponse response = httpClient.execute(request);

            /**请求发送成功，并得到响应**/
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                /**读取服务器返回过来的json字符串数据**/
                String strResult = EntityUtils.toString(response.getEntity());
                System.out.println(strResult);
            } else {
                logger.error("get请求提交失败:" + themeUrl);
            }
        } catch (IOException e) {
            logger.error("get请求提交失败:" + themeUrl, e);
        }
    }

    @org.junit.Test
    public void testList() {
        List<String> tList = Lists.newArrayList();
        tList.add("123");
        tList.add("456");
        tList.add("789");
        int i = 0;
        while (i < 3) {
            System.out.println(tList.get(0));
//            tList.remove(s);
            tList.remove(0);

            i++;
        }
    }

    @org.junit.Test
    public void testLog() {
        Exception e = new RuntimeException("test new runtime exception");
        logger.info("error, a = {}", 1, "asdf");
        logger.info("error, a = {}", 2, e);
    }

    @org.junit.Test
    public void testTail() {
        String[] imeiMd5s = {
                "af3a46ccc6bbe6c73f1ed1c89b5c7870",
                "af3a46ccc6bbe6c73f1ed1c89b5c7871",
                "af3a46ccc6bbe6c73f1ed1c89b5c7872",
                "af3a46ccc6bbe6c73f1ed1c89b5c7873",
                "af3a46ccc6bbe6c73f1ed1c89b5c7874",
                "af3a46ccc6bbe6c73f1ed1c89b5c7875",
                "af3a46ccc6bbe6c73f1ed1c89b5c7876",
                "af3a46ccc6bbe6c73f1ed1c89b5c7877",
                "af3a46ccc6bbe6c73f1ed1c89b5c7878",
                "af3a46ccc6bbe6c73f1ed1c89b5c7879",
                "af3a46ccc6bbe6c73f1ed1c89b5c787a",
                "af3a46ccc6bbe6c73f1ed1c89b5c787b",
                "af3a46ccc6bbe6c73f1ed1c89b5c787c",
                "af3a46ccc6bbe6c73f1ed1c89b5c787d",
                "af3a46ccc6bbe6c73f1ed1c89b5c787e",
                "af3a46ccc6bbe6c73f1ed1c89b5c787f"
        };
        for (String imeiMd5 : imeiMd5s) {
            if (StringUtil.endWithEven(imeiMd5))
                logger.info("imeiMd5 = {}, rec", imeiMd5);
            else
                logger.info("imeiMd5 = {}, no rec", imeiMd5);
        }
    }

}
