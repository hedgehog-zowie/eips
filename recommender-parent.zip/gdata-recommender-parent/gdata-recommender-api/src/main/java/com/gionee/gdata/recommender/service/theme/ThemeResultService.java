package com.gionee.gdata.recommender.service.theme;

import com.gionee.gdata.common.utils.RandomUtil;
import com.gionee.gdata.recommender.model.RecommendItem;
import com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

/**
 * <code>ThemeResultService</code>.
 * 结果处理服务
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/8/28 14:31
 */
@Service
public class ThemeResultService {

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ThemeResultService.class);

    /**
     * 随机获取size个结果
     *
     * @param allResultList 全部结果集
     * @param size          需要的结果个数
     * @return 需要的结果列表
     */
    public List<RecommendItem> getRandomResult(final List<RecommendItem> allResultList, final Integer size) {
        List<RecommendItem> resultList = Lists.newArrayList();
        // 若所有主题个数大于需要的结果大小
        if (allResultList.size() > size) {
            Set<Integer> set = RandomUtil.getSortedLimitRandom(0, allResultList.size(), size);
            for (Integer idx : set) {
                RecommendItem result = allResultList.get(idx);
                resultList.add(result);
            }
        } else {
            resultList = allResultList;
        }
        return resultList;
    }

}
