package com.gionee.gdata.recommender.service.downloadmanager;

import com.gionee.gdata.data.mybatis.entity.recommender.downloadmanager.DownloadManagerAppSimilarResult;
import com.gionee.gdata.data.mybatis.mapper.recommender.downloadmanager.DownloadManagerAppSimilarResultMapper;
import com.google.common.collect.Sets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.Set;

/**
 * <code>SimilarService</code>.
 * ${DESCRIPTION}
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2018/3/9 14:19
 */
@Service
public class SimilarService {

    @Autowired
    private DownloadManagerAppSimilarResultMapper downloadManagerAppSimilarResultMapper;

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(SimilarService.class);

    /**
     * 获取相似的应用
     *
     * @param app
     * @return
     */
    @Cacheable(value = "similarAppsCache", key = "#app")
    public Set<String> getSimilarApps(String app) {
        DownloadManagerAppSimilarResult downloadManagerAppSimilarResult = downloadManagerAppSimilarResultMapper.findDownloadManagerAppSimilarResultByApp(app);
        Set<String> similarAppSet = Sets.newLinkedHashSet();
        if (downloadManagerAppSimilarResult != null) {
            similarAppSet = downloadManagerAppSimilarResult.getSimilarAppSet();
        }
        return similarAppSet;
    }

}
