package com.gionee.gdata.recommender.service.gamehall;

import com.gionee.gdata.data.mybatis.entity.recommender.gamehall.GameSecondTagCorrelDegree;
import com.gionee.gdata.data.mybatis.mapper.recommender.gamehall.GameSecondTagCorrelDegreeMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 *
 * @author yuwei
 * @version: 1.0-SNAPSHOT
 * date: 2017-10-12 16:55:17
 */
@Service
public class GameHallSecondTagCorrelService {
    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(GameHallSecondTagCorrelService.class);

    /**
     * 二级相关度
     */
    @Autowired
    private GameSecondTagCorrelDegreeMapper gameSecondTagCorrelDegreeMapper;

    /**
     * 获取推荐结果
     * @param secondTagId
     * @return
     */
    public List<GameSecondTagCorrelDegree> getRecommendResult(String secondTagId) {
        // 获取二级相关度
        List<GameSecondTagCorrelDegree> secondTagCorrelDegreeList = gameSecondTagCorrelDegreeMapper.findGameSecondTagCorrelDegree(secondTagId);
        return secondTagCorrelDegreeList;
    }
}
