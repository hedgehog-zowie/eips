package com.gionee.gdata.recommender.service.theme;

import com.gionee.gdata.common.utils.StringUtil;
import com.gionee.gdata.data.mybatis.entity.recommender.theme.ThemeItemSimilar;
import com.gionee.gdata.data.mybatis.mapper.recommender.theme.ThemeItemSimilarMapper;
import com.gionee.gdata.data.mybatis.model.recommender.theme.ThemeItemSimilarQuery;
import com.gionee.gdata.recommender.common.ABID;
import com.gionee.gdata.recommender.common.Operation;
import com.gionee.gdata.recommender.model.RecommendItem;
import com.gionee.gdata.recommender.model.theme.EditorRate;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author yuwei
 * @version 1.0-SNAPSHOT
 * @description
 * @date
 */
@Service
public class ThemeEditorService {

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ThemeOperationService.class);

    /**
     * 相似主题mapper
     */
    @Autowired
    private ThemeItemSimilarMapper themeItemSimilarMapper;

    /**
     * 获取相似主题，用于小编推荐
     * @param imeiMd5
     * @param modelType
     * @return
     */
    public Map<String, List<RecommendItem>> getEditorRecommendResult(String imeiMd5, String modelType){
        // 获取imeiMd5 最后一位数的余数
        Integer residue = StringUtil.endResidue(imeiMd5, 3);
        Double firstRate = 0.5;
        Double secondRate = 0.5;
        // 根据最后一位数余数赋予比例
        if (residue == 1) {
            firstRate  = EditorRate.similarRate1;
            secondRate = EditorRate.similarRate2;
        } else if (residue == 2) {
            firstRate  = EditorRate.similarRate3;
            secondRate = EditorRate.similarRate4;
        }
        ThemeItemSimilarQuery query = new ThemeItemSimilarQuery(imeiMd5, modelType, firstRate, secondRate);
        List<ThemeItemSimilar> itemSimilarList = themeItemSimilarMapper.findAllSimilarItem(query);
        // 根据系列保存的结果集
        Map<String, List<RecommendItem>> seriesMap = Maps.newHashMap();
        for (ThemeItemSimilar itemSimilar : itemSimilarList) {
            String series = itemSimilar.getSeries();
            List<RecommendItem> recommendItems = seriesMap.get(series);
            if (recommendItems == null) {
                recommendItems = Lists.newArrayList();
            }
            String item = itemSimilar.getSimilarItemId();
            String abid = ABID.REC_THEME_SIMILAR.toString() + "_" + firstRate + "_" + secondRate;
            Operation opeId = null;
            recommendItems.add(new RecommendItem(item, opeId, abid));
            seriesMap.put(series, recommendItems);
        }
        return seriesMap;
    }

    public void updateRate(){
        LOGGER.info("开始更新小编推荐比例");
        EditorRate.similarRate1 = EditorRate.similarRate1Temp;
        EditorRate.similarRate2 = EditorRate.similarRate2Temp;
        EditorRate.similarRate3 = EditorRate.similarRate3Temp;
        EditorRate.similarRate4 = EditorRate.similarRate4Temp;
        LOGGER.info("更新小编推荐比例结束");
    }
}
