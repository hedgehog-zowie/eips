package com.gionee.gdata.recommender.common;

/**
 * <code>OperationStrategy</code>.
 * 主题运营策略
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/8/22 11:13
 */
public enum ThemeOperation {

    /**
     * 主题推荐运营策略——强制新品
     */
    theme_new_force,
    /**
     * 主题推荐运营策略——随机新品
     */
    theme_new_random,
    /**
     * 主题推荐运营策略——紧急上架
     */
    theme_new_urgent,
    /**
     * 主题推荐运营策略——按热度推荐，未取得推荐结果及推荐结果个数不足时使用
     */
    theme_hot,

}
