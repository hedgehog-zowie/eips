package com.gionee.gdata.recommender.api;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <code>IndexController</code>.
 * 主页
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:25
 */
@RestController
@RequestMapping("/")
public class IndexController {

    /**
     * 主页，方便查看部署是否成功，也可在此添加使用文档之类.
     *
     * @return 略
     */
    @RequestMapping("/")
    public String index() {
        return "welcome recommender-api!";
    }

}
