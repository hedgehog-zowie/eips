package com.gionee.gdata.recommender.model.gamehall;

import com.gionee.gdata.recommender.model.RecommendResult;

import java.util.List;

/**
 * 游戏大厅游戏桌面推荐结果
 *
 * @author yuwei
 * @version: 1.0-SNAPSHOT
 * date: 2017-10-13 08:47:23
 */
public class GameDesktopRecommendResult extends RecommendResult {
    /**
     * 略
     */
    private String imei;
    /**
     * 推荐结果
     */
    private List<GameDesktopRecommendItem> resultList;

    public GameDesktopRecommendResult() {
        super.ok();
    }

    public GameDesktopRecommendResult(String imei, List<GameDesktopRecommendItem> resultList) {
        this.imei = imei;
        this.resultList = resultList;
        super.ok();
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public List<GameDesktopRecommendItem> getResultList() {
        return resultList;
    }

    public void setResultList(List<GameDesktopRecommendItem> resultList) {
        this.resultList = resultList;
    }
}
