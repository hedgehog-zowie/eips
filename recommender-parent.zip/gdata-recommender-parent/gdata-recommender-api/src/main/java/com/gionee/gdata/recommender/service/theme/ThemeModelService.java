package com.gionee.gdata.recommender.service.theme;

import com.gionee.gdata.data.mybatis.entity.recommender.theme.ItemTag;
import com.gionee.gdata.data.mybatis.mapper.recommender.theme.ItemTagMapper;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * <code>ThemeTagService</code>.
 * 主题机型服务类
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/13 14:02
 */
@Service
public class ThemeModelService {

    /**
     * 日志记录器.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ThemeModelService.class);

    /**
     * 锁
     */
    private ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    /**
     * 机型主题缓存，model作为key，Set<Item>作为value
     */
    private Map<String, Set<String>> modelCache = Maps.newHashMap();

    /**
     * 主题标签mapper
     */
    @Autowired
    private ItemTagMapper itemTagMapper;

    /**
     * 缓存机型主题
     */
    public void cacheModel() {
        LOGGER.info("更新主题机型缓存开始");
        List<ItemTag> itemTagList = itemTagMapper.findAllItemModelTag();
        if (itemTagList == null || itemTagList.size() == 0) {
            LOGGER.error("get theme model from table error.");
            return;
        }
        lock.writeLock().lock();
        try {
            modelCache.clear();
            for (ItemTag itemTag : itemTagList) {
                String model = itemTag.getTagValue();
                Set<String> itemSet = modelCache.get(model);
                if (itemSet == null) {
                    itemSet = Sets.newHashSet();
                }
                itemSet.add(itemTag.getItem());
                modelCache.put(model, itemSet);
            }
        } finally {
            lock.writeLock().unlock();
        }
        LOGGER.info("更新主题机型缓存完成");
    }

    /**
     * 根据机型获取主题
     *
     * @param model 机型编号
     * @return 返回主题集合
     */
    public Set<String> getItemByModel(final String model) {
        lock.readLock().lock();
        try {
            return modelCache.get(model);
        } finally {
            lock.readLock().unlock();
        }
    }

}
