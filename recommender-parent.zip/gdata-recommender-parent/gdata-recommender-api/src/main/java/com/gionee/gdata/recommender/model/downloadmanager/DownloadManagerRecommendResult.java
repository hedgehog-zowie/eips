package com.gionee.gdata.recommender.model.downloadmanager;

import com.gionee.gdata.recommender.model.RecommendItem;
import com.gionee.gdata.recommender.model.RecommendResult;
import com.google.common.collect.Lists;

import java.util.List;
import java.util.Set;

/**
 * <code>ThemeResult</code>.
 * 下载管理推荐结果
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/13 15:28
 */
public class DownloadManagerRecommendResult extends RecommendResult {

    /**
     * 略
     */
    private String imei;
    /**
     * 推荐结果
     */
    private List<RecommendItem> resultList;

    /**
     * 略
     */
    public DownloadManagerRecommendResult() {

    }

    /**
     * 略
     *
     * @param imei      略
     * @param resultSet 略
     */
    public DownloadManagerRecommendResult(final String imei, final Set<RecommendItem> resultSet) {
        this.imei = imei;
        this.resultList = Lists.newArrayList(resultSet);
        super.ok();
    }

    public String getImei() {
        return imei;
    }

    public void setImei(final String imei) {
        this.imei = imei;
    }

    public List<RecommendItem> getResultList() {
        return resultList;
    }

    public void setResultList(final List<RecommendItem> resultList) {
        this.resultList = resultList;
    }

}
