package com.gionee.gdata.recommender.api;

import com.gionee.gdata.recommender.model.Response;
import com.gionee.gdata.recommender.service.gamehall.GameFeatureService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <code>ModelController</code>.
 * 模型更新控制层
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/7 10:11
 */
@RestController
@RequestMapping("/feature")
public class FeatureController {

    /**
     * 日志记录器.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(FeatureController.class);

    /**
     * 游戏特征服务
     */
    @Autowired
    private GameFeatureService gameFeatureService;

    /**
     * 更新游戏大厅-每日一荐物品特征更新
     *
     * @return
     */
    @RequestMapping(value = "/game/daily/item")
    public Response updateGameDailyLrModel() {
        Response response = new Response();
        gameFeatureService.cacheFeatureVector();
        response.ok();
        return response;
    }

}
