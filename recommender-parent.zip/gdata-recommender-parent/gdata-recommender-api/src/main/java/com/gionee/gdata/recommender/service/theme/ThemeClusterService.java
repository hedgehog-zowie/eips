package com.gionee.gdata.recommender.service.theme;

import com.gionee.gdata.data.mybatis.entity.recommender.theme.ItemClusterScore;
import com.gionee.gdata.data.mybatis.mapper.recommender.theme.ItemClusterScoreMapper;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * <code>ThemeClusterService</code>.
 * 主题聚类服务类
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/14 10:47
 */
@Service
public class ThemeClusterService {

    /**
     * 日志记录器.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ThemeModelService.class);

    /**
     * 锁
     */
    private ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    /**
     * 机型主题缓存，cluster作为key，Set<ItemClusterScore>作为value
     */
    private Map<Integer, Set<ItemClusterScore>> clusterCache = Maps.newHashMap();

    /**
     * 主题聚类mapper
     */
    @Autowired
    private ItemClusterScoreMapper itemClusterScoreMapper;

    /**
     * 缓存主题聚类
     */
    public void cacheItemClusterScore() {
        LOGGER.info("更新主题聚类缓存开始");
        List<ItemClusterScore> itemClusterScoreList = itemClusterScoreMapper.findAllItemClusterScore();
        if (itemClusterScoreList == null || itemClusterScoreList.size() == 0) {
            LOGGER.error("get item-cluster-score from table error.");
            return;
        }
        lock.writeLock().lock();
        try {
            clusterCache.clear();
            for (ItemClusterScore itemClusterScore : itemClusterScoreList) {
                Integer cluster = itemClusterScore.getCluster();
                Set<ItemClusterScore> itemSet = clusterCache.get(cluster);
                if (itemSet == null) {
                    itemSet = Sets.newHashSet();
                }
                itemSet.add(itemClusterScore);
                clusterCache.put(cluster, itemSet);
            }
        } finally {
            lock.writeLock().unlock();
        }
        LOGGER.info("更新主题聚类缓存完成");
    }

    /**
     * 根据聚类获取主题
     *
     * @param cluster 聚类
     * @return 主题集合
     */
    public Set<ItemClusterScore> getItemByCluster(final Integer cluster) {
        lock.readLock().lock();
        try {
            return clusterCache.get(cluster);
        } finally {
            lock.readLock().unlock();
        }
    }

    /**
     * 根据聚类获取主题
     *
     * @param clusterSet 聚类集合
     * @return 主题集合
     */
    public Set<ItemClusterScore> getItemByCluster(final Set<Integer> clusterSet) {
        lock.readLock().lock();
        try {
            Set<ItemClusterScore> set = Sets.newHashSet();
            for (Integer cluster : clusterSet) {
                set.addAll(clusterCache.get(cluster));
            }
            return set;
        } finally {
            lock.readLock().unlock();
        }
    }

}
