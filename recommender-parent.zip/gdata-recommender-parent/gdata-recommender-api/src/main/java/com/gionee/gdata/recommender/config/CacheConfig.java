package com.gionee.gdata.recommender.config;

import com.gionee.gdata.recommender.service.gamehall.GameFeatureService;
import com.gionee.gdata.recommender.service.LRModelService;
import com.gionee.gdata.recommender.service.theme.ThemeClusterService;
import com.gionee.gdata.recommender.service.theme.ThemeEditorService;
import com.gionee.gdata.recommender.service.theme.ThemeModelService;
import com.gionee.gdata.recommender.service.theme.ThemeRuleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

/**
 * <code>CacheConfig</code>.
 * 缓存配置
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/14 14:53
 */
@Component
public class CacheConfig implements ApplicationListener<ContextRefreshedEvent> {

    /**
     * 主题机型服务类
     */
    @Autowired
    private ThemeModelService themeModelService;
    /**
     * 主题干预规则服务类
     */
    @Autowired
    private ThemeRuleService themeRuleService;
    /**
     * 主题聚类服务类
     */
    @Autowired
    private ThemeClusterService themeClusterService;
    /**
     * 游戏大厅推荐特征服务类
     */
    @Autowired
    private GameFeatureService gameFeatureService;
    /**
     * LR模型服务类
     */
    @Autowired
    private LRModelService lrModelService;

    /**
     * 小编推荐服务类
     */
    @Autowired
    private ThemeEditorService themeEditorService;

    /**
     * 应用程序启动时，增加一些处理
     *
     * @param contextRefreshedEvent 上下文
     */
    @Override
    public void onApplicationEvent(final ContextRefreshedEvent contextRefreshedEvent) {
        themeModelService.cacheModel();
        themeRuleService.cacheRuleTag();
        themeClusterService.cacheItemClusterScore();
        gameFeatureService.cacheFeatureVector();
        lrModelService.updateLRModelOfGameDaily();
        themeEditorService.updateRate();
    }

}
