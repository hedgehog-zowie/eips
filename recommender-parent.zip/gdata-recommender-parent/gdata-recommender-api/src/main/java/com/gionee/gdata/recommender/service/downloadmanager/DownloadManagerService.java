package com.gionee.gdata.recommender.service.downloadmanager;

import com.gionee.gdata.common.utils.StringUtil;
import com.gionee.gdata.data.mybatis.entity.recommender.downloadmanager.DownloadManagerImeiAppList;
import com.gionee.gdata.data.mybatis.mapper.recommender.downloadmanager.DownloadManagerImeiAppListMapper;
import com.gionee.gdata.recommender.common.ABID;
import com.gionee.gdata.recommender.model.RecommendItem;
import com.gionee.gdata.recommender.model.downloadmanager.DownloadManagerRecommendResult;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

/**
 * <code>DownloadManagerService</code>.
 * ${DESCRIPTION}
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2018/1/3 16:11
 */
@Service
public class DownloadManagerService {
    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DownloadManagerService.class);

    /**
     * 参数包名间的分隔符
     */
    private static final String SPLITTER = ",";

    @Autowired
    private SimilarService similarService;
    @Autowired
    private DownloadManagerImeiAppListMapper downloadManagerImeiAppListMapper;

    /**
     * 获取推荐结果
     *
     * @param imei
     * @param apps
     * @param limit
     * @return
     */
    public DownloadManagerRecommendResult getRecommendResult(String imei, String apps, Integer limit) {
        DownloadManagerImeiAppList downloadManagerImeiAppList =
                downloadManagerImeiAppListMapper.findDownloadManagerImeiAppListByImei(imei);
        // 用户已安装应用列表
        Set<String> installedAppSet = Sets.newHashSet();
        if (downloadManagerImeiAppList != null) {
            installedAppSet.addAll(downloadManagerImeiAppList.getInstalledAppList());
        }
        // 将参数apps转成Set
        Set<String> appSet = StringUtil.delimitedStrToSet(apps, SPLITTER);
        // 各app的相似物品列表（app的相似物品列表的列表）
        List<List<String>> similarResultList = Lists.newArrayList();
        // 全部相似物品的数量
        Set<String> allSimilarAppSet = Sets.newHashSet();
        for (String app : appSet) {
            Set<String> similarAppSet = similarService.getSimilarApps(app);
            allSimilarAppSet.addAll(similarAppSet);
            similarResultList.add(Lists.newLinkedList(similarAppSet));
        }
        // 循环次数
        int loopIndex = 0;
        // app的相似物品列表的列表索引
        int listIndex = 0;
        // app的相似物品列表索引
        int appIndex = 0;
        // 结果集
        Set<RecommendItem> resultSet = Sets.newLinkedHashSet();
        while (resultSet.size() < limit && loopIndex < allSimilarAppSet.size()) {
            List<String> list = similarResultList.get(listIndex);
            String app = list.get(appIndex);
            // app不为空，且用户未安装过该应用，则添加到推荐结果
            if (app != null && !installedAppSet.contains(app)) {
                resultSet.add(new RecommendItem(app, null, ABID.REC_DOWN_SIMILAR_ITEM.name()));
            }
            listIndex++;
            // listIndex等于similarResultList的大小时，appIndex需要加1，listIndex置为0
            if (listIndex == similarResultList.size()) {
                listIndex = 0;
                appIndex++;
            }
            loopIndex++;
        }

        return new DownloadManagerRecommendResult(imei, resultSet);
    }

}


