package com.gionee.gdata.recommender.model.gamehall;

import com.gionee.gdata.recommender.model.RecommendResult;

import java.util.List;

/**
 * <code>GameDailyRecommendResult</code>.
 * 游戏大厅每日一荐推荐结果
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/11/21 9:36
 */
public class GameDailyRecommendResult extends RecommendResult {

    private String imei;

    private List<GameDailyRecommendItem> resultList;

    public GameDailyRecommendResult() {
        super.ok();
    }

    public GameDailyRecommendResult(String imei, List<GameDailyRecommendItem> resultList) {
        this.imei = imei;
        this.resultList = resultList;
        super.ok();
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public List<GameDailyRecommendItem> getResultList() {
        return resultList;
    }

    public void setResultList(List<GameDailyRecommendItem> resultList) {
        this.resultList = resultList;
    }

    @Override
    public String toString() {
        return "GameDailyRecommendResult{" +
                "imei='" + imei + '\'' +
                ", resultList=" + resultList +
                '}';
    }
}
