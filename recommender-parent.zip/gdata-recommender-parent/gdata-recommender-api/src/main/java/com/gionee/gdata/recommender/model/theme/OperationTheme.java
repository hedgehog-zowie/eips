package com.gionee.gdata.recommender.model.theme;

import com.gionee.gdata.recommender.common.Operation;
import com.gionee.gdata.recommender.common.ThemeScene;

/**
 * <code>OpeTheme</code>.
 * 运营策略类主题
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/8/23 13:44
 */
public class OperationTheme {

    /**
     * 主题ID
     */
    private String itemId;
    /**
     * 相关信息
     */
    private String itemInfo;
    /**
     * 场景ID
     */
    private ThemeScene scnId;
    /**
     * 运营策略ID
     */
    private Operation opeId;
    /**
     * 运营策略规则key
     */
    private String ruleKey;
    /**
     * 运营策略规则value
     */
    private String ruleValue;
    /**
     * 生效时间，毫秒级时间戳格式
     */
    private long effectiveTime;

    public OperationTheme() {
    }

    public OperationTheme(String itemId, String itemInfo, ThemeScene sncId, Operation opeId, String ruleKey, String ruleValue, long effectiveTime) {
        this.itemId = itemId;
        this.itemInfo = itemInfo;
        this.scnId = sncId;
        this.opeId = opeId;
        this.ruleKey = ruleKey;
        this.ruleValue = ruleValue;
        this.effectiveTime = effectiveTime;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public String getItemInfo() {
        return itemInfo;
    }

    public void setItemInfo(String itemInfo) {
        this.itemInfo = itemInfo;
    }

    public ThemeScene getScnId() {
        return scnId;
    }

    public void setScnId(ThemeScene scnId) {
        this.scnId = scnId;
    }

    public Operation getOpeId() {
        return opeId;
    }

    public void setOpeId(Operation opeId) {
        this.opeId = opeId;
    }

    public String getRuleKey() {
        return ruleKey;
    }

    public void setRuleKey(String ruleKey) {
        this.ruleKey = ruleKey;
    }

    public String getRuleValue() {
        return ruleValue;
    }

    public void setRuleValue(String ruleValue) {
        this.ruleValue = ruleValue;
    }

    public long getEffectiveTime() {
        return effectiveTime;
    }

    public void setEffectiveTime(long effectiveTime) {
        this.effectiveTime = effectiveTime;
    }

}
