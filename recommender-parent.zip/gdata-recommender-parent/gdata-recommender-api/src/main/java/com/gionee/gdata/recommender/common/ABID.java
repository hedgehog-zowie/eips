package com.gionee.gdata.recommender.common;

/**
 * <code>ABID</code>.
 * A/B Test ID
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/13 14:56
 */
public enum ABID {

    /**
     * 基于KMeans聚类的主题推荐
     */
    REC_THEME_K("基于KMeans聚类的主题推荐"),
    /**
     * 基于KMeans聚类的壁纸推荐
     */
    REC_WALLPAPER_K("基于KMeans聚类的壁纸推荐"),
	/**
     * 主题推荐小编推荐
     */
    REC_THEME_SIMILAR("主题推荐小编推荐"),
    /**
    /**
     * 基于KMeans聚类的下载管理推荐
     */
    REC_DOWN_K("基于KMeans聚类的下载管理推荐"),
	/**
     * 基于物品相似性的下载管理推荐
     */
    REC_DOWN_SIMILAR_ITEM("基于物品相似性的下载管理推荐"),
    /**
     * 游戏大厅-下载比例推荐算法
     */
    recGameDownloadRatio("游戏大厅-下载比例推荐算法"),
    /**
     * 游戏大厅-每日一荐LR推荐算法
     */
    recGameDailyLR("游戏大厅-每日一荐LR推荐算法"),
    /**
     * 基于物品相似性的浏览器-二级站点推荐
     */
    REC_BROWSER_SIMILAR_ITEM("基于物品相似性的浏览器-二级站点推荐"),
    ;

    /**
     * 略
     */
    private final String msg;

    /**
     * 略
     *
     * @param msg 略
     */
    ABID(final String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }

}
