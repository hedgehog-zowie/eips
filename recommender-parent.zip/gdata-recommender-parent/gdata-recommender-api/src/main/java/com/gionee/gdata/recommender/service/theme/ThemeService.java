package com.gionee.gdata.recommender.service.theme;

import com.gionee.gdata.common.utils.RandomUtil;
import com.gionee.gdata.common.utils.StringUtil;
import com.gionee.gdata.data.mybatis.entity.recommender.theme.ThemeUserItemFilter;
import com.gionee.gdata.data.mybatis.entity.recommender.theme.UserItemClusterScore;
import com.gionee.gdata.data.mybatis.mapper.recommender.theme.ThemeUserItemFilterMapper;
import com.gionee.gdata.data.mybatis.mapper.recommender.theme.UserItemClusterScoreMapper;
import com.gionee.gdata.data.redis.entity.recommender.theme.Result;
import com.gionee.gdata.data.redis.repository.recommender.theme.ThemeResultRepository;
import com.gionee.gdata.recommender.common.ABID;
import com.gionee.gdata.recommender.common.Operation;
import com.gionee.gdata.recommender.common.ThemeScene;
import com.gionee.gdata.recommender.model.RecommendItem;
import com.gionee.gdata.recommender.model.theme.ThemeRecommendResult;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * <code>ThemeServiceV2</code>.
 * 采用mysql + redis架构的主题服务类
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/13 13:27
 */
@Service
public class ThemeService {

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ThemeService.class);

    /**
     * 多个运营策略间的分隔符
     */
    private static final String OPERATION_SPLITTER = ",";

    /**
     * 每用户推荐结果个数
     */
    protected static final Integer MAX_RESULT_SIZE = 50;
    /**
     * 随机新品结果个数
     */
    protected static final Integer MAX_NEW_RANDOM_RESULT_SIZE = 3;

    /**
     * 主题算法服务
     */
    @Autowired
    private ThemeAlgorithmService themeAlgorithmService;
    /**
     * 运营策略服务
     */
    @Autowired
    private ThemeOperationService themeOperationService;
    /**
     * 结果处理服务
     */
    @Autowired
    private ThemeResultService themeResultService;
    /**
     * redis缓存的结果
     */
    @Autowired
    private ThemeResultRepository themeResultRepository;

    /**
     * 主题干预规则服务
     */
    @Autowired
    private ThemeRuleService themeRuleService;

    /**
     * 用户物品聚类评分mapper
     */
    @Autowired
    private UserItemClusterScoreMapper userItemClusterScoreMapper;

    /**
     * 下载的评分
     */
    @Value(value = "${recommender.api.theme.downloadScore}")
    private Double downloadScore;

    /**
     * 小编推荐-老用户推荐service
     */
    @Autowired
    private ThemeEditorService themeEditorService;

    /**
     * 用户推荐未下载过滤mapper
     */
    @Autowired
    private ThemeUserItemFilterMapper themeUserItemFilterMapper;

    /**
     * 根据主题用户物品聚类评分表和主题聚类物品评分表在线计算推荐物品，详细逻辑如下：
     * 主题推荐API服务实现逻辑:
     * 1、接收传入的imei(MD5加密), 机型系列号与返回条数(limit)
     * 2、获取推荐结果列表
     * 2.1计算待推荐池rem_item_list，推荐池计算逻辑如下
     * 2.1.1从用户主题评分表【用户、主题、聚类、评分】获取用户已存在的主题
     * 2.1.2获取用户喜欢的主题（喜欢的聚类），计算逻辑如下：
     * 2.1.2.1获取用户喜欢的聚类(从用户聚类表获取【用户、聚类、评分】)
     * 2.1.2.2根据用户喜欢的聚类，去主题聚类评分表获取主题列表，按评分排序
     * 2.1.3从2.1.2.2步骤得到主题列表，过滤掉用户已经存在的主题
     * 3、根据推荐列表进行颜色及风格规则干预
     * 3.1根据机型系列及上架时间(当前时间与上架时间比较),从推荐列表中获取已上架且评分最高的50个主题
     * 3.2从50个主题中随机获取27个主题
     * 3.3从27个主题，获取13个评分最高的主题，分别放在1,3,5,6,7,9,11,13,15,17,19,21,23,25,27的位置
     * 3.4剩下14个主题，按评分高低排序及颜色、风格的干预规则，分别放在2,4,6,8,10,12,14,16,18,20,22,24,26的位置
     *
     * @param imeiMd5 Md5加密后的imei
     * @param modelType   机型系列
     * @param limit   返回结果上限
     * @param isABModel   测试机型标志
     * @return 略
     */
//    public ThemeRecommendResult getRecommendResultOnline(final String imeiMd5, final String operations, final String model, final Integer limit) {
    public ThemeRecommendResult getRecommendResultOnline(final String imeiMd5, final String modelType, final Integer limit, final String isABModel) {
        // imeiMd5以偶数结尾，则进行推荐，用于评估效果
        // 新增AB测试机型，即是否需要按照单双号来进行主题推荐的机型    2017-9-21 11:37:58
        // 开放除测试机型外的全机型进行推荐，测试机型仍按AB测试流程进行推荐    2017-10-16 09:18:26
        if ((!StringUtil.endWithEven(imeiMd5) && "0".equals(isABModel)) || (StringUtil.endWithEven(imeiMd5) && "0".equals(isABModel))) {
            RecommendItem[] recommendItems = new RecommendItem[0];
            ThemeRecommendResult themeRecommendResult = new ThemeRecommendResult(imeiMd5, recommendItems);
            return themeRecommendResult;
        }

        // 结果集
        Set<RecommendItem> recommendItemSet = Sets.newLinkedHashSet();

        // 检查operations是否包含紧急策略，结果需要添加到最前
//        List<RecommendItem> urgentRecommendItems = Lists.newArrayList();
//        if (operations != null && operations.contains(Operation.theme_new_urgent.toString())) {
//            urgentRecommendItems.addAll(themeOperationService.computeResultListUseOperation(Operation.theme_new_urgent, model));
//            recommendItemSet.addAll(urgentRecommendItems);
//        }
//        // 如果紧急策略的结果个数已经大于等于 limit，则直接返回
//        if (urgentRecommendItems.size() >= limit) {
//            List<RecommendItem> newResultList = urgentRecommendItems.subList(0, limit - 1);
//            ThemeRecommendResult themeRecommendResult = new ThemeRecommendResult(imeiMd5, newResultList);
//            return themeRecommendResult;
//        }

        // 检查operations是否包含强制新品推荐策略，结果需要添加到最前
//        List<RecommendItem> newForceRecommendItems = Lists.newArrayList();
//        if (operations != null && operations.contains(Operation.theme_new_force.toString())) {
//            newForceRecommendItems.addAll(themeOperationService.computeResultListUseOperation(Operation.theme_new_force, model));
//            recommendItemSet.addAll(newForceRecommendItems);
//        }
//        // 如果紧急策略 + 强制新品推荐策略的结果个数已经大于等于 limit，则直接返回
//        if (recommendItemSet.size() >= limit) {
//            List<RecommendItem> newResultList = Lists.newArrayList(recommendItemSet).subList(0, limit - 1);
//            ThemeRecommendResult themeRecommendResult = new ThemeRecommendResult(imeiMd5, newResultList);
//            return themeRecommendResult;
//        }

        // 其他运营策略结果
//        List<RecommendItem> otherOpeRecommendItems = Lists.newArrayList();
//        if (operations != null) {
//            String[] operationArray = operations.split(OPERATION_SPLITTER);
//            Set<Operation> otherOperationSet = Sets.newHashSet();
//            try {
//                for (String operation : operationArray) {
//                    if (StringUtil.isBlank(operation)) {
//                        continue;
//                    }
//                    Operation themeOperation = Operation.valueOf(operation.trim());
//                    if (themeOperation != null &&
//                            Operation.theme_new_force != themeOperation &&
//                            Operation.theme_new_urgent != themeOperation) {
//                        otherOperationSet.add(themeOperation);
//                    }
//                }
//            } catch (Exception e) {
//                LOGGER.error("themeOperation error, please check it: {}", operations);
//            }
//            for (Operation themeOperation : otherOperationSet) {
//                switch (themeOperation) {
//                    case theme_new_random:
//                        otherOpeRecommendItems.addAll(themeOperationService.computeResultListUseThemeNewRandom(model, MAX_NEW_RANDOM_RESULT_SIZE));
//                        break;
//                    default:
//                        otherOpeRecommendItems.addAll(themeOperationService.computeResultListUseOperation(themeOperation, model));
//                        break;
//                }
//            }
//        }
//        recommendItemSet.addAll(otherOpeRecommendItems);

        // 从redis中获取推荐算法已经计算好的结果（保存ALL_RESULT_SIZE个）
        List<Result> algorithmResultList = themeResultRepository.getResult(imeiMd5);
        // 若redis中不存在结果，则在线计算结果
        if (algorithmResultList == null || algorithmResultList.size() == 0) {
            algorithmResultList = themeAlgorithmService.computeResultListUseKMeans(imeiMd5, modelType, MAX_RESULT_SIZE);
            // 添加到缓存
            themeResultRepository.setResult(imeiMd5, algorithmResultList);
        }
        // 将Result转换成RecommendItem
        List<RecommendItem> algorithmRecommendItems = Lists.newArrayList();
        try {
            for (Result result : algorithmResultList) {
                String item = result.getItem();
                LOGGER.info("推荐集合：" + item);
                String abIdStr = result.getAbId();
                String opeIdStr = result.getOpeId();
                Operation opeId = null;
                if (opeIdStr != null) {
                    opeId = Operation.valueOf(opeIdStr);
                }
                algorithmRecommendItems.add(new RecommendItem(item, opeId, abIdStr));
            }
        } catch (Exception e) {
            LOGGER.info("get abid or opeId error. error msg: {}", e.getLocalizedMessage());
        }
        recommendItemSet.addAll(algorithmRecommendItems);

        // 结果个数不足时，添加热门主题
        if (recommendItemSet.size() < limit) {
            List<RecommendItem> hotRecommendItems = themeOperationService.computeResultListUseOperation(Operation.theme_hot, modelType);
            Set<Integer> linkedRandoms = RandomUtil.getLinkedLimitRandom(0, hotRecommendItems.size(), hotRecommendItems.size());
            for (Integer index : linkedRandoms) {
                RecommendItem recommendItem = hotRecommendItems.get(index);
                recommendItemSet.add(recommendItem);
                // 若结果个数已经补足，则跳出循环
                if (recommendItemSet.size() == limit) {
                    break;
                }
            }
        }

        // 最终结果集
        Set<RecommendItem> finalRecommendItemSet = Sets.newLinkedHashSet();
        // 需要进行规则干预的结果列表
//        List<RecommendItem> needRuleResultList = Lists.newArrayList();
//        for (RecommendItem recommendItem : recommendItemSet) {
//            if (urgentRecommendItems.contains(recommendItem) || newForceRecommendItems.contains(recommendItem)) {
//                finalRecommendItemSet.add(recommendItem);
//            } else {
//                needRuleResultList.add(recommendItem);
//            }
//        }
        List<RecommendItem> needRuleResultList = Lists.newArrayList(recommendItemSet);

        // 需要进行规则干预的结果个数 = limit - 不需要进行规则干预的结果个数
        int size = limit - finalRecommendItemSet.size();
        List<RecommendItem> limitedRecommendItems = themeResultService.getRandomResult(needRuleResultList, size);

        // 干预规则
        RecommendItem[] ruledRecommendItems = themeRuleService.rule(limitedRecommendItems);
        // 添加到最终结果集
        finalRecommendItemSet.addAll(Lists.newArrayList(ruledRecommendItems));

        ThemeRecommendResult themeResult = new ThemeRecommendResult(imeiMd5, finalRecommendItemSet);
        return themeResult;
    }

    /**
     * 获取小编推荐主题
     * 对主题进行过滤，剔除与新品推荐相同的主题
     * 每个系列的主题只保存一个
     * 对主题的排序就行干预
     * @param imeiMd5
     * @param modelType
     * @param limit
     * @param isABModel
     * @return
     */
    public ThemeRecommendResult getEditorRecommendResult(final String imeiMd5, final String modelType, final Integer limit, final String isABModel) {
        // 不需要走推荐，直接返回空结果集(当ABModel为0,默认不走推荐)
        if ("0".equals(isABModel)) {
            RecommendItem[] recommendItems = new RecommendItem[0];
            ThemeRecommendResult themeRecommendResult = new ThemeRecommendResult(imeiMd5, recommendItems);
            return themeRecommendResult;
        }

        // 包含系列的结果集
        Map<String, List<RecommendItem>> resultMap = (Map<String, List<RecommendItem>>) themeResultRepository.getObjectResult("editor-" + imeiMd5);
        //
        List<RecommendItem> hotRecommendItems = Lists.newArrayList();
        // 获取新品推荐中缓存的所有主题
        Set<String> filterSet = Sets.newHashSet();
        List<Result> cacheList = themeResultRepository.getResult(imeiMd5);
        if (cacheList != null) {
            for (Result result: cacheList) {
                filterSet.add(result.getItem());
            }
        }
        //
        Set<RecommendItem> recommendItemSet = Sets.newLinkedHashSet();
        if (resultMap == null || resultMap.size() == 0) {
            resultMap = Maps.newHashMap();
            // 获取用户物品聚类评分
            List<UserItemClusterScore> userItemClusterScoreList = userItemClusterScoreMapper.findUserItemClusterScoreByUserMd5(imeiMd5);
            // 若没有获取到用户物品聚类评分，则当做新用户
            boolean dowmloadFlag = false;
            if (userItemClusterScoreList != null && userItemClusterScoreList.size() != 0) {
                for (UserItemClusterScore userItemClusterScore : userItemClusterScoreList) {
                    String item = userItemClusterScore.getItem();
                    Double score = userItemClusterScore.getScore();
                    // 评分>=downloadScore的物品才是下载过的物品
                    if (item != null && score != null && score >= downloadScore) {
                        // 存在下载，则表示为老用户，跳出循环
                        dowmloadFlag = true;
                        break;
                    }
                }
            }

            // 存在下载数据，则表示该用户为老用户
            if (dowmloadFlag) {
                // 老用户imeiMd5最后一位%3为0，直接返回空结果集
                if (0 == StringUtil.endResidue(imeiMd5, 3) || -1 == StringUtil.endResidue(imeiMd5, 3)) {
                    RecommendItem[] recommendItems = new RecommendItem[0];
                    ThemeRecommendResult themeRecommendResult = new ThemeRecommendResult(imeiMd5, recommendItems);
                    return themeRecommendResult;
                }
                resultMap = themeEditorService.getEditorRecommendResult(imeiMd5, modelType);
            }

            // 判断结果集是否够50个，不够则补足50个
            Integer resultSize = 0;
            if (resultMap != null) {
                for (String key : resultMap.keySet()) {
                    // 将个系列的结果长度相加
                    resultSize += resultMap.get(key).size();
                }
            }

            // 老用户推荐结果为空，或者结果小于50个，则补推荐池中的结果
            if (resultMap == null || resultMap.size() == 0 || resultSize < 50 || resultMap.get("0") == null) {
                // 新用户imeiMd5最后一位为基数时,直接返回空结果集
                if (!StringUtil.endWithEven(imeiMd5) && resultMap == null) {
                    RecommendItem[] recommendItems = new RecommendItem[0];
                    ThemeRecommendResult themeRecommendResult = new ThemeRecommendResult(imeiMd5, recommendItems);
                    return themeRecommendResult;
                }
                // 新用户推荐主题，直接获取
                try {
                    resultMap.putAll(themeOperationService.getResultList(ThemeScene.theme_editor.toString(), Operation.theme_hot, modelType));
                } catch (NullPointerException e) {
                    LOGGER.info("获取不到新用户推荐数据");
                }
            }
            // 将带系列的结果集存入缓存中
            themeResultRepository.setResult("editor-" + imeiMd5, resultMap);
        }

        // 需过滤的主题集合
        List<ThemeUserItemFilter> themeFilterList = themeUserItemFilterMapper.findAllUserFilterTheme(imeiMd5);
        if (themeFilterList != null) {
            for (ThemeUserItemFilter themeUserItemFilter: themeFilterList) {
                filterSet.add(themeUserItemFilter.getItem());
            }
        }

        // 每个系列取一套主题，并且保证主题不与新品推荐主题重复
        for (String key : resultMap.keySet()) {
            if (!"0".equals(key)) { // 当系列不为0的时候，只取一套主题
                List<RecommendItem> recommendItems = resultMap.get(key);
                // 过滤不需要推荐的主题, 将可能推荐的主题存在一个集合内
                List<RecommendItem> filteredRecItems = Lists.newArrayList();
                for (RecommendItem recommendItem : recommendItems) {
                    if (!filterSet.contains(recommendItem.getItemId())) {
                        filteredRecItems.add(recommendItem);
                    }
                }
                Random random = new Random();
                // 随机获取该系列一套主题
                Integer resultSize = filteredRecItems.size();
                // 只有一套主题的时候直接取下标为0的主题
                if (resultSize == 1) {
                    hotRecommendItems.add(filteredRecItems.get(0));
                } else if (resultSize != 0) {
                    Integer randomNum = random.nextInt(resultSize);
                    RecommendItem recommendItem = filteredRecItems.get(randomNum);
                    hotRecommendItems.add(recommendItem);
                }
            }
        }
        // 处理无系列主题
        List<RecommendItem> recommendItems = resultMap.get("0");
        // 过滤不需要推荐的主题, 将可能推荐的主题存在一个集合内
        List<RecommendItem> filteredRecItems = Lists.newArrayList();
        if (recommendItems != null) {
            if (recommendItems != null) {
                for (RecommendItem recommendItem : recommendItems) {
                    if (!filterSet.contains(recommendItem.getItemId())) {
                        filteredRecItems.add(recommendItem);
                    }
                }
            }
            hotRecommendItems.addAll(filteredRecItems);
        }

        if(hotRecommendItems.size() > MAX_RESULT_SIZE){
            hotRecommendItems = hotRecommendItems.subList(0, MAX_RESULT_SIZE);
        }
        // themeResultRepository.setResult("editor_" + imeiMd5, hotRecommendItems);
        // 打乱主题顺序
        Set<Integer> linkedRandoms = RandomUtil.getLinkedLimitRandom(0, hotRecommendItems.size(), hotRecommendItems.size());
        for (Integer index : linkedRandoms) {
            RecommendItem recommendItem = hotRecommendItems.get(index);
            recommendItemSet.add(recommendItem);
        }

        List<RecommendItem> needRuleResultList = Lists.newArrayList(recommendItemSet);

        // 最终结果集
        Set<RecommendItem> finalRecommendItemSet = Sets.newLinkedHashSet();
        // 需要进行规则干预的结果个数 = limit - 不需要进行规则干预的结果个数
        int size = limit - finalRecommendItemSet.size();
        List<RecommendItem> limitedRecommendItems = themeResultService.getRandomResult(needRuleResultList, size);

        // 干预规则
        RecommendItem[] ruledRecommendItems = themeRuleService.rule(limitedRecommendItems);
        // 添加到最终结果集
        finalRecommendItemSet.addAll(Lists.newArrayList(ruledRecommendItems));

        ThemeRecommendResult themeResult = new ThemeRecommendResult(imeiMd5, finalRecommendItemSet);
        return themeResult;
    }

}
