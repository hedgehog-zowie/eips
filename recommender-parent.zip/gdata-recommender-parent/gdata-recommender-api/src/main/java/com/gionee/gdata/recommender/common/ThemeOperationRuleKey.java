package com.gionee.gdata.recommender.common;

/**
 * <code>ThemeOpeRuleKey</code>.
 * 主题运营策略ruleKey
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/8/28 13:35
 */
public enum ThemeOperationRuleKey {

    /**
     * 机型系列
     */
    modeltype

}
