package com.gionee.gdata.recommender.common;

/**
 * <code>ResultCode</code>.
 * 返回码定义
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/13 14:57
 */
public enum ResultCode {

    /**
     * 略
     */
    SUCCESS("000000", "success"),
    /**
     * 略
     */
    ERROR_SYSTEM("100000", "system error."),
    /**
     * 略
     */
    ERROR_SIGNATURE("100001", "signature error."),
    /**
     * 略
     */
    ERROR_APPID("100002", "appId error."),
    /**
     * 略
     */
    ERROR_PARAM("100003", "parameters error."), ;

    /**
     * 略
     */
    private final String code;
    /**
     * 略
     */
    private final String msg;

    /**
     * 略
     *
     * @param code 略
     * @param msg  略
     */
    ResultCode(final String code, final String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    @Override
    public String toString() {
        return "{" + "\"code\":\"" + code + '\"' + ", \"msg\":\"" + msg + '\"' + '}';
    }

}
