package com.gionee.gdata.recommender.service.gamehall;

import com.gionee.gdata.data.mybatis.entity.recommender.gamehall.GameFirstTagCorrelDegree;
import com.gionee.gdata.data.mybatis.mapper.recommender.gamehall.GameFirstTagCorrelDegreeMapper;
import com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

/**
 * 一级标签处理
 *
 * @author yuwei
 * @version: 1.0-SNAPSHOT
 * date: 2017-10-13 13:39:02
 */
@Service
public class GameHallFirstTagCorrelService {
    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(GameHallFirstTagCorrelService.class);

    /**
     *
     */
    @Autowired
    private GameFirstTagCorrelDegreeMapper gameFirstTagCorrelDegreeMapper;

    /**
     * 获取一级标签相关度（按照相关度降序排序取firstLimt个推荐结果）
     * @param firstTagId
     * @param firstLimt
     * @return
     */    public List<String> getFirstTagRecommondResult(final String firstTagId, final Integer firstLimt){
        // 一级标签可以有多个，以英文逗号分隔
        String[] firstTagArray = firstTagId.split(",");
        // 数组转为list集合
        List<String> firstTagList = Arrays.asList(firstTagArray);
        LOGGER.info("一级标签集合：{}", firstTagList);
        // 获取一级标签下所有相关的游戏
        List<GameFirstTagCorrelDegree> gameFirstTagCorrelDegrees  = gameFirstTagCorrelDegreeMapper.findFirstTagCorrelDegree(firstTagList);
        if (gameFirstTagCorrelDegrees == null || gameFirstTagCorrelDegrees.size() == 0) {   // 当不存在一级标签推荐结果，直接返回null
            return null;
        }
        // 一级相关度推荐结果集
        List<String> firstTagRecommondList = Lists.newArrayList();
        // 已取值个数
        int i = 0;
        for (GameFirstTagCorrelDegree gameFirstTagCorrelDegree: gameFirstTagCorrelDegrees) {
            firstTagRecommondList.add(gameFirstTagCorrelDegree.getItem());
            if (i++ >= firstLimt) { // 只取firstLimt个，超出之后跳出循环
                break;
            }
        }
        return firstTagRecommondList;
    }
}
