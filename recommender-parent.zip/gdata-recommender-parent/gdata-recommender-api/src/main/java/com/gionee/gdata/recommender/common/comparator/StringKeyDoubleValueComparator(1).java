package com.gionee.gdata.recommender.common.comparator;

import java.io.Serializable;
import java.util.Comparator;
import java.util.Map;

/**
 * <code>StringKeyDoubleValueComparator</code>.
 * String为key, Double为value的map比较器
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/13 15:56
 */
public class StringKeyDoubleValueComparator implements Comparator<String>, Serializable {

    /**
     * 略
     */
    private Map<String, Double> base;

    /**
     * 略
     *
     * @param base 略
     */
    public StringKeyDoubleValueComparator(final Map<String, Double> base) {
        this.base = base;
    }

    /**
     * 略
     *
     * @param a 略
     * @param b 略
     * @return 略
     */
    @Override
    public int compare(final String a, final String b) {
        return base.get(a) > base.get(b) ? -1 : 1;
    }

}
