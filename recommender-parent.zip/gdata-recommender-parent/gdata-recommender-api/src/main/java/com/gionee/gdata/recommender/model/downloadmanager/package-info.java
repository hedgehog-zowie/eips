/**
 * <code>package-info</code>.
 * 下载管理数据模型定义
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/13 13:46
 */
package com.gionee.gdata.recommender.model.downloadmanager;
