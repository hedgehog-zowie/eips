/**
 * <code>package-info</code>.
 * spring配置包
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:30
 */
package com.gionee.gdata.recommender.config;
