/**
 * <code>package-info</code>.
 * 采用mysql + redis架构的服务包
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/7/13 13:28
 */
package com.gionee.gdata.recommender.service;
