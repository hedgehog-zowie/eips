/**
 * <code>package-info</code>.
 * 游戏大厅数据模型定义
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/11/21 9:35
 */
package com.gionee.gdata.recommender.model.gamehall;
