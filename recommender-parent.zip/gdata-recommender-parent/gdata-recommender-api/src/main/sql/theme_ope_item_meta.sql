-- 93 上程序路径： C:/etl_app/etl_proc/THEME_OPE_ITEM_META.kjb

-- 主题新品用户当访问第一次强制推荐 ----------
insert overwrite table theme_ope_item_meta
select a.theme_id item_id,--物品ID
       concat('title:',b.title,',down_times:',0,',avg_day_down:',0)  item_info,--业务方需要的物品其他信息
       'theme_new' snc_id,--场景ID
       'theme_new_force' ope_id,--运营策略ID
       'modeltype' rule_key, --运营策略规则key
       a.modeltype rule_value,--运营策略规则value
       from_unixtime(a.create_time,'yyyy-MM-dd HH:mm:ss') effective_time, --生效时间
       1 as effective_flag,--有效标识,1有效,0无效
       from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss') create_time --创建时间
from dim_theme_file_attribute a
left join stg_theme_file_${ETLDate} b on a.theme_id=b.id
where a.status=4 and from_unixtime(a.create_time,'yyyy-MM-dd')=from_unixtime(unix_timestamp(),'yyyy-MM-dd');

-- 主题新品用户当访问非第一次随机推荐 ----------
insert into table theme_ope_item_meta
select a.theme_id item_id,--物品ID
       concat('title:',b.title,',down_times:',0,',avg_day_down:',0) item_info,--业务方需要的物品其他信息
       'theme_new' snc_id,--场景ID
       'theme_new_random' ope_id,--运营策略ID
       'modeltype' rule_key, --运营策略规则key
       a.modeltype rule_value,--运营策略规则value
       from_unixtime(a.create_time,'yyyy-MM-dd HH:mm:ss') effective_time, --生效时间
       1 as effective_flag,--有效标识,1有效,0无效
       from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss') create_time --创建时间
from dim_theme_file_attribute a
left join stg_theme_file_${ETLDate} b on a.theme_id=b.id
where a.status=4 and from_unixtime(a.create_time,'yyyy-MM-dd')=from_unixtime(unix_timestamp(),'yyyy-MM-dd');


-- 主题新用户推荐热门主题 ----------
create  table if not exists temp_theme_rec_hot(
  theme_id int, 
  modeltype tinyint, 
  down_times int, 
  title string, 
  online_time string, 
  day_down int);
 
-- 取历史下载量最高的20套主题 -- 
insert overwrite table temp_theme_rec_hot  
select a.theme_id,a.modeltype,a.down_times,a.title,a.online_time,a.day_down
from (
select b.theme_id,b.modeltype,a.down down_times,a.title,b.create_time online_time,
       floor(a.down/(ceil((UNIX_TIMESTAMP('${DAY_ID}','yyyyMMdd') - b.create_time)/(60*60*24)))) day_down,
       row_number() over(partition by b.modeltype order by a.down desc) row_id
from stg_theme_file_${ETLDate} a 
inner join dim_theme_file_attribute b on a.id=b.theme_id
where b.status=4 and b.create_time<unix_timestamp('${DAY_ID}','yyyyMMdd') -- 已上架
and b.create_time is not null and b.create_time>0
) a where row_id<=20;


-- 除历史下载最高的20套主题个，再取平均每天下载量最高的30套主题 -- 
insert into table temp_theme_rec_hot 
select a.theme_id,a.modeltype,a.down_times,a.title,a.online_time,a.day_down 
from (
select  a.theme_id,a.modeltype,a.down_times,a.title,a.online_time,day_down,
        row_number()over(partition by a.modeltype order by day_down desc) row_id
from (
select b.theme_id,b.modeltype,a.down down_times,a.title,b.create_time online_time,
       floor(a.down/ceil((UNIX_TIMESTAMP('${DAY_ID}','yyyyMMdd') - b.create_time)/(60*60*24))) day_down
from stg_theme_file_${ETLDate} a 
inner join dim_theme_file_attribute b on a.id=b.theme_id
left join temp_theme_rec_hot c on a.id=c.theme_id
where c.theme_id is null 
and  b.status=4 and b.create_time<unix_timestamp('${DAY_ID}','yyyyMMdd') -- 已上架
and b.create_time is not null and b.create_time>0
) a  ) a where row_id<=30 ;

insert into table theme_ope_item_meta
select theme_id item_id,--物品ID
       concat('title:',title,',down_times:',down_times,',avg_day_down:',day_down) item_info,--业务方需要的物品其他信息
       'theme_new' snc_id,--场景ID
       'theme_hot' ope_id,--运营策略ID
       'modeltype' rule_key,--运营策略规则key
       modeltype rule_value,--运营策略规则value
       from_unixtime(online_time,'yyyy-MM-dd HH:mm:ss') effective_time,--生效时间
       1 as effective_flag,--有效标识,1有效,0无效
       from_unixtime(unix_timestamp(),'yyyy-MM-dd HH:mm:ss') create_time --创建时间
from temp_theme_rec_hot;


-- 记录存档 ---

insert overwrite table fact_theme_ope_item_meta partition(day_id=${ETLDate})
select item_id,
       item_info,
       snc_id,
       ope_id,
       rule_key,
       rule_value,
       effective_time,
       effective_flag,
       create_time
from theme_ope_item_meta;
