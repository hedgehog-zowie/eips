-- 创建HIVE表
CREATE TABLE rec_api_downloadmanager_log(
  action string,
  time string,
  imei string,
  apps string,
  limit int,
  result string
) partitioned by(day_id int)

-- 增加自助查询元数据
-- 增加元数据 - 表
INSERT INTO self_srv_tables(table_name_src,split_column,table_name_dest,table_desc,STATUS, SUBJECT, source_db, dest_db, data_date,syn_date,syn_user,create_user,crt_time) VALUES('rec_api_downloadmanager_log','day_id','推荐系统-下载管理接口日志','推荐系统-下载管理接口日志',1,'推荐系统','spark150','spark150','数据到当前时间前一小时',SYSDATE(),'陈智伟','陈智伟',SYSDATE());
-- 增加元数据 - 列
INSERT INTO self_srv_tables_columns(table_id, order_id, column_name, column_desc, data_type, COMMENT) VALUES(107, 1, 'action', '动作', 'string', '接口调用开始或结束等动作记录');
INSERT INTO self_srv_tables_columns(table_id, order_id, column_name, column_desc, data_type, COMMENT) VALUES(107, 2, 'time', '时间', 'string', '日志发生时间戳');
INSERT INTO self_srv_tables_columns(table_id, order_id, column_name, column_desc, data_type, COMMENT) VALUES(107, 3, 'imei', 'IMEI', 'string', 'IMEI号');
INSERT INTO self_srv_tables_columns(table_id, order_id, column_name, column_desc, data_type, COMMENT) VALUES(107, 4, 'apps', '应用列表', 'string', '接口传入参数-应用列表');
INSERT INTO self_srv_tables_columns(table_id, order_id, column_name, column_desc, data_type, COMMENT) VALUES(107, 5, 'limit', '结果个数', 'int', '接口传入参数-限制结果个数');
INSERT INTO self_srv_tables_columns(table_id, order_id, column_name, column_desc, data_type, COMMENT) VALUES(107, 5, 'result', '结果', 'string', '接口返回结果');
INSERT INTO self_srv_tables_columns(table_id, order_id, column_name, column_desc, data_type, COMMENT) VALUES(107, 5, 'day_id', '日期', 'int', '日期分区');
