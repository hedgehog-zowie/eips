-- 创建HIVE表
CREATE TABLE ctr_api_log(
  action string,
  time string,
  res string
) partitioned by(day_id int)
