package com.gionee.bigdata.recommender.tencent;

import com.google.common.collect.Lists;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * <code>PostUtilTest</code>.
 * ${DESCRIPTION}
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/21 15:53
 */
public class PostUtilTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(PostUtilTest.class);

    /**
     * 线程池
     */
    private static final ExecutorService EXECUTOR_SERVICE = Executors.newFixedThreadPool(1000);

    @Test
    public void test() throws InterruptedException {
        final PostUtil postUtil = new PostUtil(1000);
        final List<NameValuePair> params = Lists.newArrayList();
        params.add(new BasicNameValuePair("m", "multiDataImport"));
        params.add(new BasicNameValuePair("p", "[\"200000\",\"7d10d09d-be62-4979-9ee0-414f7a23086a\",\"uid=8fbcdd43a1b276068a552e3eca8a829a&oper_time=2017/06/08 18:59:25.000&test_id=0&rule_id=0&trace_id=0&item_id=8879&action_id=103&device=231&network_type=3&app_version=1.4.9.x&report_source=CATEGORY157_GID8879##uid=5e08520d1818734fe58c133e2208708c&oper_time=2017/06/08 18:36:00.000&test_id=0&rule_id=0&trace_id=0&item_id=7851&action_id=103&device=179&network_type=3&app_version=1.4.8.j&report_source=flashrecom651##uid=792ce270073c2cb2a3ee4caf1c5d30c7&oper_time=2017/06/08 19:25:23.000&test_id=0&rule_id=0&trace_id=0&item_id=5073&action_id=103&device=234&network_type=2&app_version=1.4.9.w&report_source=ad24_pcg_GID5073##uid=424be49ddbe04a4cf32cd309cfbf8a57&oper_time=2017/06/08 19:25:41.000&test_id=0&rule_id=0&trace_id=0&item_id=5743&action_id=103&device=222&network_type=3&app_version=1.4.7.g&report_source=gltj6866_GID5743##uid=424be49ddbe04a4cf32cd309cfbf8a57&oper_time=2017/06/08 19:25:56.000&test_id=0&rule_id=0&trace_id=0&item_id=5743&action_id=103&device=222&network_type=3&app_version=1.4.7.g&report_source=gltj6866_GID5743##uid=02f3749ba29bf3ae33b45adc1aa5d64e&oper_time=2017/06/08 18:22:52.000&test_id=0&rule_id=0&trace_id=0&item_id=8754&action_id=102&device=21000&network_type=3&app_version=1.4.5.a&report_source=CATEGORY3_GID8754##uid=e5d0c8bc0e5ee16c2602e0ec8872efdf&oper_time=2017/06/08 19:52:59.000&test_id=0&rule_id=0&trace_id=0&item_id=9057&action_id=103&device=176&network_type=3&app_version=1.4.9.t&report_source=Isearch##uid=f435aba0cece62263e3f4a71cf6ef0f3&oper_time=2017/06/08 19:44:26.000&test_id=0&rule_id=0&trace_id=0&item_id=7041&action_id=103&device=178&network_type=3&app_version=1.4.8.j&report_source=flashrecom651##uid=8c86044c241814dbd61c2e3f3e286563&oper_time=2017/06/08 19:43:21.000&test_id=0&rule_id=0&trace_id=0&item_id=6695&action_id=103&device=212&network_type=3&app_version=1.4.9.f&report_source=ad22_ness_GID6695##uid=e5d0c8bc0e5ee16c2602e0ec8872efdf&oper_time=2017/06/08 19:52:45.000&test_id=0&rule_id=0&trace_id=0&item_id=9057&action_id=103&device=176&network_type=3&app_version=1.4.9.t&report_source=Isearch\"]"));
        long start = new Date().getTime();
        for (int i = 0; i < 10000; i++) {
            EXECUTOR_SERVICE.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        postUtil.post(Constants.UPLOAD_URL, params);
                    } catch (Exception e) {
                        LOGGER.error("请求失败, {}", e.getLocalizedMessage());
                    }
                }
            });
        }
        EXECUTOR_SERVICE.shutdown();
        EXECUTOR_SERVICE.awaitTermination(Integer.MAX_VALUE, TimeUnit.SECONDS);
        long end = new Date().getTime();
        System.out.println("耗时：" + (end - start) + "ms");
    }

}
