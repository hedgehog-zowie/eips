package com.gionee.bigdata.recommender.tencent;

/**
 * <code>ReturnResult</code>.
 * 腾讯云推荐数据上报接口返回
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/14 14:04
 */
public class ReturnResult {

    /**
     * 腾讯云推荐数据上报接口返回代码
     */
    private String code;
    /**
     * 腾讯云推荐数据上报接口返回消息
     */
    private String message;

    public String getCode() {
        return code;
    }

    public void setCode(final String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(final String message) {
        this.message = message;
    }
}
