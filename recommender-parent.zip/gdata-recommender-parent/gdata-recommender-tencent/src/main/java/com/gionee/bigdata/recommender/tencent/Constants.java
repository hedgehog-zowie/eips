package com.gionee.bigdata.recommender.tencent;

/**
 * <code>Constants</code>.
 * 常量定义
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/13 10:34
 */
public final class Constants {

    /**
     * 隐藏public构造器
     */
    private Constants() {
    }

    /**
     * 数据上报URL
     */
    public static final String UPLOAD_URL = "https://sdtj.y.qq.com:8008/upload";

    /**
     * 客户用户行为类型（操作代码，比如：客户A的曝光数据、客户B的点击数据，此处为测试用的代码）
     * 物品
     */
    public static final String UPLOAD_ITEM_CODE = "200202";
    /**
     * 客户用户行为类型（操作代码，比如：客户A的曝光数据、客户B的点击数据，此处为测试用的代码）
     * 行为
     */
    public static final String UPLOAD_ACTION_CODE = "200201";

    /**
     * 上报时需要携带的token，用于标识客户的唯一身份，由云推荐引擎管理员分配
     */
    public static final String TOKEN = "3988a3ec-e546-4c3a-b13a-ef8d5e0a1501";

    /**
     * 物品数据文件 - 字段分隔符
     */
    public static final String ITEM_SPLITTER = "\001";
//    public static final String ITEM_SPLITTER = "\\|\\|";
    /**
     * 物品数据文件 - 字段个数
     */
    public static final int ITEM_LENGTH = 2;
    /**
     * 物品数据文件 - 物品ID字段位置
     */
    public static final int ITEM_ITEMID_INDEX = 0;
    /**
     * 物品数据文件 - 上线时间字段位置
     */
    public static final int ITEM_FTIME_INDEX = 1;
    /**
     * 物品池ID
     */
    public static final int ITEM_POOL_ID = 0;

    /**
     * 行为数据文件 - 字段分隔符
     */
    public static final String ACTION_SPLITTER = "\001";
//    public static final String ACTION_SPLITTER = "\\|\\|";

    /**
     * 行为数据文件 - 字段个数
     */
    public static final int ACTION_LENGTH = 8;
    /**
     * 行为数据文件 - IMEI长度，不符合此长度的数据丢弃
     */
    public static final int ACTION_IMEI_LENGTH = 15;
    /**
     * 行为数据文件 - IMEI字段位置
     */
    public static final int ACTION_IMEI_INDEX = 0;
    /**
     * 行为数据文件 - 操作类型字段位置
     */
    public static final int ACTION_ACTION_INDEX = 1;
    /**
     * 行为数据文件 - 客户端版本字段位置
     */
    public static final int ACTION_VERSION_INDEX = 2;
    /**
     * 行为数据文件 - 操作时间字段位置
     */
    public static final int ACTION_TIME_INDEX = 3;
    /**
     * 行为数据文件 - 网络类型字段位置
     */
    public static final int ACTION_NETTYPE_INDEX = 4;
    /**
     * 行为数据文件 - 物品id字段位置
     */
    public static final int ACTION_ITEMID_INDEX = 5;
    /**
     * 行为数据文件 - 来源字段位置
     */
    public static final int ACTION_REFERER_INDEX = 6;
    /**
     * 行为数据文件 - 机型字段位置
     */
    public static final int ACTION_DEVICE_INDEX = 7;

    /**
     * 场景ID
     */
    public static final int ACTION_TEST_ID = 0;
    /**
     * 算法ID，用于云推荐引擎推荐效果对比，由云推荐引擎推荐在线上返回时指定，接入推荐之前，填写0即可
     */
    public static final int ACTION_RULE_ID = 0;
    /**
     * 跟踪ID, 用于跟踪同一次推荐产生的所有行为
     */
    public static final int ACTION_TRACE_ID = 0;
    /**
     * 平台
     */
    public static final String ACTION_PLATFORM = "android";

}
