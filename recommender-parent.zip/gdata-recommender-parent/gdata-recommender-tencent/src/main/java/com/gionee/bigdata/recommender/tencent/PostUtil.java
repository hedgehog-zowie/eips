package com.gionee.bigdata.recommender.tencent;

import com.gionee.gdata.common.utils.JsonUtil;
import com.google.common.base.Charsets;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * <code>PostUtil</code>.
 * post请求腾讯云推荐接口
 *
 * @author zweig
 * @version: 1.0-SNAPSHOT
 * date: 2017/6/14 9:20
 */
public class PostUtil {

    /**
     * 日志记录器
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(PostUtil.class);

    /**
     * 连接池
     */
    private PoolingHttpClientConnectionManager connectionManager = null;
    /**
     * http客户端建造器
     */
    private HttpClientBuilder httpClientBuilder = null;
    /**
     * 请求配置
     */
    private RequestConfig requestConfig = null;

    /**
     * socket超时
     */
    private static final int SOCKET_TIME_OUT = 5000;
    /**
     * 连接超时
     */
    private static final int CONNECTION_TIME_OUT = 5000;
    /**
     * 请求超时
     */
    private static final int REQUEST_TIME_OUT = 5000;

    /**
     *
     * @param maxConnection 最大连接数
     */
    public PostUtil(final int maxConnection) {
        connectionManager = new PoolingHttpClientConnectionManager();
        // MaxTotal是整个连接池的最大连接数
        connectionManager.setMaxTotal(maxConnection);
        // DefaultMaxPerRoute是根据连接到的主机对MaxTotal的一个细分；比如：
        // MaxtTotal=400 DefaultMaxPerRoute=200
        // 当只连接到http://baidu.com时，到这个主机的并发最多只有200；而不是400；
        // 当连接到http://baidu.com 和 http://qq.com时，到每个主机的并发最多只有200；即加起来是400（但不能超过400）；所以起作用的设置是DefaultMaxPerRoute。
        connectionManager.setDefaultMaxPerRoute(maxConnection);

        // 为指定站点设置最大连接数
//        HttpHost target = new HttpHost(IP, PORT);
//        connectionManager.setMaxPerRoute(new HttpRoute(target), 20);

        httpClientBuilder = HttpClients.custom();
        httpClientBuilder.setConnectionManager(connectionManager);

        // 设置http的状态参数
        requestConfig = RequestConfig.custom()
                .setSocketTimeout(SOCKET_TIME_OUT)
                .setConnectTimeout(CONNECTION_TIME_OUT)
                .setConnectionRequestTimeout(REQUEST_TIME_OUT)
                .build();
    }

    /**
     * post方式请求接口
     *
     * @param url    请求URL
     * @param params 请求参数
     * @return 服务器返回的字符串
     * @throws Exception 抛出异常不处理，由调用者自行处理异常
     */
    public String post(final String url, final List<NameValuePair> params) throws Exception {
        HttpClient httpClient = httpClientBuilder.build();

        HttpPost request = new HttpPost(url);
        request.setConfig(requestConfig);

        HttpEntity httpEntity = new UrlEncodedFormEntity(params, "UTF-8");
        request.setEntity(httpEntity);

        HttpResponse response;
        response = httpClient.execute(request);
        String strResult;
        // 请求发送成功，并得到响应
        if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
            // 读取服务器返回过来的json字符串数据
            strResult = EntityUtils.toString(response.getEntity(), Charsets.UTF_8);
            LOGGER.info("response = {}", strResult);
            ReturnResult returnResult = JsonUtil.fromJson(strResult, ReturnResult.class);
            if (!"0".equals(returnResult.getCode())) {
                throw new RuntimeException("数据上报接口返回失败");
            }
        } else {
            strResult = EntityUtils.toString(response.getEntity());
            throw new RuntimeException("数据上报接口异常，" + strResult);
        }
        return strResult;
    }

}
