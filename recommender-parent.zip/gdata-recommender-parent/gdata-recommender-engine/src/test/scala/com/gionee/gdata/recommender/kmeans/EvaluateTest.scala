package com.gionee.gdata.recommender.kmeans

import java.util.Properties

import com.gionee.gdata.common.ConfigLoader
import org.apache.log4j.Logger
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
  * Created by Zweig on 2017/4/13.
  * Email: hedgehog.zowie@gmail.com
  */
object EvaluateTest {

  val logger = Logger.getLogger(EvaluateTest.getClass)

  def main(args: Array[String]) {

    val defaultParams = KMeansParams()
    val parser = new OptionParser[KMeansParams]("") {
      head("KMeans EvaluateTest", "1.0")
      opt[String]('c', "conf")
        .required()
        .valueName("config-file-path")
        .text(s"配置文件，必选")
        .action { (x, c) => c.copy(conf = x) }
      help("help").text("prints this usage text")
    }

    var props: Properties = null
    parser.parse(args, defaultParams) match {
      case Some(params) => {
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
      }
      case None => System.exit(1)
    }

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")

    val sparkConf = new SparkConf().
      setAppName(props.getProperty(KMeansConfig.SPARK_NAME_CONFIG)).
      setMaster(props.getProperty(KMeansConfig.SPARK_MASTER_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)
    val hiveContext = new HiveContext(sc)

    val itemRdd = sc.textFile("data/kmeans/items2.txt").map(line => {
      val fields = line.split("\t")
      (fields(0).trim, fields(1).trim, fields(2).trim)
    }).cache()

    if(Evaluate.init(sc, hiveContext, props))
      Evaluate.evaluate(itemRdd)

    sc.stop()

  }

}
