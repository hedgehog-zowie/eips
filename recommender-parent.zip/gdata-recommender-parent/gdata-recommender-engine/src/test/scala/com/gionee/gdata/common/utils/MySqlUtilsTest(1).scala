package com.gionee.gdata.common.utils

import com.gionee.gdata.common.ConfigLoader
import com.gionee.gdata.recommender.game.ConfigConstants
import org.apache.spark.sql.{SQLContext, SaveMode}
import org.apache.spark.{SparkConf, SparkContext}

/**
  * Created by Zweig on 2016/9/7.
  * Email: hedgehog.zowie@gmail.com
  */
object MySqlUtilsTest {

  def main(args: Array[String]) {
    val properties = ConfigLoader.load("test.properties")
    println(properties)

    val sparkConf = new SparkConf().
      setAppName(properties.getProperty(ConfigConstants.SPARK_NAME_CONFIG)).
      setMaster(properties.getProperty(ConfigConstants.SPARK_MASTER_CONFIG)).
      set("spark.ui.port", properties.getProperty(ConfigConstants.SPARK_UI_PORT_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)

    val mySqlTool = MySqlUtil.getInstance(sc, properties.getProperty("mysql.url"))

    val sqlContext = new SQLContext(sc)
    val df = sqlContext.createDataFrame(sc.parallelize(Seq((1, "a", "aa"), (2, "b", "bb"), (3, "c", "cc"))))
    mySqlTool.writeTable(df, "mySqlTool_test", SaveMode.Append)

    val df2 = sqlContext.createDataFrame(sc.parallelize(Seq((1, "a"), (2, "b"), (3, "c"))))
    mySqlTool.writeTable(df2, "mySqlTool_test", SaveMode.Append)
  }

}
