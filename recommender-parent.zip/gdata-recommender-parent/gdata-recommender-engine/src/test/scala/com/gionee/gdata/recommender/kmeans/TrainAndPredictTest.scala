package com.gionee.gdata.recommender.kmeans

import java.util.Properties

import com.gionee.gdata.common.ConfigLoader
import org.apache.log4j.Logger
import org.apache.spark.sql.Row
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
  * Created by Zweig on 2017/4/13.
  * Email: hedgehog.zowie@gmail.com
  */
object TrainAndPredictTest {

  val logger = Logger.getLogger(TrainAndPredictTest.getClass)

  def main(args: Array[String]) {
    val defaultParams = KMeansParams()
    val parser = new OptionParser[KMeansParams]("") {
      head("KMeans TrainAndPredictTest", "1.0")
      opt[String]('c', "conf")
        .required()
        .valueName("config-file-path")
        .text(s"配置文件，必选")
        .action { (x, c) => c.copy(conf = x) }
      help("help").text("prints this usage text")
    }

    var props: Properties = null
    parser.parse(args, defaultParams) match {
      case Some(params) => {
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
      }
      case None => System.exit(1)
    }

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")

    val sparkConf = new SparkConf().
      setAppName(props.getProperty(KMeansConfig.SPARK_NAME_CONFIG)).
      setMaster(props.getProperty(KMeansConfig.SPARK_MASTER_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)
    val hiveContext = new HiveContext(sc)

    val train = new Train
    // init als train
    if (!train.init(sc, hiveContext, props))
      System.exit(-1)

    val itemRdd = sc.textFile("data/kmeans/items2.txt").map(line => {
      val fields = line.split("\t")
      (fields(0).trim, fields(1).trim, fields(2).trim)
    }).cache()
    train.train(itemRdd)

    val recommend = new Recommend
    // init kmeans recommend
    if (!recommend.init(sc, hiveContext, props))
      System.exit(-1)

    recommend.saveCluster = true
    val clusterPredict = recommend.predict(itemRdd)
    clusterPredict.show(100)

    val scoreRdd = sc.textFile("data/kmeans/userItems.csv").map(line => {
      val fields = line.split(",")
      (fields(0).trim, fields(1).trim, fields(2).trim.toDouble)
    }).cache()
    recommend.needRecommend = true

    recommend.recommendOnline = true
    recommend.recommend(clusterPredict, scoreRdd)
    hiveContext.sql(s"select ${KMeansConstants.USER_COLUMN_NAME}, ${KMeansConstants.ITEM_COLUMN_NAME}, ${KMeansConstants.PREDICTION_COLUMN_NAME}, ${KMeansConstants.SCORE_COLUMN_NAME} from ${recommend.userItemClusterScoreTable}").show()
    hiveContext.sql(s"select ${KMeansConstants.ITEM_COLUMN_NAME}, ${KMeansConstants.PREDICTION_COLUMN_NAME}, ${KMeansConstants.SCORE_COLUMN_NAME} from ${recommend.itemClusterScoreTable}").show()

    recommend.recommendOnline = false
    recommend.recommend(clusterPredict, scoreRdd)
    hiveContext.sql(s"select ${KMeansConstants.USER_COLUMN_NAME}, ${KMeansConstants.RESULT_COLUMN_NAME} from ${recommend.recommendHiveTable}").
      orderBy(KMeansConstants.USER_COLUMN_NAME, KMeansConstants.RESULT_COLUMN_NAME).collect().foreach {
      case Row(user, result) => {
        println(s"${user} | ${result}")
      }
    }

    itemRdd.unpersist(true)
    scoreRdd.unpersist(true)

    sc.stop()

  }

}
