package com.gionee.gdata

import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.rdd.RDD

/**
  * Created by Zweig on 2016/9/2.
  * Email: hedgehog.zowie@gmail.com
  */
object Test {

  case class MyTest(a: Int)

  def main(args: Array[String]) {
    val max = 0
    val min = 0
    val v = 0
    val vt = (v - min) / (max - min)
    println(s"vt = ${vt}")

        val sparkConf = new SparkConf().setAppName("test").setMaster("local[*]")
        val sc = new SparkContext(sparkConf)
    //    val sqlContext = new SQLContext(sc)
    //
    //    val r0 = sc.parallelize(Array((1, 1), (1, 2), (1, 3), (1, 4), (2, 2), (2, 3), (2, 4), (2, 5)), 3)
    //    val reduceByKeyResult = r0.reduceByKey((key, value) => key + value).collect()
    //    print(s"reduceByKey =  ")
    //    reduceByKeyResult.foreach(print)
    //    println()
    //
        val r1 = sc.parallelize(List(1, 2, 3, 4, 5, 6), 4)
    //    //    printPartition(r1)
    //    val aggregateResult = r1.aggregate(0)(math.max(_, _), _ + _)
    //    println(s"aggregate = $aggregateResult")
    //
    //    val r2 = sc.parallelize(Array((1, 1.0), (1, 2.0), (1, 3.0), (1, 4.0), (1, 5.0), (2, 1.0), (2, 2.0)), 3)
    //    val combineResult = r2.combineByKey((v: Double) => (v: Double, 1),
    //      (c: (Double, Int), v: Double) => (c._1 + v, c._2 + 1),
    //      (c1: (Double, Int), c2: (Double, Int)) => (c1._1 + c2._1, c1._2 + c2._2)
    //    ).collect()
    //    print(s"reduceByKey = ")
    //    combineResult.foreach(print)
    //    println()
    //
    //    val r3 = sc.parallelize(Array((1, 2), (1, 3), (1, 4), (1, 5), (2, 3), (2, 4), (2, 5), (2, 6)), 3)
    //    val coGroupResult = r0.cogroup(r3).collect()
    //    print(s"cogroup = ")
    //    coGroupResult.foreach(print)
    //    println()
    //
    //    val treeAggregateResult = r2.treeAggregate(0, 0.0)(
    //      (u, t) => (u._1 + t._1, u._2 + t._2),
    //      (u1, u2) => (u1._1 + u2._1, u1._2 + u2._2),
    //      4
    //    )
    //    println(s"treeAggregateResult = $treeAggregateResult")
    //
    //    val foldResult = r2.fold((0, 0))((u, t) => (u._1 + t._1, u._2 + t._2))
    //    println(s"foldResult = $foldResult")
    //
    //    val reduceResult = r2.reduce((u, t) => (u._1 + t._1, u._2 + t._2))
    //    println(s"reduceResult = $reduceResult")
    //
    //    val lookUpResult = r2.lookup(1)
    //    println(s"lookUpResult = $lookUpResult")
    //
    //    val r4 = sc.parallelize(1 to 10000, 3)
    //    val sampleCount = r4.sample(false, 0.1, 0).count()
    //    println(s"sampleCount = $sampleCount")
    //
    //    val a = Array(1, 2, 3, 4)
    //    val as = a.slice(1, 3)
    //    print(s"as = ")
    //    as.foreach(i => print(s"$i,"))
    //    println()

  }

  def testToAndUntil(): Unit = {
    for (idx <- 0 to 10)
      println(idx)
    for (idx <- 0 until 10)
      println(idx)
  }

  def testFormatDouble: Unit = {
    val d = 3.1465926
    val ds = "%.2f".format(d)
    println(s"d = $ds")
  }

  def printPartition(rdd: RDD[Int]): Unit = {
    rdd.mapPartitionsWithIndex {
      (partIdx, iter) => {
        var part_map = scala.collection.mutable.Map[String, List[Int]]()
        while (iter.hasNext) {
          var part_name = "part_" + partIdx;
          var elem = iter.next()
          if (part_map.contains(part_name)) {
            var elems = part_map(part_name)
            elems ::= elem
            part_map(part_name) = elems
          } else {
            part_map(part_name) = List[Int] {
              elem
            }
          }
        }
        part_map.iterator
      }
    }.collect.map(println)
  }

}
