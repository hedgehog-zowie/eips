package com.gionee.gdata.recommender.kmeans

import org.apache.log4j.Logger
import org.apache.spark.ml.clustering.KMeansModel
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}

/**
  * Created by Zweig on 2017/4/13.
  * Email: hedgehog.zowie@gmail.com
  */
object KMeansTest {

  val logger = Logger.getLogger(KMeansTest.getClass)

  def main(args: Array[String]) {

    val sparkConf = new SparkConf().
      setAppName("KmeansTest").
      setMaster("local[*]").
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)
    val hiveContext = new HiveContext(sc)

    val featureRdd = sc.textFile("data/kmeans/features").map(line => {
      val fields = line.split("\t")
      val features = fields(1).trim.split(",")
      var featureVectors: List[Double] = List()
      for (feature <- features)
        featureVectors = featureVectors :+ feature.toString.toDouble
      (fields(0).trim, Vectors.dense(featureVectors.toArray))
    })

    val featureDataFrame = hiveContext.createDataFrame(featureRdd).toDF(KMeansConstants.ITEM_COLUMN_NAME, KMeansConstants.ITEM_FEATURES_COLUMN_NAME).cache()

    val model = KMeansModel.load("data/kmeans/model")

    model.transform(featureDataFrame).select(KMeansConstants.ITEM_COLUMN_NAME, KMeansConstants.PREDICTION_COLUMN_NAME).show(100, false)

    sc.stop()

  }

}
