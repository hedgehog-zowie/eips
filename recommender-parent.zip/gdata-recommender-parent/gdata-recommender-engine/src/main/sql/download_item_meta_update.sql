-- 下载管理物品聚类数据来源表dlv_item_meta更新语句
INSERT overwrite TABLE dlv_item_meta
SELECT tag_4_id AS item_id,app_type_id AS category,
CASE WHEN CONCAT(regexp_REPLACE(NVL(type_detail,''),'分类:',''),regexp_REPLACE(NVL(tag_detail,''),'TAG:','')) ='' THEN tag_name
ELSE CONCAT(regexp_REPLACE(NVL(type_detail,''),'分类:',''),regexp_REPLACE(NVL(tag_detail,''),'TAG:','')) END AS keywords
 FROM dim_app_tag WHERE tag_4_id IS NOT NULL
