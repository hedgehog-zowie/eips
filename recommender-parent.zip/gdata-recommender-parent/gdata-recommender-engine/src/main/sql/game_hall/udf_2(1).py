#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import sys

if __name__ == '__main__':
    for line in sys.stdin:
        line_arr = line.strip().split('\t')

        is_weekday = int(line_arr[-2])
        if is_weekday >= 1 and is_weekday <= 5:
            line_arr[-2] = '1,0'
        else:
            line_arr[-2] = '0,1'

        is_high_peak = int(line_arr[-1])
        if (is_high_peak >= 12 and is_high_peak < 14) or (is_high_peak >= 18 and is_high_peak < 24):
            line_arr[-1] = '1,0'
        else:
            line_arr[-1] = '0,1'

        for i in range(len(line_arr)):
            line_arr[i] = str(line_arr[i])

        print line_arr[0] + '\t' + line_arr[1] + '\t' + line_arr[2] + '\t' + ','.join(line_arr[3:])

