#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import sys

if __name__ == '__main__':
    for line in sys.stdin:
        ini_tag_score = {
            '1': '0', '3': '0', '4': '0', '8': '0',
            '13': '0', '32': '0', '35': '0', '36': '0',
            '151': '0', '154': '0', '155': '0', '157': '0',
            '232': '0', '239': '0'
        }
        imei, tags_scores = line.strip().split('\t')
        tag_score_arr = tags_scores.split(',')
        for tag_score in tag_score_arr:
            tag, score = tag_score.split(':')
            if tag in ini_tag_score.keys():
                ini_tag_score[tag] = score

        scores = []
        for key in ['1', '3', '4', '8', '13', '32', '35', '36', '151', '154', '155', '157', '232', '239']:
            scores.append(ini_tag_score[key])
        print imei + '\t' + '\t'.join(scores)
