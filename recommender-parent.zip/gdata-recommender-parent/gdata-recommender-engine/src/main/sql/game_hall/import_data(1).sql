USE testrecdb01;

DROP TABLE IF EXISTS p_fact_imei_vector;
CREATE TABLE p_fact_imei_vector(
  imeim VARCHAR(255) PRIMARY KEY NOT NULL,
  vector VARCHAR(255) NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=gb2312;

LOAD DATA LOCAL INFILE "/data/game_hall/recommend_every_day/p_fact_imei_vector"
REPLACE INTO TABLE p_fact_imei_vector(imeim, vector);

DROP TABLE IF EXISTS p_fact_item_vector;
CREATE TABLE p_fact_item_vector(
  item_id VARCHAR(255) PRIMARY KEY NOT NULL,
  vector VARCHAR(255) NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=gb2312;

LOAD DATA LOCAL INFILE "/home/hadoop/taylor/game_hall/daily/p_fact_item_vector.txt"
REPLACE INTO TABLE p_fact_item_vector(item_id, vector);

DROP TABLE IF EXISTS p_fact_imei_item_vector;
CREATE TABLE p_fact_imei_item_vector(
  imeim VARCHAR(255) NOT NULL,
  item_id VARCHAR(255) NOT NULL,
  vector VARCHAR(255) NOT NULL,
  PRIMARY KEY(imeim, item_id)
)ENGINE=InnoDB DEFAULT CHARSET=gb2312;

LOAD DATA LOCAL INFILE "/data/game_hall/recommend_every_day/p_fact_imei_item_vector"
REPLACE INTO TABLE p_fact_imei_item_vector(imeim, item_id, vector);
