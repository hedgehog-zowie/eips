USE game_hall;

set mapred.reduce.tasks = 15;
SET hive.auto.convert.join = true;
SET mapred.reduce.slowstart.completed.maps = 1.0;


------------------------------------------------------------------------------------------------------
-- 1、 预测用户表  记录数：
------------------------------------------------------------------------------------------------------
DROP TABLE IF EXISTS p_fact_imei;
CREATE TABLE p_fact_imei AS
SELECT
  t1.imei,
  IF (t4.imei_ctr_item IS NOT NULL, t4.imei_ctr_item, 0) AS imei_ctr_item,
  IF (t7.imei_ctr_game IS NOT NULL, t7.imei_ctr_game, 0) AS imei_ctr_game,
  IF (t9.mac_ctr_item IS NOT NULL, t9.mac_ctr_item, 0) AS mac_ctr_item,
  IF (t9.mac_ctr_game IS NOT NULL, t9.mac_ctr_game, 0) AS mac_ctr_game,
  IF (t8.p_1 IS NOT NULL, t8.p_1, 0) AS p_1,
  IF (t8.p_2 IS NOT NULL, t8.p_2, 0) AS p_2,
  IF (t8.p_3 IS NOT NULL, t8.p_3, 0) AS p_3,
  IF (t8.p_4 IS NOT NULL, t8.p_4, 0) AS p_4,
  IF (t8.p_5 IS NOT NULL, t8.p_5, 0) AS p_5,
  IF (t8.p_6 IS NOT NULL, t8.p_6, 0) AS p_6,
  IF (t8.p_7 IS NOT NULL, t8.p_7, 0) AS p_7,
  IF (t8.p_8 IS NOT NULL, t8.p_8, 0) AS p_8,
  IF (t8.p_9 IS NOT NULL, t8.p_9, 0) AS p_9,
  IF (t8.p_10 IS NOT NULL, t8.p_10, 0) AS p_10,
  IF (t8.p_11 IS NOT NULL, t8.p_11, 0) AS p_11,
  IF (t8.p_12 IS NOT NULL, t8.p_12, 0) AS p_12,
  IF (t8.p_13 IS NOT NULL, t8.p_13, 0) AS p_13,
  IF (t8.p_14 IS NOT NULL, t8.p_14, 0) AS p_14
FROM (SELECT imei, COLLECT_SET(mac_id)[0] AS mac_id FROM fact_gamec_home_recommend GROUP BY imei) t1
LEFT OUTER JOIN (
  SELECT
    t2.imei,
    IF (t3.imei IS NOT NULL, t3.user_click_ct_1, 0)/t2.user_imp_ct_1 AS imei_ctr_item
  FROM (
    SELECT
      imei,
      COUNT (1) AS user_imp_ct_1
    FROM fact_gamec_home_recommend WHERE active_type='0'
    GROUP BY imei
  ) t2
  LEFT OUTER JOIN (
    SELECT
      imei,
      COUNT (1) AS user_click_ct_1
    FROM fact_gamec_home_recommend WHERE active_type='1'
    GROUP BY imei
  ) t3
  ON (t2.imei=t3.imei)
) t4
ON (t1.imei=t4.imei)
LEFT OUTER JOIN (
  SELECT
    t5.imei,
    if (t6.imei is not null, t6.user_click_ct, 0)/t5.user_imp_ct AS imei_ctr_game
  FROM (
    SELECT
      imei,
      COUNT (1) AS user_imp_ct
    FROM fact_gamec_home_recommend_imei WHERE imp_flag='1'
    GROUP BY imei
  ) t5
  LEFT OUTER JOIN (
    SELECT
      imei,
      COUNT (1) AS user_click_ct
    FROM fact_gamec_home_recommend_imei WHERE click_flag='1' AND imp_flag='1'
    GROUP BY imei
  ) t6
  ON (t5.imei=t6.imei)
) t7
ON (t1.imei=t7.imei)
LEFT OUTER JOIN imei_prefer_tag_score t8
ON (t1.imei=t8.imei)
LEFT OUTER JOIN fact_mac t9
ON (t1.mac_id=t9.mac_id);


------------------------------------------------------------------------------------------------------
-- 2、 预测用户-40款游戏相似度表  记录数：
------------------------------------------------------------------------------------------------------
DROP TABLE IF EXISTS p_fact_imei_item;
CREATE TABLE p_fact_imei_item AS
SELECT
  t4.imei,
  t4.item_id,
  t4.score,
  IF (t5.imei IS NOT NULL AND t5.gamec_resource_id IS NOT NULL, '1,0', '0,1') AS is_follow
FROM (
  SELECT
    t3.imei,
    t3.item_id,
    SUM(t3.similar_score) AS score
  FROM (
    SELECT
      t1.imei,
      t1.game_id,
      t2.itemid AS item_id,
      t2.similar_score
    FROM (
      SELECT
        t.imei,
        t.gamec_resource_id AS game_id
      FROM (
        SELECT DISTINCT imei, gamec_resource_id FROM fact_gamec_home_recommend_imei WHERE imp_flag='1' AND click_flag='1'
      ) t
    ) t1 JOIN default.dlv_item_03 t2
    ON (t1.game_id=t2.similar_item)
  ) t3 GROUP BY t3.imei, t3.item_id
) t4
LEFT OUTER JOIN (
  SELECT
    DISTINCT imei,
      gamec_resource_id
    FROM fact_gamec_home_recommend WHERE active_type='2'
) t5
ON (t4.imei=t5.imei AND t4.item_id=t5.gamec_resource_id);

------------------------------------------------------------------------------------------------------
-- 3、 推荐特征向量
------------------------------------------------------------------------------------------------------
-- 3.1 待推荐用户特征向量（imei尾号为1）
ADD FILE udf_3.py;
DROP TABLE IF EXISTS p_fact_imei_vector;
CREATE TABLE p_fact_imei_vector AS
SELECT
  TRANSFORM (
    imei,
    imei_ctr_item,
    imei_ctr_game,
    mac_ctr_item,
    mac_ctr_game,
    p_1,
    p_2,
    p_3,
    p_4,
    p_5,
    p_6,
    p_7,
    p_8,
    p_9,
    p_10,
    p_11,
    p_12,
    p_13,
    p_14)
USING 'python udf_3.py'
AS (
  imeiM,
  vector)
FROM p_fact_imei;

-- 3.2 待推荐物品特征向量（40款）
DROP TABLE IF EXISTS p_fact_item_vector;
CREATE TABLE p_fact_item_vector AS
SELECT
  item_id,
  CONCAT_WS(',', CAST(package_size_level AS STRING), CAST(item_ctr_user AS STRING)) AS vector
FROM fact_item;

-- 3.3 待推荐用户-40款游戏相似度表
ADD FILE udf_4.py;
DROP TABLE IF EXISTS p_fact_imei_item_vector;
CREATE TABLE p_fact_imei_item_vector AS
SELECT
  TRANSFORM (
    imei,
    item_id,
    score,
    is_follow)
USING 'python udf_4.py'
AS (
  imeiM,
  item_id,
  vector)
FROM p_fact_imei_item;

