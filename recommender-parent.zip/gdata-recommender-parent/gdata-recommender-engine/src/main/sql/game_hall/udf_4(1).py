#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import sys
import hashlib

if __name__ == '__main__':
    for line in sys.stdin:
        line_arr = line.strip().split('\t')
        m2 = hashlib.md5()
        m2.update(line_arr[0])
        imeiMd5 = m2.hexdigest()
        print imeiMd5 + '\t' + line_arr[1] + '\t'+ ','.join(line_arr[2:])
