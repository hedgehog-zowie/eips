#!/usr/bin/env bash
# 1
sqoop export \
--connect jdbc:mysql://10.10.10.119:3306/rec \
--username recuser \
--password 'rec)2-gsf49' \
--table game_user_mac_item_feature_vector \
--export-dir hdfs://bis-newdatanode-s2c-89:9000/user/hive/warehouse/game_hall.db/game_user_mac_item_feature_vector \
--update-key user_md5,item_id \
--update-mode allowinsert \
--input-fields-terminated-by '\001' \
--num-mappers 20 \
--columns 'user_md5,item_id,vector'

# 2
sqoop export \
--connect jdbc:mysql://10.10.10.119:3306/rec \
--username recuser \
--password 'rec)2-gsf49' \
--table game_user_first_tag_feature_vector \
--export-dir hdfs://bis-newdatanode-s2c-89:9000/user/hive/warehouse/game_hall.db/game_user_first_tag_feature_vector \
--update-key user_md5,item_id \
--update-mode allowinsert \
--input-fields-terminated-by '\001' \
--num-mappers 50 \
--columns 'user_md5,item_id,vector'

# 3
sqoop export \
--connect jdbc:mysql://10.10.10.119:3306/rec \
--username recuser \
--password 'rec)2-gsf49' \
--table game_user_package_level_feature_vector \
--export-dir hdfs://bis-newdatanode-s2c-89:9000/user/hive/warehouse/game_hall.db/game_user_package_level_feature_vector \
--update-key user_md5,item_id \
--update-mode allowinsert \
--input-fields-terminated-by '\001' \
--num-mappers 50 \
--columns 'user_md5,item_id,vector'

# 4
sqoop export \
--connect jdbc:mysql://10.10.10.119:3306/rec \
--username recuser \
--password 'rec)2-gsf49' \
--table game_user_item_similarity_feature_vector \
--export-dir hdfs://bis-newdatanode-s2c-89:9000/user/hive/warehouse/game_hall.db/game_user_item_similarity_feature_vector \
--update-key user_md5,item_id \
--update-mode allowinsert \
--input-fields-terminated-by '\001' \
--num-mappers 30 \
--columns 'user_md5,item_id,vector'

## 5
sqoop export \
--connect jdbc:mysql://10.10.10.119:3306/rec \
--username recuser \
--password 'rec)2-gsf49' \
--table game_item_set \
--export-dir hdfs://bis-newdatanode-s2c-89:9000/user/hive/warehouse/game_hall.db/dim_gamec_game_recommend \
--update-key item_id \
--update-mode allowinsert \
--input-fields-terminated-by '\001' \
--num-mappers 30 \
--columns 'item_id'

# 6
sqoop export \
--connect jdbc:mysql://10.10.10.119:3306/rec \
--username recuser \
--password 'rec)2-gsf49' \
--table game_item_default_feature_vector \
--export-dir hdfs://bis-newdatanode-s2c-89:9000/user/hive/warehouse/game_hall.db/game_item_default_feature_vector \
--update-key item_id \
--update-mode allowinsert \
--input-fields-terminated-by '\001' \
--num-mappers 30 \
--columns 'item_id,vector1,vector2,vector3,vector4'
