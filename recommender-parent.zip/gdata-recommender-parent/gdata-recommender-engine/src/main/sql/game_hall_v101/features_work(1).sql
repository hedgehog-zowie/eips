USE game_hall;

SET mapred.reduce.tasks = 15;
SET hive.auto.convert.join = true;
SET mapred.reduce.slowstart.completed.maps = 1.0;

SET mapreduce.map.memory.mb= 4096;
SET mapreduce.map.java.opts= -Xmx3686m;
SET mapreduce.task.timeout=4800000;

SET hive.exec.parallel=true;
SET hive.exec.parallel.thread.number=16;
SET hive.groupby.skewindata=true;

ADD jar /home/hadoop/taylor/game_hall/udfmd5.jar;
CREATE TEMPORARY function md5 as 'albert_hadoop.Md5';

-- 1.1、用户对待推荐游戏的偏好 21475186
DROP TABLE IF EXISTS game_user_item_feature_vector;
CREATE TABLE game_user_item_feature_vector AS
SELECT
  md5(t1.imei) AS user_md5,
  t1.mac_id,
  t1.item_id,
  PERCENT_RANK() OVER(ORDER BY score) AS score
FROM (
  SELECT
    imei,
    mac_id,
    game_id AS item_id,
    prefer_score AS score
  FROM fact_game_recommend_score
  WHERE length(imei)=15 and imei<>'000000000000000'
) t1;

-- 1.2、机型对待推荐游戏的偏好  38211
DROP TABLE IF EXISTS game_mac_item_feature_vector;
CREATE TABLE game_mac_item_feature_vector AS
SELECT
  t1.mac_id,
  t1.item_id,
  PERCENT_RANK() OVER(ORDER BY t1.score) AS score
FROM (
  SELECT
    CAST (mac_id AS STRING) AS mac_id,
    CAST (game_id AS STRING) AS item_id,
    SUM (prefer_score) AS score
  FROM fact_game_recommend_score WHERE length(imei)=15 and imei<>'000000000000000' AND mac_id<>'0'
  GROUP BY mac_id, game_id
) t1;

-- 1.3、机型对待推荐游戏包等级的偏好 133204
DROP TABLE IF EXISTS game_mac_package_level_feature_vector;
CREATE TABLE game_mac_package_level_feature_vector AS
SELECT
  t2.mac_id,
  t3.item_id,
  PERCENT_RANK() OVER(ORDER BY t2.score) AS score
FROM (
  SELECT
    t1.mac_id,
    t1.package_size_level,
    SUM(t1.prefer_score) AS score
  FROM (
    SELECT
      CAST (mac_id AS STRING) AS mac_id,
      CASE
        WHEN package_size <=31 THEN 1
        WHEN package_size >31 AND package_size <=54 THEN 2
        WHEN package_size >54 AND package_size <=154 THEN 3
        WHEN package_size >154 THEN 4 END
      AS package_size_level,
      prefer_score
    FROM fact_game_package_score WHERE length(imei)=15 AND imei<>'000000000000000' AND mac_id<>'0'
  ) t1 GROUP BY t1.mac_id, t1.package_size_level
) t2 JOIN (
  SELECT
    CAST (game_id AS STRING) AS item_id,
    CASE
      WHEN package_size <=31 THEN 1
      WHEN package_size >31 AND package_size <=54 THEN 2
      WHEN package_size >54 AND package_size <=154 THEN 3
      WHEN package_size >154 THEN 4 END
    AS package_size_level
  FROM dim_gamec_game_recommend
) t3 ON (t2.package_size_level=t3.package_size_level);

--1.4 用户对待推荐游戏的偏好\机型对待推荐游戏的偏好\机型对待推荐游戏包等级的偏好  21474942
DROP TABLE IF EXISTS game_user_mac_item_feature_vector;
CREATE TABLE game_user_mac_item_feature_vector AS
SELECT
    t1.user_md5,
    t1.item_id,
    CONCAT_WS(',',
      CAST(t1.score AS STRING),
      CAST(t2.score AS STRING),
      CAST(t3.score AS STRING)
    ) AS vector
FROM game_user_item_feature_vector t1
JOIN game_mac_item_feature_vector t2
ON (t1.mac_id=t2.mac_id AND t1.item_id=t2.item_id)
JOIN game_mac_package_level_feature_vector t3
ON (t1.mac_id=t3.mac_id AND t1.item_id=t3.item_id);

-- 2、用户对待推荐游戏一级标签的偏好特征  254842797
DROP TABLE IF EXISTS game_user_first_tag_feature_vector;
CREATE TABLE game_user_first_tag_feature_vector AS
SELECT
  t1.user_md5,
  t2.item_id,
  t1.score AS vector
FROM (
  SELECT
    md5(imei) AS user_md5,
    CAST(first_tab_id AS STRING) AS first_tab_id,
    ROUND(prefer_score/30, 4) AS score
  FROM fact_game_first_score WHERE prefer_score<30 AND length(imei)=15 and imei<>'000000000000000' AND mac_id<>0
) t1 JOIN (
  SELECT
    CAST (game_id AS STRING) AS item_id,
    CAST (category_id AS STRING) AS first_tab_id
  FROM dim_gamec_game_recommend
) t2 ON (t1.first_tab_id=t2.first_tab_id);

-- 3、计算用户对待推荐游戏的包等级的偏好  258448560
DROP TABLE IF EXISTS game_user_package_level_feature_vector;
CREATE TABLE game_user_package_level_feature_vector AS
SELECT
  t3.user_md5,
  t4.item_id,
  t3.score AS vector
FROM (
  SELECT
    md5(t2.imei) AS user_md5,
    t2.package_size_level,
    PERCENT_RANK() OVER(ORDER BY t2.score) AS score
  FROM (
    SELECT
      t1.imei,
      t1.package_size_level,
      SUM (t1.prefer_score) AS score
    FROM (
      SELECT
        imei,
        CASE
          WHEN package_size <=31 THEN 1
          WHEN package_size >31 AND package_size <=54 THEN 2
          WHEN package_size >54 AND package_size <=154 THEN 3
          WHEN package_size >154 THEN 4 END
        AS package_size_level,
        prefer_score
      FROM fact_game_package_score WHERE length(imei)=15 and imei<>'000000000000000' AND mac_id<>'0'
    ) t1 GROUP BY t1.imei, t1.package_size_level
  ) t2
) t3 JOIN (
  SELECT
    CAST (game_id AS STRING) AS item_id,
    CASE
      WHEN package_size <=31 THEN 1
      WHEN package_size >31 AND package_size <=54 THEN 2
      WHEN package_size >54 AND package_size <=154 THEN 3
      WHEN package_size >154 THEN 4 END
    AS package_size_level
  FROM dim_gamec_game_recommend
) t4 ON (t3.package_size_level=t4.package_size_level);

-- 4、计算用户对待推荐游戏相似度得分以及是否关注  47953729
DROP TABLE IF EXISTS game_user_item_similarity_feature_vector;
CREATE TABLE game_user_item_similarity_feature_vector AS
SELECT
  md5(t4.imei) AS user_md5,
  t4.item_id,
  CONCAT_WS(',',
    CAST (ROUND(t4.score/14, 6) AS STRING),
    CAST (IF (t5.imei IS NOT NULL AND t5.gamec_resource_id IS NOT NULL, '1,0', '0,1') AS STRING)
  ) AS vector
FROM (
  SELECT
    t3.imei,
    t3.item_id,
    SUM(t3.similar_score) AS score
  FROM (
    SELECT
      t1.imei,
      t2.itemid AS item_id,
      t2.similar_score
    FROM (
      SELECT DISTINCT imei, gamec_resource_id FROM fact_gamec_home_recommend_imei WHERE imp_flag='1' AND click_flag='1'
    ) t1 JOIN default.dlv_item_03 t2 ON (t1.gamec_resource_id=t2.similar_item)
  ) t3 GROUP BY t3.imei, t3.item_id
) t4 LEFT OUTER JOIN (
  SELECT DISTINCT imei, gamec_resource_id FROM fact_gamec_home_recommend WHERE active_type='2'
) t5
ON (t4.imei=t5.imei AND t4.item_id=t5.gamec_resource_id);