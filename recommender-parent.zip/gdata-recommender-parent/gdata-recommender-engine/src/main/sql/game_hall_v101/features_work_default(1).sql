USE game_hall;

SET mapred.reduce.tasks = 15;
SET hive.auto.convert.join = true;
SET mapred.reduce.slowstart.completed.maps = 1.0;

ADD jar /home/hadoop/taylor/game_hall/udfmd5.jar;
CREATE TEMPORARY function md5 as 'albert_hadoop.Md5';

DROP TABLE IF EXISTS game_item_default_feature_vector;
CREATE TABLE game_item_default_feature_vector AS
SELECT
  t0.item_id,
  CONCAT_WS(',',
    CAST (IF (t1.item_id IS NOT NULL, t1.score, 0) AS STRING),
    CAST (IF (t2.item_id IS NOT NULL, t2.score, 0) AS STRING),
    CAST (IF (t3.item_id IS NOT NULL, t3.score, 0) AS STRING)
  ) AS vector1,
  CAST (IF (t4.item_id IS NOT NULL, t4.score, 0) AS STRING) AS vector2,
  CAST (IF (t5.item_id IS NOT NULL, t5.score, 0) AS STRING) AS vector3,
  IF (t6.item_id IS NOT NULL, t6.vector, '0,0,1') AS vector4
FROM (
  SELECT CAST (game_id AS STRING) AS item_id FROM dim_gamec_game_recommend
) t0 LEFT OUTER JOIN (
  SELECT
    item_id,
    AVG (score) AS score
  FROM game_user_item_feature_vector GROUP BY item_id
) t1 ON (t0.item_id=t1.item_id)
LEFT OUTER JOIN (
  SELECT
    item_id,
    AVG (score) AS score
  FROM game_mac_item_feature_vector GROUP BY item_id
) t2 ON (t0.item_id=t2.item_id)
LEFT OUTER JOIN (
  SELECT
    item_id,
    AVG (score) AS score
  FROM game_mac_package_level_feature_vector GROUP BY item_id
) t3 ON (t0.item_id=t3.item_id)
LEFT OUTER JOIN (
  SELECT
    item_id,
    AVG (vector) AS score
  FROM game_user_first_tag_feature_vector GROUP BY item_id
) t4 ON (t0.item_id=t4.item_id)
LEFT OUTER JOIN (
  SELECT
    item_id,
    AVG (vector) AS score
  FROM game_user_package_level_feature_vector GROUP BY item_id
) t5 ON (t0.item_id=t5.item_id)
LEFT OUTER JOIN (
  SELECT
    item_id,
    CONCAT_WS(',',
      CAST (AVG (CAST (SPLIT(vector, ',')[0] AS DOUBLE)) AS STRING),
      CAST (AVG (CAST (SPLIT(vector, ',')[1] AS INT)) AS STRING),
      CAST (AVG (CAST (SPLIT(vector, ',')[2] AS INT)) AS STRING)
    ) AS vector
  FROM game_user_item_similarity_feature_vector GROUP BY item_id
) t6 ON (t0.item_id=t6.item_id);
