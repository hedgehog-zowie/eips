-- 下载管理推荐-用户、物品、聚类、评分导出表
drop table if exists download_kmeans_user_item_cluster_score_exp;
create table download_kmeans_user_item_cluster_score_exp(
  user_md5 string comment '用户MD5',
  userId string comment '用户',
  itemId string comment '物品',
  prediction int comment '聚类',
  rating double comment '评分'
)
comment '下载管理推荐-用户、物品、聚类、评分导出表';

-- 下载管理推荐-物品、聚类导出表
drop table if exists download_kmeans_item_cluster_exp;
create table download_kmeans_item_cluster_exp(
  itemId string comment '物品',
  prediction int comment '聚类'
)
comment '下载管理推荐-物品、聚类导出表';

-- 测试语句
insert overwrite table download_kmeans_user_item_cluster_score_exp select md5(user_id) userMd5, user_id, substr(app_pkg, instr(app_pkg, '-') + 1) itemId, prediction cluster, dlv_value rating from (select user_id, app_pkg, prediction, max(dlv_value) dlv_value from dlv_item_down_mana_result group by user_id, app_pkg, prediction) t;
insert overwrite table download_kmeans_item_cluster_exp select dat.app_pkg itemId, dik.prediction cluster from dim_app_tag dat left join dlv_item_kmeans dik on dat.tag_4_id = dik.id where dat.tag_4_id is not null;



-- 下载管理推荐-用户、物品、聚类、评分导入mysql表
drop index idx_download_kmeans_user_item_cluster_score_cluster on download_kmeans_user_item_cluster_score;
drop index idx_download_kmeans_user_item_cluster_score_user_md5 on download_kmeans_user_item_cluster_score;
drop table if exists download_kmeans_user_item_cluster_score;
create table download_kmeans_user_item_cluster_score
(
   user_md5             varchar(32) not null,
   userId                 varchar(32) not null comment '用户',
   itemId                 varchar(32) not null comment '物品',
   cluster              int not null comment '聚类',
   rating                double not null comment '评分'
);
alter table download_kmeans_user_item_cluster_score comment '用户物品聚类评分表——下载管理';
create index idx_download_kmeans_user_item_cluster_score_user_md5 on download_kmeans_user_item_cluster_score(user_md5);
create index idx_download_kmeans_user_item_cluster_score_cluster on download_kmeans_user_item_cluster_score(cluster);

-- 下载管理推荐-物品、聚类导入mysql表
drop index idx_download_kmeans_item_cluster_cluster on download_kmeans_item_cluster;
drop index idx_download_kmeans_item_cluster_item on download_kmeans_item_cluster;
drop table if exists download_kmeans_item_cluster;
create table download_kmeans_item_cluster
(
   itemId                 varchar(64) not null comment '物品唯一标识',
   cluster              int not null comment '聚类'
);
alter table download_kmeans_item_cluster comment '物品聚类表';
create index idx_download_kmeans_item_cluster_item on download_kmeans_item_cluster(itemId);
create index idx_download_kmeans_item_cluster_cluster on download_kmeans_item_cluster(cluster);



-- 导出测试语句
sqoop export --connect jdbc:mysql://10.10.10.119:3306/rec --username 'recuser' --password 'rec)2-gsf49' --driver com.mysql.jdbc.Driver --table download_kmeans_user_item_cluster_score --export-dir /userId/hive/warehouse/download_kmeans_user_item_cluster_score_exp --input-fields-terminated-by '\001'
sqoop export --connect jdbc:mysql://10.10.10.119:3306/rec --username 'recuser' --password 'rec)2-gsf49' --driver com.mysql.jdbc.Driver --table download_kmeans_item_cluster --export-dir /userId/hive/warehouse/download_kmeans_item_cluster_exp --input-fields-terminated-by '\001'

