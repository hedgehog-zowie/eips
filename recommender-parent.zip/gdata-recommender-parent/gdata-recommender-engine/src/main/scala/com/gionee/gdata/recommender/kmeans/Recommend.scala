package com.gionee.gdata.recommender.kmeans

import java.util
import java.util.Properties

import com.gionee.gdata.common.ConfigLoader
import com.gionee.gdata.common.hbase.HBaseExecutor
import com.gionee.gdata.common.utils.HashUtil
import org.apache.commons.lang3.StringUtils
import org.apache.hadoop.hbase.client.Put
import org.apache.hadoop.hbase.util.Bytes
import org.apache.log4j.Logger
import org.apache.spark.ml.clustering.KMeansModel
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.{DataFrame, Row, SaveMode}
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
  * <code>Recommend</code>.
  * 推荐
  *
  * @author zweig
  *         version: 1.0-SNAPSHOT
  *         date: 2017/6/9 18:19
  */
class Recommend {

  val logger = Logger.getLogger(this.getClass)

  var sc: SparkContext = _
  var hiveContext: HiveContext = _
  var model: KMeansModel = _

  // 业务配置
  /**
    * 待预测集查询sql
    */
  var predictSql: String = _
  /**
    * 评分查询sql
    */
  var scoreSql: String = _
  /**
    * 是否需要进行推荐
    */
  var needRecommend: Boolean = false
  /**
    * 是否需要在线推荐
    */
  var recommendOnline: Boolean = true
  /**
    * 物品、聚类、评分表
    */
  var itemClusterScoreTable: String = _
  /**
    * 聚类、物品、评分表
    */
  var clusterItemScoreTable: String = _
  /**
    * 用户、物品、聚类、评分表
    */
  var userItemClusterScoreTable: String = _
  /**
    * 是否保存到Hive
    */
  var saveToHive: Boolean = false
  /**
    * hive推荐结果表
    */
  var recommendHiveTable: String = _
  /**
    * 是否保存聚类结果
    */
  var saveCluster: Boolean = false
  /**
    * 聚类结果表
    */
  var clusterTable: String = _
  /**
    * 标称型特征全集
    */
  var enumFeaturesArray: Array[String] = _
  /**
    * 数值型特征全集
    */
  var valueFeaturesArray: Array[String] = _
  /**
    * 每用户推荐结果个数
    */
  var recommendResultSize = 50

  /**
    * 是否保存推荐结果到HBase
    */
  var saveToHBase: Boolean = true
  // HBase相关参数
  var zkQuorum: String = _
  var zkPort: String = _
  var hbaseTableName: String = _
  var hbaseTableCf: String = _
  var hbaseTableCfBytes: Array[Byte] = _
  var resultHBaseExecutor: HBaseExecutor = _

  var userItemClusterScoreHBaseExecutor: HBaseExecutor = _

  var itemClusterHBaseExecutor: HBaseExecutor = _

  var clusterItemHBaseExecutor: HBaseExecutor = _

  val DEFAULT_BLOCK_SIZE = 16384
  val DEFAULT_REGION_NUM = 60
  val DEFAULT_COLUMN_FAMILY = "f"
  val DEFAULT_COLUMN_FAMILY_BYTES = Bytes.toBytes(DEFAULT_COLUMN_FAMILY)
  val DEFAULT_RESULT_QUALIFIER = Bytes.toBytes("r")
  val DEFAULT_BATCH_PUT_SIZE = 10000
  val DEFAULT_SPLITTER = "-"

  def init(sc: SparkContext, hiveContext: HiveContext, props: Properties): Boolean = {
    // spark配置上下文
    this.sc = sc
    this.hiveContext = hiveContext

    val saveClusterConfig = props.getProperty(KMeansConfig.SAVE_CLUSTER_CONFIG)
    if (StringUtils.isNotBlank(saveClusterConfig))
      this.saveCluster = saveClusterConfig.toBoolean
    this.clusterTable = props.getProperty(KMeansConfig.CLUSTER_TABLE_CONFIG)
    if (saveCluster) {
      if (StringUtils.isBlank(this.clusterTable)) {
        logger.error("需要保存聚类结果，聚类结果表名必须配置")
        return false
      }
    }

    val needRecommendConfig = props.getProperty(KMeansConfig.NEED_RECOMMEND_CONFIG)
    if (StringUtils.isNotBlank(needRecommendConfig))
      this.needRecommend = needRecommendConfig.toBoolean
    this.scoreSql = props.getProperty(KMeansConfig.SCORE_SQL_CONFIG)
    val recommendOnlineConfig = props.getProperty(KMeansConfig.RECOMMEND_ONLINE_CONFIG)
    if (StringUtils.isNotBlank(recommendOnlineConfig))
      this.recommendOnline = recommendOnlineConfig.toBoolean
    this.itemClusterScoreTable = props.getProperty(KMeansConfig.ITEM_CLUSTER_SCORE_TABLE_CONFIG)
    this.clusterItemScoreTable = props.getProperty(KMeansConfig.CLUSTER_ITEM_SCORE_TABLE_CONFIG)
    this.userItemClusterScoreTable = props.getProperty(KMeansConfig.USER_ITEM_CLUSTER_SCORE_TABLE_CONFIG)
    this.recommendHiveTable = props.getProperty(KMeansConfig.RECOMMEND_TABLE_IN_HIVE_CONFIG)
    val saveToHiveConfig = props.getProperty(KMeansConfig.SAVE_TO_HIVE_CONFIG)
    if (StringUtils.isNoneBlank(saveToHiveConfig))
      this.saveToHive = saveToHiveConfig.toBoolean
    val saveToHBaseConfig = props.getProperty(KMeansConfig.SAVE_TO_HBASE_CONFIG)
    if (StringUtils.isNotBlank(saveToHBaseConfig))
      this.saveToHBase = saveToHBaseConfig.toBoolean
    // hbase配置
    this.zkQuorum = props.getProperty(KMeansConfig.ZK_QUORUM_CONFIG)
    this.zkPort = props.getProperty(KMeansConfig.ZK_PORT_CONFIG)

    if (needRecommend) {
      if (StringUtils.isBlank(this.scoreSql)) {
        logger.error("需要进行推荐，评分SQL必须配置")
        return false
      }

      if (recommendOnline) {
        if (StringUtils.isBlank(this.userItemClusterScoreTable)) {
          logger.error("需要根据物品来进行推荐，用户、物品、聚类、评分表名必须配置")
          return false
        }
        if (StringUtils.isBlank(this.itemClusterScoreTable)) {
          logger.error("需要根据物品来进行推荐，物品、聚类、评分表名必须配置")
          return false
        }
        if (StringUtils.isBlank(this.clusterItemScoreTable)) {
          logger.error("需要根据物品来进行推荐，聚类、物品、评分表名必须配置")
          return false
        }
        // 检查hbase中的表是否存在
        this.userItemClusterScoreHBaseExecutor = new HBaseExecutor(zkQuorum, zkPort, userItemClusterScoreTable, DEFAULT_COLUMN_FAMILY)
        if (this.userItemClusterScoreHBaseExecutor.exists())
          this.userItemClusterScoreHBaseExecutor.drop()
        this.userItemClusterScoreHBaseExecutor.create(DEFAULT_BLOCK_SIZE, DEFAULT_REGION_NUM)

        this.itemClusterHBaseExecutor = new HBaseExecutor(zkQuorum, zkPort, itemClusterScoreTable, DEFAULT_COLUMN_FAMILY)
        if (this.itemClusterHBaseExecutor.exists())
          this.itemClusterHBaseExecutor.drop()
        this.itemClusterHBaseExecutor.create(DEFAULT_BLOCK_SIZE, DEFAULT_REGION_NUM)

        this.clusterItemHBaseExecutor = new HBaseExecutor(zkQuorum, zkPort, clusterItemScoreTable, DEFAULT_COLUMN_FAMILY)
        if (this.clusterItemHBaseExecutor.exists())
          this.clusterItemHBaseExecutor.drop()
        this.clusterItemHBaseExecutor.create(DEFAULT_BLOCK_SIZE, DEFAULT_REGION_NUM)
      } else {
        if (saveToHive) {
          if (StringUtils.isBlank(this.recommendHiveTable)) {
            logger.error("需要进行推荐，推荐结果表名必须配置")
            return false
          }
        }
        if (saveToHBase) {
          this.hbaseTableName = props.getProperty(KMeansConfig.HBASE_RESULT_TABLE_CONFIG)
          this.hbaseTableCf = props.getProperty(KMeansConfig.HBASE_RESULT_CF_CONFIG)
          if (StringUtils.isBlank(zkQuorum) || StringUtils.isBlank(zkPort) || StringUtils.isBlank(hbaseTableName) || StringUtils.isBlank(hbaseTableCf)) {
            logger.error("hbase相关配置错误")
            return false
          }
          this.resultHBaseExecutor = new HBaseExecutor(zkQuorum, zkPort, hbaseTableName, hbaseTableCf)
          this.hbaseTableCfBytes = Bytes.toBytes(hbaseTableCf)
          if (!this.resultHBaseExecutor.exists())
            this.resultHBaseExecutor.create(DEFAULT_BLOCK_SIZE, DEFAULT_REGION_NUM)
        }
      }

    }

    this.predictSql = props.getProperty(KMeansConfig.PREDICT_SQL_CONFIG)
    if (StringUtils.isBlank(this.predictSql)) {
      logger.error("待预测集查询SQL必须配置")
      return false
    }

    val modelPath = props.getProperty(KMeansConfig.MODEL_PATH_CONFIG)
    if (StringUtils.isBlank(modelPath)) {
      logger.error("模型保存路径必须配置")
      return false
    }
    this.model = KMeansModel.load(modelPath)

    val enumFeaturesPath = props.getProperty(KMeansConfig.ENUM_FEATURES_PATH_CONFIG)
    val valueFeaturesPath = props.getProperty(KMeansConfig.VALUE_FEATURES_PATH_CONFIG)
    if (StringUtils.isBlank(enumFeaturesPath) && StringUtils.isBlank(valueFeaturesPath)) {
      logger.error("标称型特征或数值型特征保存路径至少配置一个")
      return false
    }
    this.enumFeaturesArray = sc.textFile(enumFeaturesPath).collect()
    this.valueFeaturesArray = sc.textFile(valueFeaturesPath).collect()

    val recommendResultSizeConfig = props.getProperty(KMeansConfig.RECOMMEND_RESULT_SIZE_CONFIG)
    if (StringUtils.isNotBlank(recommendResultSizeConfig)) {
      this.recommendResultSize = recommendResultSizeConfig.toInt
    }

    return true
  }

  /**
    * 聚类
    */
  def predict(): DataFrame = {
    predict(hiveContext.sql(predictSql).map {
      case Row(item, enumFeatures, valueFeatures) =>
        (item.toString, enumFeatures.toString, valueFeatures.toString)
    })
  }

  /**
    * 聚类
    */
  def predict(originalFeaturesRdd: RDD[(String, String, String)]): DataFrame = {
    val originalItemTable = hiveContext.createDataFrame(originalFeaturesRdd).toDF(
      KMeansConstants.ITEM_COLUMN_NAME, KMeansConstants.ITEM_ENUM_FEATURES_COLUMN_NAME, KMeansConstants.ITEM_VALUE_FEATURES_COLUMN_NAME).
      cache()
    val count = originalItemTable.count()
    if (count == 0) {
      logger.warn(s"不存在物品表，无法进行聚类。")
      return null
    }
    logger.info(s"物品表数据条数：$count")
    originalItemTable.show(20, false)

    val itemRdd = FeaturesTool.handleItems(originalItemTable).cache()
    val features = hiveContext.createDataFrame(
      FeaturesTool.handleFeatures(itemRdd, enumFeaturesArray, valueFeaturesArray)
    ).toDF(KMeansConstants.ITEM_COLUMN_NAME, KMeansConstants.ITEM_FEATURES_COLUMN_NAME).cache()

    features.show(20, false)

    val predictions = model.transform(features).select(KMeansConstants.ITEM_COLUMN_NAME, KMeansConstants.PREDICTION_COLUMN_NAME)
    if (saveCluster)
      predictions.write.mode(SaveMode.Overwrite).saveAsTable(clusterTable)

    features.unpersist()
    itemRdd.unpersist()

    predictions
  }

  /**
    * 推荐
    */
  def recommend(clusterDataFrame: DataFrame): Unit = {
    recommend(clusterDataFrame, hiveContext.sql(scoreSql).map {
      case Row(user, item, score) =>
        (user.toString, item.toString, score.toString.toDouble)
    })
  }

  /**
    * 推荐
    *
    * @param clusterDataFrame
    * @param scoreRdd
    */
  def recommend(clusterDataFrame: DataFrame, scoreRdd: RDD[(String, String, Double)]): Unit = {
    val scoreDataFrame = hiveContext.createDataFrame(scoreRdd).
      toDF(KMeansConstants.USER_COLUMN_NAME, KMeansConstants.ITEM_COLUMN_NAME, KMeansConstants.SCORE_COLUMN_NAME)
    // 用户、物品、聚类、评分表
    val userItemClusterScoreDataFrame = scoreDataFrame.join(clusterDataFrame, Seq(KMeansConstants.ITEM_COLUMN_NAME)).
      select(KMeansConstants.USER_COLUMN_NAME, KMeansConstants.ITEM_COLUMN_NAME,
        KMeansConstants.PREDICTION_COLUMN_NAME, KMeansConstants.SCORE_COLUMN_NAME)
    // 物品、聚类、评分表
    val itemClusterScoreDataFrame = userItemClusterScoreDataFrame.
      groupBy(KMeansConstants.ITEM_COLUMN_NAME, KMeansConstants.PREDICTION_COLUMN_NAME).
      avg(KMeansConstants.SCORE_COLUMN_NAME).
      toDF(KMeansConstants.ITEM_COLUMN_NAME, KMeansConstants.PREDICTION_COLUMN_NAME, KMeansConstants.SCORE_COLUMN_NAME)
    if (recommendOnline) {
      if (saveToHive) {
        userItemClusterScoreDataFrame.write.mode(SaveMode.Overwrite).saveAsTable(userItemClusterScoreTable)
        itemClusterScoreDataFrame.write.mode(SaveMode.Overwrite).saveAsTable(itemClusterScoreTable)
      }
      if (saveToHBase) {
        // 定义局部变量
        val localZkQuorum = zkQuorum
        val localZkPort = zkPort
        val localUserItemClusterScoreTable = userItemClusterScoreTable
        val localItemClusterScoreTable = itemClusterScoreTable
        val localClusterItemScoreTable = clusterItemScoreTable
        val localDefaultCf = DEFAULT_COLUMN_FAMILY
        val localDefaultCfBytes = DEFAULT_COLUMN_FAMILY_BYTES
        val localDefaultBatchSize = DEFAULT_BATCH_PUT_SIZE
        val localDefaultSplitter = DEFAULT_SPLITTER

        // 保存userItemClusterScore
        userItemClusterScoreDataFrame.mapPartitions {
          partition => {
            val hBaseExecutor = new HBaseExecutor(localZkQuorum, localZkPort, localUserItemClusterScoreTable, localDefaultCf)
            val putList: util.List[Put] = new util.ArrayList()
            var i = 0
            while (partition.hasNext) {
              i += 1
              val row = partition.next()
              val rowKey = HashUtil.md5Encode(row.get(0).toString)
              val qualifier = row.get(2).toString + localDefaultSplitter + row.get(1).toString
              val value = row.get(3).toString
              val put = new Put(Bytes.toBytes(rowKey))
              put.add(localDefaultCfBytes, Bytes.toBytes(qualifier), Bytes.toBytes(value))
              putList.add(put)
              if (i % localDefaultBatchSize == 0) {
                hBaseExecutor.put(putList)
                putList.clear()
              }
            }
            if (putList.size() != 0)
              hBaseExecutor.put(putList)
            val result = List[String]()
            result.iterator
          }
        }.collect()

        // 保存itemClusterScore
        itemClusterScoreDataFrame.mapPartitions {
          partition => {
            val itemHBaseExecutor = new HBaseExecutor(localZkQuorum, localZkPort, localItemClusterScoreTable, localDefaultCf)
            val clusterHBaseExecutor = new HBaseExecutor(localZkQuorum, localZkPort, localClusterItemScoreTable, localDefaultCf)
            val itemPutList: util.List[Put] = new util.ArrayList[Put]()
            val clusterPutList: util.List[Put] = new util.ArrayList[Put]()
            var i = 0
            while (partition.hasNext) {
              i += 1
              val row = partition.next()
              // 物品、聚类、评分
              val itemRowKey = HashUtil.md5Encode(row.get(0).toString)
              val itemQualifier = row.get(1).toString
              val itemValue = row.get(2).toString
              val itemPut = new Put(Bytes.toBytes(itemRowKey))
              itemPut.add(localDefaultCfBytes, Bytes.toBytes(itemQualifier), Bytes.toBytes(itemValue))
              itemPutList.add(itemPut)
              // 聚类、物品、评分
              val clusterRowKey = HashUtil.md5Encode(row.get(1).toString)
              val clusterQualifier = row.get(0).toString
              val clusterValue = row.get(2).toString
              val clusterPut = new Put(Bytes.toBytes(clusterRowKey))
              clusterPut.add(localDefaultCfBytes, Bytes.toBytes(clusterQualifier), Bytes.toBytes(clusterValue))
              clusterPutList.add(clusterPut)
              if (i % localDefaultBatchSize == 0) {
                itemHBaseExecutor.put(itemPutList)

                clusterHBaseExecutor.put(clusterPutList)
                itemPutList.clear()
                clusterPutList.clear()
              }
            }
            if (itemPutList.size() != 0)
              itemHBaseExecutor.put(itemPutList)
            if (clusterPutList.size() != 0)
              clusterHBaseExecutor.put(clusterPutList)
            val result = List[String]()
            result.iterator
          }
        }.collect()

      }
    }
    else {
      val localRecommendResultSize = recommendResultSize
      // 取每用户下前resultSize个聚类
      val limitedUserClusterScoreDataFrame = hiveContext.createDataFrame(
        userItemClusterScoreDataFrame.groupBy(KMeansConstants.USER_COLUMN_NAME, KMeansConstants.PREDICTION_COLUMN_NAME).
          sum(KMeansConstants.SCORE_COLUMN_NAME).map {
          case Row(user, cluster, score) => (user.toString, (cluster.toString.toInt, score.toString.toDouble))
        }.groupByKey().flatMap {
          grouped => {
            //            val recommendResultSizeConfig = sc.getConf.get(KMeansConfig.recommendResultSize)
            //            if (StringUtils.isNotBlank(recommendResultSizeConfig))
            //              recommendResultSize = recommendResultSizeConfig.toInt
            grouped._2.map(temp => (grouped._1, (temp._1, temp._2))).
              toList.sortWith((a, b) => a._2._2 > b._2._2).take(localRecommendResultSize)
          }
        }.map {
          case (user, (cluster, score)) => (user, cluster, score)
        }).
        toDF(KMeansConstants.USER_COLUMN_NAME, KMeansConstants.PREDICTION_COLUMN_NAME, KMeansConstants.SCORE_COLUMN_NAME)

      // 取每聚类下前resultSize个物品
      val limitedItemClusterScoreDataFrame = hiveContext.createDataFrame(
        itemClusterScoreDataFrame.map {
          case Row(item, cluster, score) => (cluster.toString.toInt, (item.toString, score.toString.toDouble))
        }.groupByKey().flatMap {
          grouped => {
            //            val recommendResultSizeConfig = sc.getConf.get(KMeansConfig.recommendResultSize)
            //            if (StringUtils.isNotBlank(recommendResultSizeConfig))
            //              recommendResultSize = recommendResultSizeConfig.toInt
            grouped._2.map(temp => (grouped._1, (temp._1, temp._2))).
              toList.sortWith((a, b) => a._2._2 > b._2._2).take(localRecommendResultSize)
          }
        }.map {
          case (cluster, (item, score)) => (cluster, item, score)
        }).
        toDF(KMeansConstants.PREDICTION_COLUMN_NAME, KMeansConstants.ITEM_COLUMN_NAME, KMeansConstants.SCORE_COLUMN_NAME)

      // 取前resultSize个结果作为推荐结果
      val joinedDataFrame = limitedUserClusterScoreDataFrame.join(limitedItemClusterScoreDataFrame, Seq(KMeansConstants.PREDICTION_COLUMN_NAME), "left").
        select(limitedUserClusterScoreDataFrame(KMeansConstants.USER_COLUMN_NAME), limitedItemClusterScoreDataFrame(KMeansConstants.ITEM_COLUMN_NAME),
          limitedUserClusterScoreDataFrame(KMeansConstants.SCORE_COLUMN_NAME) + limitedItemClusterScoreDataFrame(KMeansConstants.SCORE_COLUMN_NAME)).
        toDF(KMeansConstants.USER_COLUMN_NAME, KMeansConstants.ITEM_COLUMN_NAME, KMeansConstants.SCORE_COLUMN_NAME)
      val resultDataFrame = hiveContext.createDataFrame(
        // 过滤已评分物品
        joinedDataFrame.join(userItemClusterScoreDataFrame, Seq(KMeansConstants.USER_COLUMN_NAME, KMeansConstants.ITEM_COLUMN_NAME), "left").
          where(userItemClusterScoreDataFrame(KMeansConstants.PREDICTION_COLUMN_NAME).isNull).
          select(joinedDataFrame(KMeansConstants.USER_COLUMN_NAME),
            joinedDataFrame(KMeansConstants.ITEM_COLUMN_NAME),
            joinedDataFrame(KMeansConstants.SCORE_COLUMN_NAME)).
        // 输出竖表不需要后续代码
          map {
            case Row(user, item, score) => (user.toString, (item.toString, score.toString.toDouble))
          }.
          // 取top localRecommendResultSize个结果，输出横表不需要取top
          groupByKey().flatMap {
          grouped => {
            //            val recommendResultSizeConfig = sc.getConf.get(KMeansConfig.recommendResultSize)
            //            if (StringUtils.isNotBlank(recommendResultSizeConfig))
            //              recommendResultSize = recommendResultSizeConfig.toInt
            grouped._2.map(temp => (grouped._1, (temp._1, temp._2))).
              toList.sortWith((a, b) => a._2._2 > b._2._2).take(localRecommendResultSize)
          }
        }.groupByKey().map {
          grouped => {
            var resultStr = ""
            val size = grouped._2.size
            var i = 0
            grouped._2.map(temp => {
              i += 1
              resultStr += temp._1 + ":" + "%.2f".format(temp._2)
              if (i != size)
                resultStr += ","
            })
            (grouped._1, resultStr)
          }
        }
      ).toDF(KMeansConstants.USER_COLUMN_NAME, KMeansConstants.RESULT_COLUMN_NAME)
      if (saveToHive) {
        resultDataFrame.write.mode(SaveMode.Overwrite).saveAsTable(recommendHiveTable)
      }
      if (saveToHBase) {
        var i = 0
        val resultPutList: util.List[Put] = new util.ArrayList()
        resultDataFrame.collect().foreach {
          case Row(user, result) =>
            i = i + 1
            val put = new Put(Bytes.toBytes(HashUtil.md5Encode(user.toString)))
            put.add(hbaseTableCfBytes, DEFAULT_RESULT_QUALIFIER, Bytes.toBytes(result.toString))
            resultPutList.add(put)
            if (i == DEFAULT_BATCH_PUT_SIZE) {
              saveResults()
              i = 0
            }
        }
        saveResults()
        def saveResults(): Unit = {
          resultHBaseExecutor.put(resultPutList)
          resultPutList.clear()
        }
      }
    }
  }

  def main(args: Array[String]) {

    val defaultParams = KMeansParams()
    val parser = new OptionParser[KMeansParams]("") {
      head("KMeans recommend", "1.0")
      opt[String]('c', "conf")
        .valueName("config-file-path")
        .text(s"配置文件，必选")
        .action {
          (x, c) => c.copy(conf = x)
        }
      help("help").text("prints this usage text")
    }

    var props: Properties = null
    parser.parse(args, defaultParams) match {
      case Some(params) => {
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
      }
      case None => System.exit(-1)
    }

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")

    val sparkConf = new SparkConf().
      setAppName(props.getProperty(KMeansConfig.SPARK_NAME_CONFIG)).
      setMaster(props.getProperty(KMeansConfig.SPARK_MASTER_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)
    val hiveContext = new HiveContext(sc)

    if (!init(sc, hiveContext, props))
      System.exit(-1)

    val prediction = predict()
    if (needRecommend) {
      recommend(prediction)
    }
    sc.stop()

  }

}
