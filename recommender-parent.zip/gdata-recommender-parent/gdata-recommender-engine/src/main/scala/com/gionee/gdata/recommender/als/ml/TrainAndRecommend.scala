package com.gionee.gdata.recommender.als.ml

import java.util.Properties

import com.gionee.gdata.common.ConfigLoader
import com.gionee.gdata.recommender.als.{ALSConfig, ALSParams}
import org.apache.log4j.Logger
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
  * <code>TrainAndRecommend</code>.
  * 训练模型并进行推荐
  *
  * @author zweig
  *         version: 1.0-SNAPSHOT
  *         date: 2017/6/9 18:15
  */
object TrainAndRecommend {

  val logger = Logger.getLogger(TrainAndRecommend.getClass)

  def main(args: Array[String]) {

    val defaultParams = ALSParams()
    val parser = new OptionParser[ALSParams]("") {
      head("ML ALS TrainAndRecommend", "1.0")
      opt[String]('c', "conf")
        .required()
        .valueName("config-file-path")
        .text(s"配置文件，必选")
        .action { (x, c) => c.copy(conf = x) }
      help("help").text("prints this usage text")
    }

    var props: Properties = null
    parser.parse(args, defaultParams) match {
      case Some(params) => {
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
      }
      case None => System.exit(1)
    }

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")

    val sparkConf = new SparkConf().
      setAppName(props.getProperty(ALSConfig.SPARK_NAME_CONFIG)).
      setMaster(props.getProperty(ALSConfig.SPARK_MASTER_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)
    val hiveContext = new HiveContext(sc)

    // init als train
    if (!Train.init(sc, hiveContext, props))
      System.exit(-1)
    Train.train()

    // init als recommend
    if (!Recommend.init(sc, hiveContext, props))
      System.exit(-1)
    Recommend.recommendBatch()

  }

}
