package com.gionee.gdata.recommender.game

import java.text.SimpleDateFormat
import java.util.Properties

import com.gionee.gdata.common._
import com.gionee.gdata.recommender.game.TrainModel.UserGameRating
import org.apache.log4j.Logger
import org.apache.spark.ml.recommendation._
import org.apache.spark.sql.Row
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
 * <code>Evaluate</code>.
 * 评估模型
  *
  * @author zweig
 * version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:16
 */
object Evaluate {

  val logger = Logger.getLogger(Evaluate.getClass)

  var sc: SparkContext = _
  var hiveContext: HiveContext = _

  var ranks: String = _
  var iterations: String = _
  var lambdas: String = _
  var userBlocks: String = _
  var itemBlocks: String = _
  var samples: Int = _

  def init(sc: SparkContext, evaluateProps: Properties): Unit = {

    this.ranks = evaluateProps.getProperty(GameEvaluateConfig.ALS_RANKS_CONFIG, "50")
    this.iterations = evaluateProps.getProperty(GameEvaluateConfig.ALS_ITERATIONS_CONFIG, "10")
    this.lambdas = evaluateProps.getProperty(GameEvaluateConfig.ALS_LAMBDAS_CONFIG, "0.0001")
    this.userBlocks = evaluateProps.getProperty(GameEvaluateConfig.ALS_USER_BLOCKS_CONFIG, "100")
    this.itemBlocks = evaluateProps.getProperty(GameEvaluateConfig.ALS_ITEM_BLOCKS_CONFIG, "10")
    this.samples = evaluateProps.getProperty(GameEvaluateConfig.SAMPLES_CONFIG, "1000000").toInt

    // spark配置上下文
    this.sc = sc
    this.hiveContext = new HiveContext(sc)
  }

  def evaluate(date: String): Unit = {

    val ratings = hiveContext.createDataFrame(
      hiveContext.sql(s"SELECT user_id, imei, game_id, case when rating is null then 0 else rating end rating FROM dlv_game_recommend_rating_his where day_id = ${date} limit $samples").
        map {
          case Row(user_id: Long, imei: String, game_id: String, rating: Double) =>
            UserGameRating(user_id.toInt, imei, game_id.toInt, rating)
        }
    ).cache()
    val count = ratings.count()
    if (count == 0) {
      logger.warn(s"不存在该日期 [ $date ] 的游戏数据，无法训练模型。")
      return
    }

    val splits = ratings.randomSplit(Array(0.8, 0.2))
    val training = splits(0).cache()
    val trainingCount = training.count()
    logger.info(s"用于模型训练的游戏数据条数：$trainingCount")
    val test = splits(1).cache()
    val testCount = test.count()
    logger.info(s"用于评估模型的游戏数据条数：$testCount")

    val ranksArray = this.ranks.split(",")
    val iterationsArray = this.iterations.split(",")
    val lambdasArray = this.lambdas.split(",")
    val userBlocksArray = this.userBlocks.split(",")
    val itemBlocksArray = this.itemBlocks.split(",")

    // 循环读取rank数组
    for (rank <- ranksArray) {
      // 循环读取迭代次数
      for (iteration <- iterationsArray) {
        // 循环读取正则因子
        for (lambda <- lambdasArray) {
          // 循环读取用户块
          for (userBlocks <- userBlocksArray) {
            // 循环读取物品块
            for (itemBlocks <- itemBlocksArray) {
              val rankNum = rank.trim.toInt
              val iterationNum = iteration.trim.toInt
              val lambdaNum = lambda.trim.toDouble
              val userBlocksNum = userBlocks.trim.toInt
              val itemBlocksNum = itemBlocks.trim.toInt
              val als = new ALS()
                .setUserCol("userId")
                .setItemCol("gameId")
                .setRatingCol("rating")
                .setPredictionCol("prediction")
                .setRank(rankNum)
                .setMaxIter(iterationNum)
                .setRegParam(lambdaNum)
                .setNumUserBlocks(userBlocksNum)
                .setNumItemBlocks(itemBlocksNum)
              val startTime = System.currentTimeMillis()
              val model = als.fit(training)
              val predictions = model.transform(training).cache()
              val endTime = System.currentTimeMillis()
              val duration = (endTime - startTime)

              predictions.select("rating", "prediction").take(10).foreach {
                case Row(rating: Double, prediction: Float) =>
                  logger.info(s"rating = $rating, prediction = $prediction samples = $samples, rank = $rankNum, iteration = $iterationNum, lambda = $lambdaNum, userBlocks = $userBlocksNum, itemBlocks = $itemBlocksNum, duration = $duration")
              }

              val mse = predictions.select("rating", "prediction").rdd.flatMap {
                case Row(rating: Double, prediction: Float) =>
                  val err = rating - prediction
                  val err2 = err * err
                  if (err2.isNaN) {
                    None
                  } else {
                    Some(err2)
                  }
              }.mean()
              val rmse = math.sqrt(mse)
              logger.info(s"Evaluate RMSE = $rmse. samples = $samples, rank = $rankNum, iteration = $iterationNum, lambda = $lambdaNum, userBlocks = $userBlocksNum, itemBlocks = $itemBlocksNum, duration = $duration")
            }
          }
        }
      }
    }

  }

  def main(args: Array[String]) {
    var props = ConfigLoader.load(ConfigConstants.CONFIG_FILE)
    var evaluateProps = ConfigLoader.load(GameEvaluateConfig.CONFIG_FILE)

    val defaultParams = GameEvaluateParams()
    val parser = new OptionParser[GameEvaluateParams]("") {
      head("Evaluate Game", "1.0")
      opt[String]('c', "conf")
        .valueName("config-file-path")
        .text(s"配置文件，若不配置，则使用默认的配置文件")
        .action {
          (x, c) => c.copy(conf = x)
        }
      opt[String]('e', "evaluateConf")
        .valueName("evaluate-config-file-path")
        .text(s"评估模型配置文件，若不配置，则使用默认的配置文件")
        .action { (x, c) => c.copy(evaluateConf = x) }
      opt[String]('d', "date")
        .required()
        .valueName("<date>")
        .text(s"日期，必选，日期格式必须是 yyyy-MM-dd")
        .action {
          (x, c) => c.copy(date = x)
        }
        .validate { x =>
          try {
            new SimpleDateFormat("yyyy-MM-dd").parse(x)
            success
          } catch {
            case ex: Exception => failure("日期格式必须是 yyyy-MM-dd")
          }
        }
      help("help").text("prints this usage text")
    }

    var date: String = ""
    parser.parse(args, defaultParams) match {
      case Some(params) => {
        date = params.date
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
        if (params.evaluateConf != null)
          evaluateProps = ConfigLoader.load(params.evaluateConf)
      }
      case None => System.exit(1)
    }
    date = new SimpleDateFormat("yyyyMMdd").format(new SimpleDateFormat("yyyy-MM-dd").parse(date))

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")
    val evaluatePropsStr = evaluateProps.toString
    logger.info(s"evaluate配置信息：$evaluatePropsStr")

    val sparkConf = new SparkConf().
      setAppName("Evaluate").
      setMaster(props.getProperty(ConfigConstants.SPARK_MASTER_CONFIG)).
      set("spark.ui.port", props.getProperty(ConfigConstants.SPARK_UI_PORT_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)

    init(sc, evaluateProps)
    evaluate(date)

    sc.stop()
  }

}
