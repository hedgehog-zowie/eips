package com.gionee.gdata.recommender.lr

import java.util.Properties

import com.gionee.gdata.common.ConfigLoader
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.mllib.classification.LogisticRegressionModel
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.{Row, SaveMode}
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
  * <code>Recommend</code>.
  * 推荐
  *
  * @author taylor
  *         version: 1.0-SNAPSHOT
  *         date: 2017/6/9 18:19
  */
object Recommend {
  /**
    * 日志记录器
    */
  val logger = Logger.getLogger(this.getClass)

  // Spark上下文
  var sc: SparkContext = _
  var hiveContext: HiveContext = _

  // 业务参数
  /**
    * 预测使用模型
    */
  var model: LogisticRegressionModel = _
  /**
    * 待预测集查询sql
    */
  var predictSql: String = _
  /**
    * 是否需要进行推荐
    */
  var needRecommend: Boolean = false
  /**
    * 是否保存到Hive
    */
  var saveToHive: Boolean = false
  /**
    * 每用户推荐结果个数
    */
  var recommendResultSize: Int = 2
  /**
    * 待推荐结果表
    */
  var recommendHiveTable: String = _

  /**
    * 初始化
    *
    * @param sc
    * @param hiveContext
    * @param props
    */
  def init(sc: SparkContext, hiveContext: HiveContext, props: Properties): Boolean = {

    // spark配置上下文
    this.sc = sc
    this.hiveContext = hiveContext

    val modelPath = props.getProperty(LRConfig.MODEL_PATH_CONFIG)
    if (StringUtils.isBlank(modelPath)) {
      logger.error("模型保存路径必须配置")
      return false
    }
    this.model = LogisticRegressionModel.load(sc, modelPath)

    this.predictSql = props.getProperty(LRConfig.PREDICT_SQL_CONFIG)
    this.recommendHiveTable = props.getProperty(LRConfig.RECOMMEND_TABLE_IN_HIVE_CONFIG)

    val needRecommendConfig = props.getProperty(LRConfig.NEED_RECOMMEND_CONFIG)
    if (StringUtils.isNotBlank(needRecommendConfig))
      this.needRecommend = needRecommendConfig.toBoolean

    val saveToHiveConfig = props.getProperty(LRConfig.SAVE_TO_HIVE_CONFIG)
    if (StringUtils.isNoneBlank(saveToHiveConfig))
      this.saveToHive = saveToHiveConfig.toBoolean

    if (needRecommend) {
      if (StringUtils.isBlank(this.predictSql)) {
        logger.error("待预测集查询SQL必须配置")
        return false
      }

      if (saveToHive) {
        if (StringUtils.isBlank(this.recommendHiveTable)) {
          logger.error("需要进行推荐，推荐结果表名必须配置")
          return false
        }
      }

    }

    val recommendResultSizeConfig = props.getProperty(LRConfig.RECOMMEND_RESULT_SIZE_CONFIG)
    if (StringUtils.isNotBlank(recommendResultSizeConfig)) {
      this.recommendResultSize = recommendResultSizeConfig.toInt
    }

    true
  }

  /**
    * 加载LR模型预测并得到推荐结果
    *
    */
  def recommend(): Unit = {
    val data = hiveContext.sql(predictSql).rdd.map {
      case Row(userId: String, itemId: String, feature: String) =>
        (userId, itemId, Vectors.dense(feature.split(LRConstants.SPLITTER_BETWEEN_FEATURES).map(_.toDouble)))
    }
    val scoreData = hiveContext.createDataFrame(
      data.map { line =>
        (line._1, line._2, model.predict(line._3))
      }
    ).toDF(LRConstants.USER_ID_COLUMN_NAME, LRConstants.ITEM_ID_COLUMN_NAME, LRConstants.SCORE_COLUMN_NAME)
    logger.info("使用指定路径下的LR模型，预测完成")

    val recommendData = scoreData.select(
      col(LRConstants.USER_ID_COLUMN_NAME), col(LRConstants.ITEM_ID_COLUMN_NAME),
      col(LRConstants.SCORE_COLUMN_NAME), row_number().over(Window.partitionBy(LRConstants.USER_ID_COLUMN_NAME)
        .orderBy(col(LRConstants.SCORE_COLUMN_NAME).desc)
      ).alias("Row_Num")
    ).filter(col("Row_Num") <= recommendResultSize)
    logger.info("对预测出来的得分，按照用户ID分区，预测得分降序处理")

    val resultDataFrame = hiveContext.createDataFrame(
      recommendData.map {
        case Row(userId, itemId, score, row_num) => (userId.toString, (itemId.toString, score))
      }.groupByKey().map {
        grouped => {
          var resultStr = ""
          val size = grouped._2.size
          var i = 0
          grouped._2.map(temp => {
            i += 1
            resultStr += temp._1 + ":" + "%.5f".format(temp._2)
            if (i != size)
              resultStr += ","
          })
          (grouped._1, resultStr)
        }
      }
    ).toDF(LRConstants.USER_ID_COLUMN_NAME, LRConstants.ITEM_ID_COLUMN_NAME)
    logger.info(s"对每个用户ID，生成横表：物品:得分,物品:得分等的格式，每个用户只有一行")

    if (saveToHive) {
      resultDataFrame.write.mode(SaveMode.Overwrite).saveAsTable(recommendHiveTable)
    }
    logger.info(s"推荐结果生成，每个用户只取：$recommendResultSize 物品，结果保存到HIVE表：$recommendHiveTable")
  }

  def main(args: Array[String]) {

    val defaultParams = LRParams()
    val parser = new OptionParser[LRParams]("") {
      head("LR recommend", "1.0")
      opt[String]('c', "conf")
        .valueName("config-file-path")
        .text(s"配置文件，必选")
        .action {
          (x, c) => c.copy(conf = x)
        }
      help("help").text("prints this usage text")
    }

    var props: Properties = null
    parser.parse(args, defaultParams) match {
      case Some(params) =>
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
      case None => System.exit(-1)
    }

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")

    val sparkConf = new SparkConf().
      setAppName(props.getProperty(LRConfig.SPARK_NAME_CONFIG)).
      setMaster(props.getProperty(LRConfig.SPARK_MASTER_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)
    val hiveContext = new HiveContext(sc)

    if (!init(sc, hiveContext, props) && !needRecommend)
      System.exit(-1)
    recommend()

    sc.stop()
  }
}