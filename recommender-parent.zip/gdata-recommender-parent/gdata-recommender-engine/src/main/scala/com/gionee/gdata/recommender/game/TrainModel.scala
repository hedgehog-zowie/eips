package com.gionee.gdata.recommender.game

import java.text.SimpleDateFormat
import java.util.Properties

import com.gionee.gdata.common._
import com.gionee.gdata.common.utils.FileUtil4S
import org.apache.log4j.Logger
import org.apache.spark.ml.recommendation._
import org.apache.spark.sql.Row
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
 * <code>TrainModel</code>.
 * 训练模型
 *
 * @author zweig
 * version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:18
 */
object TrainModel {

  val logger = Logger.getLogger(TrainModel.getClass)

  /**
    * 用户游戏评分类
    *
    * @param userId
    * @param imei
    * @param gameId
    * @param rating
    */
  case class UserGameRating(userId: Int, imei: String, gameId: Int, rating: Double)

  var gameModelPath: String = _

  var sc: SparkContext = _
  var hiveContext: HiveContext = _

  var ranks: Int = _
  var iterations: Int = _
  var lambdas: Double = _
  var userBlocks: Int = _
  var itemBlocks: Int = _

  def init(sc: SparkContext, props: Properties): Unit = {
    // 模型保存路径
    this.gameModelPath = props.getProperty(GameConfigConstants.MODEL_PATH_CONFIG, "/data/spark/data/game/model")

    this.ranks = props.getProperty(GameConfigConstants.RANKS_CONFIG, "8").toInt
    this.iterations = props.getProperty(GameConfigConstants.ITERATIONS_CONFIG, "12").toInt
    this.lambdas = props.getProperty(GameConfigConstants.LAMBDAS_CONFIG, "0.1").toDouble
    this.userBlocks = props.getProperty(GameConfigConstants.USER_BLOCKS_CONFIG, "10").toInt
    this.itemBlocks = props.getProperty(GameConfigConstants.ITEM_BLOCKS_CONFIG, "10").toInt

    // spark配置上下文
    this.sc = sc
    this.hiveContext = new HiveContext(sc)
  }

  def train(date: String): Unit = {

    val ratings = hiveContext.createDataFrame(
      hiveContext.sql(s"SELECT user_id, imei, game_id, case when rating is null then 0 else rating end rating FROM dlv_game_recommend_rating_his where day_id = ${date}").
        map {
          case Row(user_id: Long, imei: String, game_id: String, rating: Double) =>
            UserGameRating(user_id.toInt, imei, game_id.toInt, rating)
        }
    ).cache()
    val count = ratings.count()
    if (count == 0) {
      logger.warn(s"不存在该日期 [ $date ] 的游戏数据，无法训练模型。")
      return
    }
    logger.info(s"用于模型训练的游戏数据条数：$count")

    val als = new ALS()
      .setUserCol("userId")
      .setItemCol("gameId")
      .setRatingCol("rating")
      .setPredictionCol("prediction")
      .setRank(ranks)
      .setMaxIter(iterations)
      .setRegParam(lambdas)
      .setNumUserBlocks(userBlocks)
      .setNumItemBlocks(itemBlocks)
    val model = als.fit(ratings)

    // 保存模型
    FileUtil4S.deleteHdfsFile(sc, gameModelPath)
    model.save(gameModelPath)

  }

  def main(args: Array[String]) {
    var props = ConfigLoader.load(ConfigConstants.CONFIG_FILE)
    var gameProps = ConfigLoader.load(GameConfigConstants.CONFIG_FILE)

    val defaultParams = GameParams()
    val parser = new OptionParser[GameParams]("") {
      head("TrainModel", "1.0")
      opt[String]('c', "conf")
        .valueName("config-file-path")
        .text(s"配置文件，若不配置，则使用默认的配置文件")
        .action {
          (x, c) => c.copy(conf = x)
        }
      opt[String]('g', "gameConf")
        .valueName("game-config-file-path")
        .text(s"游戏推荐配置文件，若不配置，则使用默认的配置文件")
        .action { (x, c) => c.copy(gameConf = x) }
      opt[String]('d', "date")
        .required()
        .valueName("<date>")
        .text(s"日期，必选，日期格式必须是 yyyy-MM-dd")
        .action {
          (x, c) => c.copy(date = x)
        }
        .validate { x =>
          try {
            new SimpleDateFormat("yyyy-MM-dd").parse(x)
            success
          } catch {
            case ex: Exception => failure("日期格式必须是 yyyy-MM-dd")
          }
        }
      help("help").text("prints this usage text")
    }

    var date: String = ""
    parser.parse(args, defaultParams) match {
      case Some(params) => {
        date = params.date
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
        if (params.gameConf != null)
          gameProps = ConfigLoader.load(params.gameConf)
      }
      case None => System.exit(1)
    }
    date = new SimpleDateFormat("yyyyMMdd").format(new SimpleDateFormat("yyyy-MM-dd").parse(date))

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")
    val gamePropsStr = gameProps.toString
    logger.info(s"game配置信息：$gamePropsStr")

    val sparkConf = new SparkConf().
      setAppName("TrainModel").
      setMaster(props.getProperty(ConfigConstants.SPARK_MASTER_CONFIG)).
      set("spark.ui.port", props.getProperty(ConfigConstants.SPARK_UI_PORT_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)

    init(sc, gameProps)
    train(date)

    sc.stop()
  }

}
