package com.gionee.gdata.recommender.als.ml

import java.util
import java.util.Properties

import com.gionee.gdata.common.ConfigLoader
import com.gionee.gdata.common.hbase.HBaseExecutor
import com.gionee.gdata.common.utils.HashUtil
import com.gionee.gdata.recommender.als.{ALSConfig, ALSConstants, ALSParams}
import org.apache.commons.lang3.StringUtils
import org.apache.hadoop.hbase.client.Put
import org.apache.hadoop.hbase.util.Bytes
import org.apache.log4j.Logger
import org.apache.spark.ml.recommendation._
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.{DataFrame, Row, SaveMode}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
 * <code>Recommend</code>.
 * 预测评分
 * @author zweig
 * version: 1.0-SNAPSHOT
 * date: 2017/6/9 18:16
 */
object Recommend {

  val logger = Logger.getLogger(Recommend.getClass)

  // spark相关参数
  var sc: SparkContext = _
  var hiveContext: HiveContext = _
  var model: ALSModel = _

  // 业务参数
  /**
    * 模型保存路径
    */
  var modelPath: String = _
  /**
    * 评分表查询sql
    */
  var scoreSql: String = _
  /**
    * 用户表，用户与ID对应表
    */
  var userIdTableName: String = _
  /**
    * 物品表，物品与ID对应表
    */
  var itemIdTableName: String = _
  /**
    * 待推荐物品查询sql
    */
  var itemSql: String = _
  /**
    * 是否保存结果到hive
    */
  var saveToHive: Boolean = false
  /**
    * 推荐结果表
    */
  var resultHiveTable: String = _
  /**
    * 预测批处理用户个数
    */
  var batch: Int = _
  /**
    * 每用户推荐结果个数
    */
  var resultSize: Int = _

  /**
    * 是否保存推荐结果到HBase
    */
  var saveToHBase: Boolean = true
  // HBase相关参数
  var zkQuorum: String = _
  var zkPort: String = _
  var hbaseTableName: String = _
  var hbaseTableCf: String = _
  var hbaseTableCfBytes: Array[Byte] = _
  var hBaseExecutor: HBaseExecutor = _
  val DEFAULT_BLOCK_SIZE = 16384
  val DEFAULT_REGION_NUM = 60
  val DEFAULT_RESULT_QUALIFIER = Bytes.toBytes("r")

  def init(sc: SparkContext, hiveContext: HiveContext, props: Properties): Boolean = {
    // spark配置上下文
    this.sc = sc
    this.hiveContext = hiveContext

    // 模型保存路径
    this.modelPath = props.getProperty(ALSConfig.MODEL_PATH_CONFIG)
    if (StringUtils.isBlank(this.modelPath)) {
      logger.error("模型保存路径必须配置")
      return false
    }
    // 用户表，用户与ID对应表
    this.userIdTableName = props.getProperty(ALSConfig.USER_ID_TABLE_CONFIG)
    if (StringUtils.isBlank(this.userIdTableName)) {
      logger.error("用户ID对应表必须配置")
      return false
    }
    // 物品表，物品与ID对应表
    this.itemIdTableName = props.getProperty(ALSConfig.ITEM_ID_TABLE_CONFIG)
    if (StringUtils.isBlank(this.itemIdTableName)) {
      logger.error("物品ID对应表必须配置")
      return false
    }
    // 待推荐物品查询sql
    this.itemSql = props.getProperty(ALSConfig.ITEM_SQL_CONFIG)
    if (StringUtils.isBlank(this.itemSql)) {
      logger.error("推荐物品查询sql必须配置")
      return false
    }
    // 评分表查询sql
    this.scoreSql = props.getProperty(ALSConfig.SCORE_SQL_CONFIG)
    if (StringUtils.isBlank(this.scoreSql)) {
      logger.error("评分表查询sql必须配置")
      return false
    }

    // 预测批处理用户个数
    this.batch = props.getProperty(ALSConfig.BATCH_CONFIG, "100000").toInt
    // 每用户推荐结果个数
    this.resultSize = props.getProperty(ALSConfig.RESULT_SIZE_CONFIG, "10").toInt

    // 加载模型
    this.model = ALSModel.load(modelPath)

    // 保存结果到hive相关配置
    val saveToHiveConfig = props.getProperty(ALSConfig.SAVE_TO_HIVE_CONFIG)
    if (StringUtils.isNotBlank(saveToHiveConfig))
      this.saveToHive = saveToHiveConfig.toBoolean
    this.resultHiveTable = props.getProperty(ALSConfig.RESULT_TABLE_CONFIG)
    if (saveToHive) {
      if (StringUtils.isBlank(this.resultHiveTable)) {
        logger.error("需要保存推荐结果到Hive，Hive推荐结果表必须配置")
        return false
      }
      hiveContext.sql(s"DROP TABLE IF EXISTS ${resultHiveTable}")
    }

    // 保存结果到hBase相关配置
    val saveToHBaseConfig = props.getProperty(ALSConfig.SAVE_TO_HBASE_CONFIG)
    if (StringUtils.isNotBlank(saveToHBaseConfig))
      this.saveToHBase = saveToHBaseConfig.toBoolean
    if (saveToHBase) {
      // hbase操作
      this.zkQuorum = props.getProperty(ALSConfig.ZK_QUORUM_CONFIG)
      this.zkPort = props.getProperty(ALSConfig.ZK_PORT_CONFIG)
      this.hbaseTableName = props.getProperty(ALSConfig.HBASE_RESULT_TABLE_CONFIG)
      this.hbaseTableCf = props.getProperty(ALSConfig.HBASE_RESULT_CF_CONFIG)
      if (StringUtils.isBlank(zkQuorum) || StringUtils.isBlank(zkPort) || StringUtils.isBlank(hbaseTableName) || StringUtils.isBlank(hbaseTableCf)) {
        logger.error("hbase相关配置错误")
        return false
      }
      this.hBaseExecutor = new HBaseExecutor(zkQuorum, zkPort, hbaseTableName, hbaseTableCf)
      this.hbaseTableCfBytes = Bytes.toBytes(hbaseTableCf)
      if (!this.hBaseExecutor.exists())
        this.hBaseExecutor.create(DEFAULT_BLOCK_SIZE, DEFAULT_REGION_NUM)
    }

    return true
  }

  /**
    * 批量预测
    */
  def recommendBatch(): Unit = {
    val userIdTable = hiveContext.sql(s"select ${ALSConstants.USER_COLUMN_NAME}, ${ALSConstants.USER_ID_COLUMN_NAME} from ${userIdTableName}").persist(StorageLevel.MEMORY_AND_DISK_SER)
    val itemIdTable = hiveContext.sql(s"select ${ALSConstants.ITEM_COLUMN_NAME}, ${ALSConstants.ITEM_ID_COLUMN_NAME} from ${itemIdTableName}").persist(StorageLevel.MEMORY_AND_DISK_SER)
    val itemTable = hiveContext.sql(itemSql).toDF(ALSConstants.ITEM_COLUMN_NAME).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    // 用户已评分物品
    val scores = hiveContext.sql(scoreSql).toDF(ALSConstants.USER_COLUMN_NAME, ALSConstants.ITEM_COLUMN_NAME, ALSConstants.RATING_COLUMN_NAME).persist(StorageLevel.MEMORY_AND_DISK_SER)
    recommendBatch(userIdTable, itemIdTable, itemTable, scores)
    userIdTable.unpersist()
    itemTable.unpersist()
    itemIdTable.unpersist()
    scores.unpersist()
  }

  /**
    * 批量预测
    *
    * @param userIdTable
    * @param itemIdTable
    * @param itemTable
    */
  def recommendBatch(userIdTable: DataFrame, itemIdTable: DataFrame, itemTable: DataFrame, scores: DataFrame): Unit = {

    // 待预测的物品ID
    val itemIds = itemTable.join(itemIdTable, ALSConstants.ITEM_COLUMN_NAME).
      select(ALSConstants.ITEM_COLUMN_NAME, ALSConstants.ITEM_ID_COLUMN_NAME).
      map { case Row(item, itemId) => (item.toString, itemId.toString.toInt) }.
      collect()

    val numItems = itemIds.size
    if (numItems == 0) {
      logger.warn(s"物品数为0，不预测评分。")
      return
    }
    logger.info(s"物品数：$numItems")

    val bItemIds = sc.broadcast(itemIds)

    // 用户数
    val users = userIdTable.collect()
    val numUsers = users.size
    if (numUsers == 0) {
      logger.warn(s"用户数为0，不预测评分。")
      return
    }
    logger.info(s"用户数：$numUsers")

    // 按用户批量处理
    var userList: List[(String, Int)] = List()
    users.foreach {
      case Row(user, userId) => {
        userList = userList.::((user.toString, userId.toString().toInt))
        val size = userList.size
        if (size == batch) {
          run
        }
      }
    }
    run

    def run(): Unit = {
      val numUsers = userList.size
      if (numUsers != 0) {
        logger.info(s"批量预测评分, 用户数量: $numUsers")
        val bUserList = sc.broadcast(userList)
        val userItems = sc.parallelize(bUserList.value).cartesian(sc.parallelize(bItemIds.value)).map {
          case ((user, userId), (item, itemId)) =>
            (user, userId, item, itemId, 0d)
        }.cache()
        // 预测评分
        val predictions = predict(userItems).cache()
        // 过滤已评分物品
        val joinedPredictions = predictions.join(scores, Seq(ALSConstants.USER_COLUMN_NAME, ALSConstants.ITEM_COLUMN_NAME), "left").
          toDF(ALSConstants.USER_COLUMN_NAME, ALSConstants.ITEM_COLUMN_NAME, ALSConstants.USER_ID_COLUMN_NAME,
            ALSConstants.ITEM_ID_COLUMN_NAME, ALSConstants.PREDICTION_COLUMN_NAME, ALSConstants.RATING_COLUMN_NAME)
        val filteredPredictions = joinedPredictions.where(joinedPredictions(ALSConstants.RATING_COLUMN_NAME).isNull).
          select(joinedPredictions(ALSConstants.USER_COLUMN_NAME),
            joinedPredictions(ALSConstants.USER_ID_COLUMN_NAME),
            joinedPredictions(ALSConstants.ITEM_COLUMN_NAME),
            joinedPredictions(ALSConstants.ITEM_ID_COLUMN_NAME),
            joinedPredictions(ALSConstants.PREDICTION_COLUMN_NAME)
          )
        val results = recommend(filteredPredictions).cache()

        // 保存结果，追加
        if (saveToHive)
          results.write.mode(SaveMode.Append).saveAsTable(resultHiveTable)
        if (saveToHBase) {
          val putList: util.List[Put] = new util.ArrayList()
          results.collect().foreach {
            case Row(user, result) =>
              val put = new Put(Bytes.toBytes(HashUtil.md5Encode(user.toString)))
              put.add(hbaseTableCfBytes, DEFAULT_RESULT_QUALIFIER, Bytes.toBytes(result.toString))
              putList.add(put)
          }
          hBaseExecutor.put(putList)
        }

        results.unpersist()
        predictions.unpersist()
        userItems.unpersist()
      }

      // 清空list
      userList = List()
    }

    // 按物品批量处理
    //    var itemList: List[(String, Int)] = List()
    //    val itemIdDataFrame = itemTable.join(itemIdTable, ALSConstants.itemColumnName).
    //      select(ALSConstants.itemColumnName, ALSConstants.itemIdColumnName)
    //    itemIdDataFrame.collect().foreach {
    //      case Row(item, itemId) => {
    //        itemList = itemList ++ List((item.toString, itemId.toString().toInt))
    //        val size = itemList.size
    //        if (size == batch) {
    //          run()
    //        }
    //      }
    //    }
    //
    //    def run(): Unit = {
    //      val numItems = itemList.size
    //      if (numItems != 0) {
    //        logger.info(s"批量预测评分, 物品数量: $numItems")
    //        val userItems = userIdTable.rdd.cartesian(sc.parallelize(itemList)).map {
    //          case (Row(user, userId), (item, itemId)) =>
    //            (user.toString, userId.toString.toInt, item, itemId, 0d)
    //        }.cache()
    //        // 预测评分
    //        val predictions = predict(userItems).cache()
    //        val results = recommend(predictions).cache()
    //
    //        // 保存结果，追加
    //        results.write.mode(SaveMode.Append).saveAsTable(resultTable)
    //
    //        results.unpersist()
    //        predictions.unpersist()
    //        userItems.unpersist()
    //      }
    //      // 清空list
    //      itemList = List()

  }

  /**
    * 预测评分
    *
    * @param userItems
    * @return
    */
  private def predict(userItems: RDD[(String, Int, String, Int, Double)]): DataFrame = {
    model.transform(hiveContext.createDataFrame(userItems).toDF(
      ALSConstants.USER_COLUMN_NAME,
      ALSConstants.USER_ID_COLUMN_NAME,
      ALSConstants.ITEM_COLUMN_NAME,
      ALSConstants.ITEM_ID_COLUMN_NAME,
      ALSConstants.RATING_COLUMN_NAME
    )).select(
      ALSConstants.USER_COLUMN_NAME,
      ALSConstants.USER_ID_COLUMN_NAME,
      ALSConstants.ITEM_COLUMN_NAME,
      ALSConstants.ITEM_ID_COLUMN_NAME,
      ALSConstants.PREDICTION_COLUMN_NAME
    )
  }

  /**
    * 得出推荐结果
    *
    * @return
    */
  private def recommend(predictions: DataFrame): DataFrame = {
    hiveContext.createDataFrame(
      predictions.map {
        case Row(user, userId, item, itemId, prediction) =>
          ((user.toString, userId.toString.toInt), (item.toString, itemId.toString.toInt, prediction.toString.toDouble))
      }.groupByKey().flatMap(
        grouped => {
          grouped._2.map(temp => (grouped._1, (temp._1, temp._2, temp._3))).
            toList.sortWith((a, b) => a._2._3 > b._2._3).take(resultSize)
        }).groupByKey().map {
        grouped => {
          var resultStr = ""
          val size = grouped._2.size
          var i = 0
          grouped._2.map(temp => {
            i += 1
            resultStr += temp._1 + ":" + "%.2f".format(temp._3)
            if (i != size)
              resultStr += ","
          })
          (grouped._1._1, resultStr)
        }
      }
    ).toDF(ALSConstants.USER_COLUMN_NAME, ALSConstants.RESULT_COLUMN_NAME)
  }

  def main(args: Array[String]) {

    val defaultParams = ALSParams()
    val parser = new OptionParser[ALSParams]("") {
      head("ML ALS Recommend", "1.0")
      opt[String]('c', "conf")
        .required()
        .valueName("config-file-path")
        .text(s"配置文件，必选")
        .action {
          (x, c) => c.copy(conf = x)
        }
      help("help").text("prints this usage text")
    }

    var props: Properties = null
    parser.parse(args, defaultParams) match {
      case Some(params) => {
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
      }
      case None => System.exit(1)
    }

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")

    val sparkConf = new SparkConf().
      setAppName(props.getProperty(ALSConfig.SPARK_NAME_CONFIG)).
      setMaster(props.getProperty(ALSConfig.SPARK_MASTER_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)
    val hiveContext = new HiveContext(sc)
    new org.apache.spark.sql.SQLContext(sc)

    if (!init(sc, hiveContext, props))
      System.exit(-1)
    recommendBatch()

    sc.stop()
  }

}
