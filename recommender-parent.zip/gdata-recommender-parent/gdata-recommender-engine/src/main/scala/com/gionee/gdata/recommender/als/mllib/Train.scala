package com.gionee.gdata.recommender.als.mllib

import java.util.Properties

import com.gionee.gdata.common.ConfigLoader
import com.gionee.gdata.common.utils.FileUtil4S
import com.gionee.gdata.recommender.als.{ALSConfig, ALSConstants, ALSParams}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.mllib.recommendation.{ALS, Rating}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.{DataFrame, Row, SaveMode}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}
import scopt.OptionParser

/**
  * <code>Train</code>.
  * 训练模型
  *
  * @author zweig
  *         version: 1.0-SNAPSHOT
  *         date: 2017/6/9 18:15
  */
object Train {

  /**
    * 日志记录器
    */
  val logger = Logger.getLogger(Train.getClass)

  var sc: SparkContext = _
  var hiveContext: HiveContext = _

  var ranks: Int = _
  var iterations: Int = _
  var lambdas: Double = _
  var userBlocks: Int = _
  var itemBlocks: Int = _
  var partitions: Int = _

  /**
    * 模型保存路径
    */
  var modelPath: String = _
  /**
    * 评分表查询sql
    */
  var scoreSql: String = _
  /**
    * 用户表，用户与ID对应表
    */
  var userIdTable: String = _
  /**
    * 物品表，物品与ID对应表
    */
  var itemIdTable: String = _

  def init(sc: SparkContext, hiveContext: HiveContext, props: Properties): Boolean = {
    // 业务参数
    this.modelPath = props.getProperty(ALSConfig.MODEL_PATH_CONFIG)
    if (StringUtils.isBlank(this.modelPath)) {
      logger.error("模型保存路径必须配置")
      return false
    }
    this.scoreSql = props.getProperty(ALSConfig.SCORE_SQL_CONFIG)
    if (StringUtils.isBlank(this.scoreSql)) {
      logger.error("评分表查询sql必须配置")
      return false
    }
    this.userIdTable = props.getProperty(ALSConfig.USER_ID_TABLE_CONFIG)
    if (StringUtils.isBlank(this.userIdTable)) {
      logger.error("用户ID对应表必须配置")
      return false
    }
    this.itemIdTable = props.getProperty(ALSConfig.ITEM_ID_TABLE_CONFIG)
    if (StringUtils.isBlank(this.itemIdTable)) {
      logger.error("物品ID对应表必须配置")
      return false
    }

    // spark配置上下文
    this.sc = sc
    this.hiveContext = hiveContext

    // 模型优化参数
    this.ranks = props.getProperty(ALSConfig.RANKS_CONFIG, "10").toInt
    this.iterations = props.getProperty(ALSConfig.ITERATIONS_CONFIG, "10").toInt
    this.lambdas = props.getProperty(ALSConfig.LAMBDAS_CONFIG, "1.0").toDouble
    this.partitions = props.getProperty(ALSConfig.PARTITIONS_CONFIG, "200").toInt

    return true
  }

  def train(): Unit = {
    train(hiveContext.sql(scoreSql).
      map {
        case Row(user, item, rating) =>
          (user.toString, item.toString, rating.toString.toDouble)
      })
  }

  def train(ratingRdd: RDD[(String, String, Double)]): Unit = {

    val originalRatings = hiveContext.createDataFrame(ratingRdd).
      toDF(ALSConstants.USER_COLUMN_NAME, ALSConstants.ITEM_COLUMN_NAME, ALSConstants.RATING_COLUMN_NAME).
      repartition(partitions).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val count = originalRatings.count()
    if (count == 0) {
      logger.warn(s"不存在数据，无法训练模型。查询SQL = ${scoreSql}")
      return
    }
    logger.info(s"用于模型训练的数据条数：$count")

    val indexedUserDataFrame = transUserToId(originalRatings)
    val userCount = indexedUserDataFrame.count()
    logger.info(s"用户个数：$userCount")
    val indexedItemDataFrame = transItemToId(originalRatings)
    val itemCount = indexedItemDataFrame.count()
    logger.info(s"物品个数：$itemCount")

    val ratings = originalRatings.join(indexedUserDataFrame, Seq(ALSConstants.USER_COLUMN_NAME), "left").
      join(indexedItemDataFrame, Seq(ALSConstants.ITEM_COLUMN_NAME), "left").
      select(ALSConstants.USER_ID_COLUMN_NAME, ALSConstants.ITEM_ID_COLUMN_NAME, ALSConstants.RATING_COLUMN_NAME).
      map {
        case Row(userId, itemId, rating) =>
          Rating(userId.toString.toInt, itemId.toString.toInt, rating.toString.toDouble)
      }.
      repartition(partitions).persist(StorageLevel.MEMORY_AND_DISK_SER)

    // 训练模型
    val model = ALS.train(ratings, ranks, iterations, lambdas)
    // 保存模型
    FileUtil4S.deleteHdfsFile(sc, modelPath)
    model.save(sc, modelPath)

  }

  def transUserToId(data: DataFrame): DataFrame = {
    val userIdDataFrame = hiveContext.createDataFrame(data.select(ALSConstants.USER_COLUMN_NAME).distinct().
      map { case Row(user) => user.toString }.zipWithIndex()).
      toDF(ALSConstants.USER_COLUMN_NAME, ALSConstants.USER_ID_COLUMN_NAME).
      persist(StorageLevel.MEMORY_AND_DISK_SER)
    userIdDataFrame.write.mode(SaveMode.Overwrite).saveAsTable(userIdTable)
    userIdDataFrame
  }

  def transItemToId(data: DataFrame): DataFrame = {
    val itemIdDataFrame = hiveContext.createDataFrame(data.select(ALSConstants.ITEM_COLUMN_NAME).distinct().
      map { case Row(item) => item.toString }.zipWithIndex()).
      toDF(ALSConstants.ITEM_COLUMN_NAME, ALSConstants.ITEM_ID_COLUMN_NAME).
      persist(StorageLevel.MEMORY_AND_DISK_SER)
    itemIdDataFrame.write.mode(SaveMode.Overwrite).saveAsTable(itemIdTable)
    itemIdDataFrame
  }

  def main(args: Array[String]) {

    val defaultParams = ALSParams()
    val parser = new OptionParser[ALSParams]("") {
      head("MLLib ALS Train", "1.0")
      opt[String]('c', "conf")
        .required()
        .valueName("config-file-path")
        .text(s"配置文件，必选")
        .action { (x, c) => c.copy(conf = x) }
      help("help").text("prints this usage text")
    }

    var props: Properties = null
    parser.parse(args, defaultParams) match {
      case Some(params) => {
        if (params.conf != null)
          props = ConfigLoader.load(params.conf)
      }
      case None => System.exit(-1)
    }

    val propsStr = props.toString
    logger.info(s"配置信息：$propsStr")

    val sparkConf = new SparkConf().
      setAppName(props.getProperty(ALSConfig.SPARK_NAME_CONFIG)).
      setMaster(props.getProperty(ALSConfig.SPARK_MASTER_CONFIG)).
      set("spark.hadoop.validateOutputSpecs", "false") // 不检查输出路径，若存在，则覆盖
    val sc = new SparkContext(sparkConf)
    val hiveContext = new HiveContext(sc)

    if (!init(sc, hiveContext, props))
      System.exit(-1)
    train()

    sc.stop()
  }

}
