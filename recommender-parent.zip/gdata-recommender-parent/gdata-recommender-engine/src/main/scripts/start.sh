#!/bin/bash
spark-submit --class com.gionee.gdata.recommender.Boot recommender.jar -c config/app.properties
